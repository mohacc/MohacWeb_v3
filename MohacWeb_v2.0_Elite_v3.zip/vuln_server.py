#!/usr/bin/env python3
import http.server
import json
import urllib.parse

class VulnHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args): pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        params = urllib.parse.parse_qs(parsed.query)
        
        if path == "/search":
            q = params.get("q", [""])[0]
            if "'" in q or "1=1" in q or "OR" in q.upper():
                self.html(200, "SQL syntax error near '" + q + "' at line 1")
            else:
                self.html(200, "Results for: " + q)
        elif path == "/echo":
            msg = params.get("msg", [""])[0]
            self.html(200, msg)
        elif path.startswith("/file"):
            fname = params.get("name", [""])[0]
            if ".." in fname or "etc" in fname:
                self.text(200, "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin\nwww-data:x:33:33:www-data:/var/www\n")
            else:
                self.text(200, "Contents of " + fname)
        elif path == "/ping":
            host = params.get("host", [""])[0]
            if ";" in host or "|" in host or "&" in host:
                self.html(200, "uid=33(www-data) gid=33(www-data) groups=33(www-data)")
            else:
                self.html(200, "PING " + host + " 64 bytes")
        elif path == "/redirect":
            url = params.get("url", [""])[0]
            self.send_response(302)
            self.send_header("Location", url)
            self.end_headers()
        elif path == "/api/data":
            origin = self.headers.get("Origin", "*")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Credentials", "true")
            self.end_headers()
            self.wfile.write(json.dumps({"status":"ok","secret":"flag{cors_misconfigured}"}).encode())
        elif path.startswith("/user"):
            uid = params.get("id", ["1"])[0]
            users = {"1":{"id":1,"name":"admin","email":"admin@target.com","role":"admin"},
                     "2":{"id":2,"name":"john","email":"john@target.com","role":"user"}}
            self.json(200, users.get(uid, users["1"]))
        elif path == "/fetch":
            url = params.get("url", [""])[0]
            if "169.254" in url or "metadata" in url or "localhost" in url or "127.0.0.1" in url:
                self.json(200, {"ami-id":"ami-12345","instance-id":"i-12345","instance-type":"t2.micro"})
            else:
                self.text(200, "Fetched: " + url)
        elif path == "/.env":
            self.text(200, "DB_HOST=localhost\nDB_USER=root\nDB_PASS=SuperSecret123!\nAPI_KEY=sk-1234567890abcdef")
        elif path == "/.git/config":
            self.text(200, "[core]\nrepositoryformatversion = 0\n[remote origin]\nurl = https://github.com/target/secrets.git")
        elif path == "/.git/HEAD":
            self.text(200, "ref: refs/heads/main")
        elif path == "/backup.sql":
            self.text(200, "CREATE TABLE users (id INT, username VARCHAR(255), password VARCHAR(255))")
        elif path == "/config.php":
            self.text(200, "<?php $db_pass = 'P@ssw0rd123'; $secret_key = 'my-secret-key'; ?>")
        elif path == "/.htaccess":
            self.text(200, "RewriteEngine On\nAuthUserFile /var/www/.htpasswd")
        elif path == "/web.config":
            self.text(200, "<configuration><connectionStrings><add connectionString=\"Server=localhost;Password=Admin123!\"/></connectionStrings></configuration>")
        elif path == "/robots.txt":
            self.text(200, "User-agent: *\nDisallow: /admin\nDisallow: /api/internal\nDisallow: /debug\nDisallow: /backup")
        elif path == "/.DS_Store":
            self.text(200, "Bud1")
        elif path == "/package.json":
            self.text(200, '{"name":"target","dependencies":{"express":"4.17.1","lodash":"4.17.19","jquery":"3.5.0"}}')
        elif path == "/phpinfo.php":
            self.text(200, "PHP Version 7.4.3 - phpinfo()")
        elif path.startswith("/graphql"):
            q = params.get("query", [""])[0]
            if "introspection" in q.lower() or "__schema" in q:
                self.json(200, {"data":{"__schema":{"types":[{"name":"Query","fields":[{"name":"users"},{"name":"admin"},{"name":"secrets"}]}]}}})
            else:
                self.json(200, {"data":{"users":[{"id":"1","name":"admin"}]}})
        elif path == "/api/v1/users":
            self.json(200, {"users":[{"id":1,"name":"admin"},{"id":2,"name":"user"}]})
        elif path == "/api/v1/config":
            self.json(200, {"debug":True,"version":"1.0","admin_panel":"/admin"})
        elif path == "/api/v2/auth":
            self.json(200, {"token_endpoint":"/oauth/token","grant_types":["password","authorization_code"]})
        elif path == "/api/docs":
            self.json(200, {"swagger":"2.0","info":{"title":"Target API","version":"1.0"}})
        elif path == "/swagger.json":
            self.json(200, {"swagger":"2.0","info":{"title":"Target API"}})
        elif path == "/openapi.json":
            self.json(200, {"openapi":"3.0.0","info":{"title":"Target API"}})
        elif path == "/xml":
            self.send_response(200)
            self.send_header("Content-Type", "text/xml")
            self.end_headers()
            self.wfile.write(b'<?xml version="1.0"?><response><data>XML endpoint</data></response>')
        elif path == "/template":
            name = params.get("name", ["World"])[0]
            if "{{" in name or "${" in name or "#{" in name:
                self.html(200, "Hello " + name + " Rendered: 49")
            else:
                self.html(200, "Hello " + name)
        elif path == "/api/jwt":
            import base64
            h = base64.urlsafe_b64encode(b'{"alg":"none","typ":"JWT"}').rstrip(b"=").decode()
            p = base64.urlsafe_b64encode(b'{"user":"admin","role":"admin","exp":9999999999}').rstrip(b"=").decode()
            self.json(200, {"token":h+"."+p+".","hint":"alg:none"})
        elif path == "/oauth/authorize":
            redir = params.get("redirect_uri", [""])[0]
            self.send_response(302)
            self.send_header("Location", redir+"?code=test123&state=abc")
            self.end_headers()
        elif path == "/frame-test":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"Sensitive Page - can be framed")
        elif path == "/login":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Set-Cookie", "session=abc123; Path=/; HttpOnly; SameSite=None")
            self.end_headers()
            self.wfile.write(json.dumps({"status":"logged_in","session":"abc123"}).encode())
        elif path == "/cname":
            self.text(200, "There is no app configured at this hostname. Heroku")
        elif path == "/shop/price":
            pid = params.get("id", ["1"])[0]
            items = {"1":{"name":"Premium","price":99.99},"2":{"name":"Basic","price":9.99}}
            self.json(200, items.get(pid, items["1"]))
        elif path == "/email-security":
            self.json(200, {"spf":"v=spf1 include:_spf.google.com ~all","dmarc":"v=DMARC1; p=none","dkim":"not_configured"})
        elif path == "/admin":
            self.send_response(401)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"Admin Panel - Authentication Required")
        elif path == "/rate-test":
            self.json(200, {"status":"ok","no_limit":True})
        elif path == "/privacy":
            self.html(200, "Privacy Policy")
        elif path == "/cookie-policy":
            self.html(200, "Cookie Policy")
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            html = "<html><head><title>Test App</title></head><body>"
            html += "<h1>Welcome to Test Application v1.0</h1>"
            html += "<p>Server: Apache/2.4.41 | PHP/7.4.3 | jQuery 3.5.0</p>"
            html += "<a href=/search>Search</a> | <a href=/echo>Echo</a> | <a href=/login>Login</a>"
            html += "</body></html>"
            self.wfile.write(html.encode())

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8', errors='ignore')
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        
        if path == "/graphql":
            if "introspection" in body.lower() or "__schema" in body:
                self.json(200, {"data":{"__schema":{"types":[{"name":"Query","fields":[{"name":"users"},{"name":"secrets"}]}]}}})
            else:
                self.json(200, {"data":{"users":[{"id":"1"}]}})
        elif path == "/login":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Set-Cookie", "session=abc123")
            self.end_headers()
            self.wfile.write(json.dumps({"status":"logged_in"}).encode())
        elif path == "/xml":
            if "ENTITY" in body or "SYSTEM" in body:
                self.send_response(200)
                self.send_header("Content-Type", "text/xml")
                self.end_headers()
                self.wfile.write(b'<?xml version="1.0"?><response>root:x:0:0:root:/root:/bin/bash</response>')
            else:
                self.send_response(200)
                self.send_header("Content-Type", "text/xml")
                self.end_headers()
                self.wfile.write(b'<?xml version="1.0"?><response>OK</response>')
        elif path == "/auth":
            try:
                creds = json.loads(body)
                if creds.get("password") == "admin123":
                    self.json(200, {"status":"success"})
                else:
                    self.json(401, {"status":"failed"})
            except:
                self.send_response(400)
                self.end_headers()
        elif path.startswith("/api/fuzz"):
            self.json(200, {"status":"processed"})
        else:
            self.send_response(404)
            self.end_headers()

    def html(self, code, body):
        self.send_response(code)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(("<html><body>" + body + "</body></html>").encode())

    def text(self, code, body):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(body.encode())

    def json(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

if __name__ == "__main__":
    port = 9999
    server = http.server.HTTPServer(("127.0.0.1", port), VulnHandler)
    print(f"[*] Test server: http://127.0.0.1:{port}")
    server.serve_forever()
