# MohacWeb v2.0 Elite Edition
# 60 Security Modules - Cross Platform Scanner
# 
# Kullanim:
# 1. python3 vuln_server.py (test sunucusu)
# 2. python3 MohacWeb_v2.0_Elite.py (scanner)
# 3. Hedef: http://127.0.0.1:9999
# 4. Kategori Sec: S/R/I/A/F
#
# Moduller:
# [S] Scan (1-30): SQLi, XSS, SSRF, SSTI, XXE...
# [R] Recon (31-40): Deep Recon, OSINT, DNS...
# [I] Infra (41-50): AI Report, Compliance...
# [A] Advanced (51-60): Dashboard, CI/CD...
# [F] Full Scan (60 modul)
#
# Otomatik HTML rapor olusturulur.
