# MohacWeb v3.0 - FIXED VERSION

## Quick Start
```bash
python3 MohacWeb.py
```

## Test Target
http://testphp.vulnweb.com

## Features
- 33 Menu Options
- 5-Layer Deep Scan
- AI Hacker Brain
- PoC Generator
- WAF Evasion
- OOB Listener
