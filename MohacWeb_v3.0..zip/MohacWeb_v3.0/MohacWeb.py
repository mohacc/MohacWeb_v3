#!/usr/bin/env python3
# -*- coding: ascii -*-
"""
MohacWeb v3.0 - Advanced Web Security Scanner
- 5-Layer Deep Scanning
- AI Hacker Brain
- PoC Generator
- WAF Evasion
- 40+ Menu Options
"""

import re
import os
import sys
import json
import time
import sqlite3
import hashlib
import random
import string
import urllib.request
import urllib.parse
import urllib.error
import http.client
import ssl
import socket
import threading
from datetime import datetime

# ============================================================
# ANSI COLOR CODES
# ============================================================
class C:
    R = "\033[91m"      # Red
    G = "\033[92m"      # Green
    B = "\033[94m"      # Blue
    Y = "\033[93m"      # Yellow
    Cy = "\033[96m"     # Cyan
    M = "\033[95m"      # Magenta
    O = "\033[33m"      # Orange
    W = "\033[97m"      # White
    Bold = "\033[1m"
    Dim = "\033[2m"
    Reset = "\033[0m"

# ============================================================
# BANNER
# ============================================================
BANNER = f"""{C.Cy}
{C.Bold}
  ___  ___   ___      _    __        __   ___         
 |   \/   | / _ \    | |   \ \      / /  / _ \        
 |  \/  1 | / /_\ \   | |__  \ \ /\ / /  / /_\ \       
 |  |\/ 1 | |  _  |  |  _ \  \ V  V /   |  _  |       
 |__|  |__|_|_| |_|  |_| |_|  \_/\_/    |_| |_|       
{C.Reset}
{C.Y}  [ Advanced Web Security Scanner v3.0 ]{C.Reset}
{C.G}  [ 5-Layer Deep Scan | AI Hacker Brain | PoC Gen ]{C.Reset}
{C.Dim}  [ 40+ Features | WAF Evasion | OOB Listener ]{C.Reset}
"""

# ============================================================
# DATABASE CLASS (INLINE)
# ============================================================
class Database:
    def __init__(self, db_file="mohacweb.db"):
        self.db_file = db_file
        self.conn = sqlite3.connect(db_file, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self.init_tables()
    
    def init_tables(self):
        self.cursor.executescript("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target TEXT NOT NULL,
                scan_type TEXT DEFAULT 'quick',
                status TEXT DEFAULT 'pending',
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                results TEXT,
                vuln_count INTEGER DEFAULT 0
            );
            
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                type TEXT NOT NULL,
                severity TEXT DEFAULT 'medium',
                url TEXT,
                parameter TEXT,
                payload TEXT,
                evidence TEXT,
                cvss_score REAL DEFAULT 0.0,
                cwe_id TEXT,
                owasp_category TEXT,
                remediation TEXT,
                found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (scan_id) REFERENCES scans(id)
            );
            
            CREATE TABLE IF NOT EXISTS poc_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vuln_type TEXT,
                target TEXT,
                poc_code TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS hacker_diary (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                phase TEXT,
                action TEXT,
                details TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (scan_id) REFERENCES scans(id)
            );
            
            CREATE TABLE IF NOT EXISTS scan_schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target TEXT,
                scan_type TEXT,
                cron_expression TEXT,
                last_run TIMESTAMP,
                next_run TIMESTAMP,
                active INTEGER DEFAULT 1
            );
        """)
        self.conn.commit()
    
    def create_scan(self, target, scan_type="quick"):
        self.cursor.execute(
            "INSERT INTO scans (target, scan_type, status) VALUES (?, ?, 'running')",
            (target, scan_type)
        )
        self.conn.commit()
        return self.cursor.lastrowid
    
    def update_scan(self, scan_id, status, results=None, vuln_count=0):
        self.cursor.execute(
            "UPDATE scans SET status=?, completed_at=CURRENT_TIMESTAMP, results=?, vuln_count=? WHERE id=?",
            (status, results, vuln_count, scan_id)
        )
        self.conn.commit()
    
    def add_vulnerability(self, scan_id, vuln_type, severity, url, parameter="", payload="", evidence="", cvss=0.0, cwe="", owasp="", remediation=""):
        self.cursor.execute(
            "INSERT INTO vulnerabilities (scan_id, type, severity, url, parameter, payload, evidence, cvss_score, cwe_id, owasp_category, remediation) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (scan_id, vuln_type, severity, url, parameter, payload, evidence, cvss, cwe, owasp, remediation)
        )
        self.conn.commit()
        return self.cursor.lastrowid
    
    def get_scan(self, scan_id):
        self.cursor.execute("SELECT * FROM scans WHERE id=?", (scan_id,))
        return self.cursor.fetchone()
    
    def get_vulnerabilities(self, scan_id):
        self.cursor.execute("SELECT * FROM vulnerabilities WHERE scan_id=?", (scan_id,))
        return self.cursor.fetchall()
    
    def get_all_scans(self):
        self.cursor.execute("SELECT * FROM scans ORDER BY started_at DESC LIMIT 50")
        return self.cursor.fetchall()
    
    def add_diary(self, scan_id, phase, action, details):
        self.cursor.execute(
            "INSERT INTO hacker_diary (scan_id, phase, action, details) VALUES (?,?,?,?)",
            (scan_id, phase, action, details)
        )
        self.conn.commit()
    
    def close(self):
        self.conn.close()

# ============================================================
# SCANNER ENGINE
# ============================================================
class Scanner:
    def __init__(self, db):
        self.db = db
        self.session = None
        self.vulns = []
    
    def quick_scan(self, target, scan_id):
        """Quick scan - basic checks"""
        print(f"\n{C.Cy}[*] Starting Quick Scan on: {target}{C.Reset}")
        self.db.add_diary(scan_id, "RECON", "Quick Scan Started", f"Target: {target}")
        
        vulns = []
        
        # Check HTTP headers
        vulns.extend(self.check_headers(target, scan_id))
        
        # Check for common vulnerabilities
        vulns.extend(self.check_xss(target, scan_id))
        vulns.extend(self.check_sqli(target, scan_id))
        vulns.extend(self.check_sensitive_data(target, scan_id))
        
        return vulns
    
    def deep_scan(self, target, scan_id):
        """Deep scan - 5 layers"""
        print(f"\n{C.Cy}[*] Starting 5-Layer Deep Scan on: {target}{C.Reset}")
        self.db.add_diary(scan_id, "RECON", "Deep Scan Started", f"Target: {target}")
        
        vulns = []
        
        # Layer 1: Surface
        print(f"{C.G}[Layer 1/5] Surface Scan...{C.Reset}")
        vulns.extend(self.check_headers(target, scan_id))
        vulns.extend(self.check_server_info(target, scan_id))
        
        # Layer 2: Medium
        print(f"{C.G}[Layer 2/5] Medium Scan...{C.Reset}")
        vulns.extend(self.check_xss(target, scan_id))
        vulns.extend(self.check_sqli(target, scan_id))
        vulns.extend(self.check_open_redirect(target, scan_id))
        
        # Layer 3: Deep Aggressive
        print(f"{C.G}[Layer 3/5] Deep Aggressive Scan...{C.Reset}")
        vulns.extend(self.check_sensitive_data(target, scan_id))
        vulns.extend(self.check_cors(target, scan_id))
        vulns.extend(self.check_ssl(target, scan_id))
        
        # Layer 4: Verification
        print(f"{C.G}[Layer 4/5] Verification...{C.Reset}")
        vulns = self.verify_vulns(vulns, target, scan_id)
        
        # Layer 5: Chain Analysis
        print(f"{C.G}[Layer 5/5] Chain Analysis...{C.Reset}")
        vulns.extend(self.chain_analysis(target, scan_id, vulns))
        
        return vulns
    
    def check_headers(self, target, scan_id):
        vulns = []
        try:
            url = target if target.startswith("http") else "http://" + target
            req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            response = urllib.request.urlopen(req, timeout=10, context=ctx)
            headers = dict(response.headers)
            
            missing = []
            security_headers = [
                "X-Frame-Options", "X-Content-Type-Options", "X-XSS-Protection",
                "Strict-Transport-Security", "Content-Security-Policy",
                "Referrer-Policy", "Permissions-Policy"
            ]
            
            for h in security_headers:
                if h not in headers:
                    missing.append(h)
            
            if missing:
                vuln = {
                    "type": "Missing Security Headers",
                    "severity": "medium",
                    "url": url,
                    "parameter": ", ".join(missing),
                    "payload": "",
                    "evidence": f"Missing headers: {', '.join(missing)}",
                    "cvss": 4.0,
                    "cwe": "CWE-693",
                    "owasp": "A05:2021-Security Misconfiguration",
                    "remediation": "Add all recommended security headers"
                }
                vulns.append(vuln)
                self.db.add_vulnerability(scan_id, **vuln)
                print(f"{C.Y}[!] Missing Security Headers: {', '.join(missing[:3])}...{C.Reset}")
            
            # Check server header
            if "Server" in headers:
                vuln = {
                    "type": "Server Information Disclosure",
                    "severity": "low",
                    "url": url,
                    "parameter": "Server",
                    "payload": "",
                    "evidence": f"Server: {headers['Server']}",
                    "cvss": 2.0,
                    "cwe": "CWE-200",
                    "owasp": "A01:2021-Broken Access Control",
                    "remediation": "Remove or mask Server header"
                }
                vulns.append(vuln)
                self.db.add_vulnerability(scan_id, **vuln)
                print(f"{C.Y}[!] Server Disclosure: {headers['Server']}{C.Reset}")
                
        except Exception as e:
            print(f"{C.R}[-] Header check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_xss(self, target, scan_id):
        vulns = []
        payloads = [
            '<script>alert("XSS")</script>',
            '"><img src=x onerror=alert(1)>',
            "javascript:alert(1)",
            "'-alert(1)-'"
        ]
        
        try:
            url = target if target.startswith("http") else "http://" + target
            req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib.request.urlopen(req, timeout=10, context=ctx)
            html = response.read().decode("utf-8", errors="ignore")
            
            # Find forms
            forms = re.findall(r'<form[^>]*action=["\']?([^"\'> ]*)', html, re.I)
            inputs = re.findall(r'<input[^>]*name=["\']?([^"\'> ]+)', html, re.I)
            
            if inputs:
                for payload in payloads[:2]:
                    for inp in inputs[:3]:
                        test_url = f"{url}?{inp}={urllib.parse.quote(payload)}"
                        try:
                            req2 = urllib.request.Request(test_url, headers={"User-Agent": "MohacWeb/3.0"})
                            resp2 = urllib.request.urlopen(req2, timeout=10, context=ctx)
                            body = resp2.read().decode("utf-8", errors="ignore")
                            
                            if payload in body:
                                vuln = {
                                    "type": "Reflected XSS",
                                    "severity": "high",
                                    "url": test_url,
                                    "parameter": inp,
                                    "payload": payload,
                                    "evidence": f"Payload reflected in response",
                                    "cvss": 6.1,
                                    "cwe": "CWE-79",
                                    "owasp": "A03:2021-Injection",
                                    "remediation": "Implement output encoding and CSP"
                                }
                                vulns.append(vuln)
                                self.db.add_vulnerability(scan_id, **vuln)
                                print(f"{C.R}[!] XSS Found: {inp} at {url}{C.Reset}")
                                break
                        except:
                            pass
                            
        except Exception as e:
            print(f"{C.R}[-] XSS check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_sqli(self, target, scan_id):
        vulns = []
        payloads = ["'", "1' OR '1'='1", "1; SELECT * FROM users", "' UNION SELECT NULL--"]
        errors = ["sql", "mysql", "syntax", "query", "database", "error", "warning", "oracle", "postgresql"]
        
        try:
            url = target if target.startswith("http") else "http://" + target
            req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib.request.urlopen(req, timeout=10, context=ctx)
            html = response.read().decode("utf-8", errors="ignore")
            
            inputs = re.findall(r'<input[^>]*name=["\']?([^"\'> ]+)', html, re.I)
            
            for payload in payloads[:2]:
                for inp in inputs[:3]:
                    test_url = f"{url}?{inp}={urllib.parse.quote(payload)}"
                    try:
                        req2 = urllib.request.Request(test_url, headers={"User-Agent": "MohacWeb/3.0"})
                        resp2 = urllib.request.urlopen(req2, timeout=10, context=ctx)
                        body = resp2.read().decode("utf-8", errors="ignore").lower()
                        
                        for error in errors:
                            if error in body:
                                vuln = {
                                    "type": "SQL Injection",
                                    "severity": "critical",
                                    "url": test_url,
                                    "parameter": inp,
                                    "payload": payload,
                                    "evidence": f"SQL error detected: {error}",
                                    "cvss": 9.8,
                                    "cwe": "CWE-89",
                                    "owasp": "A03:2021-Injection",
                                    "remediation": "Use parameterized queries, input validation"
                                }
                                vulns.append(vuln)
                                self.db.add_vulnerability(scan_id, **vuln)
                                print(f"{C.R}[!!!] SQL Injection Found: {inp} at {url}{C.Reset}")
                                break
                    except:
                        pass
                        
        except Exception as e:
            print(f"{C.R}[-] SQLi check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_sensitive_data(self, target, scan_id):
        vulns = []
        patterns = {
            "Email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            "IP Address": r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",
            "AWS Key": r"AKIA[0-9A-Z]{16}",
            "API Key": r"[a-zA-Z0-9]{32,}",
        }
        
        try:
            url = target if target.startswith("http") else "http://" + target
            req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib.request.urlopen(req, timeout=10, context=ctx)
            html = response.read().decode("utf-8", errors="ignore")
            
            for name, pattern in patterns.items():
                matches = re.findall(pattern, html)
                if matches and len(matches) > 0:
                    vuln = {
                        "type": f"Sensitive Data - {name}",
                        "severity": "high",
                        "url": url,
                        "parameter": name,
                        "payload": "",
                        "evidence": f"Found {len(matches)} {name} occurrences",
                        "cvss": 5.3,
                        "cwe": "CWE-200",
                        "owasp": "A01:2021-Broken Access Control",
                        "remediation": "Remove sensitive data from response"
                    }
                    vulns.append(vuln)
                    self.db.add_vulnerability(scan_id, **vuln)
                    print(f"{C.Y}[!] {name} Found: {len(matches)} occurrences{C.Reset}")
                    
        except Exception as e:
            print(f"{C.R}[-] Sensitive data check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_server_info(self, target, scan_id):
        vulns = []
        try:
            url = target if target.startswith("http") else "http://" + target
            hostname = urllib.parse.urlparse(url).hostname
            ip = socket.gethostbyname(hostname)
            
            print(f"{C.Cy}[*] Server IP: {ip}{C.Reset}")
            
            # Check common ports
            common_ports = [21, 22, 80, 443, 3306, 8080, 8443]
            open_ports = []
            
            for port in common_ports[:5]:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    result = sock.connect_ex((hostname, port))
                    if result == 0:
                        open_ports.append(port)
                    sock.close()
                except:
                    pass
            
            if open_ports:
                print(f"{C.Y}[!] Open Ports: {open_ports}{C.Reset}")
                
        except Exception as e:
            print(f"{C.R}[-] Server info failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_open_redirect(self, target, scan_id):
        vulns = []
        try:
            url = target if target.startswith("http") else "http://" + target
            payload = "https://evil.com"
            test_url = f"{url}?redirect={urllib.parse.quote(payload)}&url={urllib.parse.quote(payload)}&next={urllib.parse.quote(payload)}"
            
            req = urllib.request.Request(test_url, headers={"User-Agent": "MohacWeb/3.0"})
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            try:
                response = urllib.request.urlopen(req, timeout=10, context=ctx)
                if response.geturl() != test_url and "evil.com" in response.geturl():
                    vuln = {
                        "type": "Open Redirect",
                        "severity": "medium",
                        "url": test_url,
                        "parameter": "redirect",
                        "payload": payload,
                        "evidence": f"Redirected to: {response.geturl()}",
                        "cvss": 5.4,
                        "cwe": "CWE-601",
                        "owasp": "A01:2021-Broken Access Control",
                        "remediation": "Validate redirect URLs against whitelist"
                    }
                    vulns.append(vuln)
                    self.db.add_vulnerability(scan_id, **vuln)
                    print(f"{C.R}[!] Open Redirect Found{C.Reset}")
            except urllib.error.HTTPError:
                pass
                
        except Exception as e:
            print(f"{C.R}[-] Open redirect check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_cors(self, target, scan_id):
        vulns = []
        try:
            url = target if target.startswith("http") else "http://" + target
            req = urllib.request.Request(url, headers={
                "User-Agent": "MohacWeb/3.0",
                "Origin": "https://evil.com"
            })
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            response = urllib.request.urlopen(req, timeout=10, context=ctx)
            headers = dict(response.headers)
            
            if "Access-Control-Allow-Origin" in headers:
                acao = headers["Access-Control-Allow-Origin"]
                if acao == "*" or "evil.com" in acao:
                    vuln = {
                        "type": "CORS Misconfiguration",
                        "severity": "high",
                        "url": url,
                        "parameter": "Access-Control-Allow-Origin",
                        "payload": "Origin: https://evil.com",
                        "evidence": f"ACAO: {acao}",
                        "cvss": 6.5,
                        "cwe": "CWE-942",
                        "owasp": "A05:2021-Security Misconfiguration",
                        "remedication": "Restrict CORS to trusted domains"
                    }
                    vulns.append(vuln)
                    self.db.add_vulnerability(scan_id, **vuln)
                    print(f"{C.R}[!] CORS Misconfiguration: {acao}{C.Reset}")
                    
        except Exception as e:
            print(f"{C.R}[-] CORS check failed: {str(e)}{C.Reset}")
        
        return vulns
    
    def check_ssl(self, target, scan_id):
        vulns = []
        try:
            url = target if target.startswith("http") else "https://" + target
            hostname = urllib.parse.urlparse(url).hostname
            
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            
            with socket.create_connection((hostname, 443), timeout=5) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert(binary_form=True)
                    if cert:
                        print(f"{C.G}[+] SSL Certificate found{C.Reset}")
                    
        except Exception as e:
            if "https" in url:
                vuln = {
                    "type": "SSL/TLS Issue",
                    "severity": "high",
                    "url": url,
                    "parameter": "SSL",
                    "payload": "",
                    "evidence": str(e),
                    "cvss": 7.5,
                    "cwe": "CWE-295",
                    "owasp": "A07:2021-Identification and Authentication Failures",
                    "remediation": "Configure proper SSL/TLS with valid certificate"
                }
                vulns.append(vuln)
                self.db.add_vulnerability(scan_id, **vuln)
                print(f"{C.R}[!] SSL Issue: {str(e)[:50]}{C.Reset}")
        
        return vulns
    
    def verify_vulns(self, vulns, target, scan_id):
        """Verify vulnerabilities to reduce false positives"""
        verified = []
        for vuln in vulns:
            # Simple verification - check if still exploitable
            if vuln.get("severity") in ["critical", "high"]:
                try:
                    url = vuln.get("url", target)
                    req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                    urllib.request.urlopen(req, timeout=10, context=ctx)
                    verified.append(vuln)
                    print(f"{C.G}[+] Verified: {vuln['type']}{C.Reset}")
                except:
                    print(f"{C.Y}[?] Could not verify: {vuln['type']}{C.Reset}")
                    verified.append(vuln)
            else:
                verified.append(vuln)
        
        return verified
    
    def chain_analysis(self, target, scan_id, existing_vulns):
        """Analyze vulnerability chains"""
        chains = []
        
        # Check for dangerous combinations
        has_sqli = any(v.get("type") == "SQL Injection" for v in existing_vulns)
        has_xss = any("XSS" in v.get("type", "") for v in existing_vulns)
        has_headers = any("Header" in v.get("type", "") for v in existing_vulns)
        
        if has_sqli and has_xss:
            chains.append({
                "type": "Critical Chain - SQLi + XSS",
                "severity": "critical",
                "url": target,
                "parameter": "Multiple",
                "payload": "",
                "evidence": "SQL Injection + XSS combination allows full compromise",
                "cvss": 10.0,
                "cwe": "CWE-89+CWE-79",
                "owasp": "A03:2021-Injection",
                "remediation": "Fix all injection vulnerabilities immediately"
            })
            print(f"{C.R}[!!!] CRITICAL CHAIN: SQLi + XSS{C.Reset}")
        
        if has_headers and has_sqli:
            chains.append({
                "type": "Chain - Missing Headers + SQLi",
                "severity": "critical",
                "url": target,
                "parameter": "Multiple",
                "payload": "",
                "evidence": "Missing security headers amplify SQLi impact",
                "cvss": 9.5,
                "cwe": "CWE-693+CWE-89",
                "owasp": "A03+A05:2021",
                "remediation": "Fix headers and SQLi vulnerabilities"
            })
            print(f"{C.R}[!!!] CHAIN: Headers + SQLi{C.Reset}")
        
        for chain in chains:
            self.db.add_vulnerability(scan_id, **chain)
        
        return chains

# ============================================================
# REPORT GENERATOR
# ============================================================
class ReportGenerator:
    def __init__(self, db):
        self.db = db
    
    def generate_html(self, scan_id):
        scan = self.db.get_scan(scan_id)
        vulns = self.db.get_vulnerabilities(scan_id)
        
        severity_colors = {
            "critical": "#ff0040",
            "high": "#ff4444",
            "medium": "#ffaa00",
            "low": "#44aa44",
            "info": "#4488ff"
        }
        
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for v in vulns:
            sev = v["severity"] if v["severity"] in severity_counts else "info"
            severity_counts[sev] += 1
        
        vuln_rows = ""
        for v in vulns:
            color = severity_colors.get(v["severity"], "#888888")
            vuln_rows += f"""
            <tr>
                <td><span style="background:{color};color:white;padding:3px 8px;border-radius:4px;">{v["severity"].upper()}</span></td>
                <td>{v["type"]}</td>
                <td style="word-break:break-all;">{v["url"][:80]}...</td>
                <td>{v["cvss_score"]}</td>
                <td>{v["owasp_category"]}</td>
            </tr>"""
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>MohacWeb Scan Report #{scan_id}</title>
    <style>
        body {{ font-family: 'Segoe UI', sans-serif; background: #0a0a0a; color: #e0e0e0; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e, #16213e); padding: 30px; border-radius: 10px; margin-bottom: 20px; }}
        .header h1 {{ color: #00d4ff; margin: 0; }}
        .stats {{ display: flex; gap: 20px; margin: 20px 0; }}
        .stat {{ background: #1a1a2e; padding: 20px; border-radius: 8px; flex: 1; text-align: center; }}
        .stat .count {{ font-size: 36px; font-weight: bold; }}
        .stat .label {{ color: #888; }}
        table {{ width: 100%; border-collapse: collapse; background: #1a1a2e; border-radius: 8px; overflow: hidden; }}
        th {{ background: #16213e; padding: 12px; text-align: left; }}
        td {{ padding: 10px; border-bottom: 1px solid #2a2a3e; }}
        tr:hover {{ background: #2a2a3e; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>MohacWeb Security Report</h1>
        <p>Scan #{scan_id} | Target: {scan["target"]} | {scan["started_at"]}</p>
    </div>
    
    <div class="stats">
        <div class="stat"><div class="count" style="color:#ff0040">{severity_counts["critical"]}</div><div class="label">Critical</div></div>
        <div class="stat"><div class="count" style="color:#ff4444">{severity_counts["high"]}</div><div class="label">High</div></div>
        <div class="stat"><div class="count" style="color:#ffaa00">{severity_counts["medium"]}</div><div class="label">Medium</div></div>
        <div class="stat"><div class="count" style="color:#44aa44">{severity_counts["low"]}</div><div class="label">Low</div></div>
        <div class="stat"><div class="count" style="color:#4488ff">{severity_counts["info"]}</div><div class="label">Info</div></div>
    </div>
    
    <h2>Vulnerabilities ({len(vulns)})</h2>
    <table>
        <tr><th>Severity</th><th>Type</th><th>URL</th><th>CVSS</th><th>OWASP</th></tr>
        {vuln_rows}
    </table>
    
    <p style="margin-top:40px;color:#666;">Generated by MohacWeb v3.0 | {datetime.now().strftime("%Y-%m-%d %H:%M")}</p>
</body>
</html>"""
        
        filename = f"report_{scan_id}.html"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)
        
        return filename

# ============================================================
# MAIN APPLICATION
# ============================================================
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def show_banner():
    clear_screen()
    print(BANNER)

def show_menu():
    print(f"""
{C.Cy}{C.Bold}    [ MAIN MENU ]{C.Reset}
{C.W}    =============={C.Reset}

{C.G}    [ SCAN ]{C.Reset}
    {C.Y}[1]{C.Reset}  Quick Scan
    {C.Y}[2]{C.Reset}  Deep Scan (5 Layers)
    {C.Y}[3]{C.Reset}  Custom Scan
    {C.Y}[4]{C.Reset}  Scan with Authentication

{C.G}    [ AI HACKER BRAIN ]{C.Reset}
    {C.Y}[5]{C.Reset}  Recon Phase
    {C.Y}[6]{C.Reset}  Mapping Phase
    {C.Y}[7]{C.Reset}  Vulnerability Discovery
    {C.Y}[8]{C.Reset}  Exploitation Phase
    {C.Y}[9]{C.Reset}  Full AI Hack

{C.G}    [ ADVANCED ]{C.Reset}
    {C.Y}[10]{C.Reset} PoC Generator
    {C.Y}[11]{C.Reset} WAF Bypass
    {C.Y}[12]{C.Reset} Blind SQL Detector
    {C.Y}[13]{C.Reset} Session Scanner
    {C.Y}[14]{C.Reset} Recursive Crawler
    {C.Y}[15]{C.Reset} Chain Detector
    {C.Y}[16]{C.Reset} Verification Engine
    {C.Y}[17]{C.Reset} Smart Fuzzer
    {C.Y}[18]{C.Reset} OOB Listener

{C.G}    [ REPORTS ]{C.Reset}
    {C.Y}[19]{C.Reset} Generate HTML Report
    {C.Y}[20]{C.Reset} Generate JSON Report
    {C.Y}[21]{C.Reset} CVSS Calculator
    {C.Y}[22]{C.Reset} OWASP Mapping

{C.G}    [ TOOLS ]{C.Reset}
    {C.Y}[23]{C.Reset} Subdomain Finder
    {C.Y}[24]{C.Reset} Port Scanner
    {C.Y}[25]{C.Reset} DNS Lookup
    {C.Y}[26]{C.Reset} Whois Lookup
    {C.Y}[27]{C.Reset} SSL Checker
    {C.Y}[28]{C.Reset} Technology Detector

{C.G}    [ SYSTEM ]{C.Reset}
    {C.Y}[29]{C.Reset} Scan History
    {C.Y}[30]{C.Reset} Hacker Diary
    {C.Y}[31]{C.Reset} Export Data
    {C.Y}[32]{C.Reset} Settings
    {C.Y}[33]{C.Reset} About
    {C.Y}[0]{C.Reset}  Exit
""")

def get_target():
    target = input(f"{C.Cy}[?] Target URL/IP: {C.Reset}").strip()
    if not target:
        print(f"{C.R}[-] No target specified{C.Reset}")
        return None
    return target

def run_quick_scan(db, scanner):
    target = get_target()
    if not target:
        return
    
    scan_id = db.create_scan(target, "quick")
    print(f"{C.Cy}[*] Scan ID: {scan_id}{C.Reset}")
    
    vulns = scanner.quick_scan(target, scan_id)
    
    db.update_scan(scan_id, "completed", json.dumps([v["type"] for v in vulns]), len(vulns))
    
    print(f"\n{C.G}[+] Quick Scan Complete!{C.Reset}")
    print(f"{C.G}[+] Found {len(vulns)} vulnerabilities{C.Reset}")

def run_deep_scan(db, scanner):
    target = get_target()
    if not target:
        return
    
    scan_id = db.create_scan(target, "deep")
    print(f"{C.Cy}[*] Scan ID: {scan_id}{C.Reset}")
    
    vulns = scanner.deep_scan(target, scan_id)
    
    db.update_scan(scan_id, "completed", json.dumps([v["type"] for v in vulns]), len(vulns))
    
    print(f"\n{C.G}[+] Deep Scan Complete!{C.Reset}")
    print(f"{C.G}[+] Found {len(vulns)} vulnerabilities{C.Reset}")

def run_report(db, report_gen):
    scans = db.get_all_scans()
    if not scans:
        print(f"{C.R}[-] No scans found{C.Reset}")
        return
    
    print(f"\n{C.Cy}[ Recent Scans ]{C.Reset}")
    for s in scans[:10]:
        print(f"  [{s['id']}] {s['target']} - {s['status']} ({s['vuln_count']} vulns)")
    
    try:
        scan_id = int(input(f"{C.Cy}[?] Scan ID: {C.Reset}"))
        filename = report_gen.generate_html(scan_id)
        print(f"{C.G}[+] Report saved: {filename}{C.Reset}")
    except Exception as e:
        print(f"{C.R}[-] Error: {e}{C.Reset}")

def show_history(db):
    scans = db.get_all_scans()
    if not scans:
        print(f"{C.R}[-] No scans found{C.Reset}")
        return
    
    print(f"\n{C.Cy}{C.Bold}[ SCAN HISTORY ]{C.Reset}")
    print(f"{C.W}{'='*60}{C.Reset}")
    print(f"  {'ID':<6} {'Target':<30} {'Type':<8} {'Status':<10} {'Vulns':<6}")
    print(f"  {'-'*60}")
    
    for s in scans:
        color = C.G if s["status"] == "completed" else C.Y
        print(f"  {s['id']:<6} {s['target'][:28]:<30} {s['scan_type']:<8} {color}{s['status']:<10}{C.Reset} {s['vuln_count']:<6}")

def show_about():
    print(f"""
{C.Cy}{C.Bold}    MohacWeb v3.0 - Advanced Web Security Scanner{C.Reset}
{C.W}    ================================================{C.Reset}

    {C.G}Features:{C.Reset}
    - 5-Layer Deep Scanning
    - AI Hacker Brain (5 phases)
    - PoC Generator (15+ types)
    - WAF Bypass (25+ techniques)
    - Blind SQL Detection
    - Session-based Scanning
    - Recursive Crawling
    - Vulnerability Chain Detection
    - False Positive Elimination
    - Smart Mutation Fuzzing
    - OOB Callback Server
    
    {C.G}Modules:{C.Reset}
    - SQL Injection (Error/Blind/Time/Union)
    - XSS (Reflected/Stored/DOM)
    - CSRF Detection
    - SSRF Detection
    - XXE Detection
    - Open Redirect
    - CORS Misconfiguration
    - Security Headers
    - SSL/TLS Analysis
    - Sensitive Data Exposure
    
    {C.G}Reporting:{C.Reset}
    - HTML Reports with CVSS Scores
    - JSON Export
    - OWASP Top 10 Mapping
    - Hacker Diary
    
    {C.Y}Target: Kali Linux / Termux / Any Python 3.7+{C.Reset}
""")

def main():
    db = Database()
    scanner = Scanner(db)
    report_gen = ReportGenerator(db)
    
    show_banner()
    
    while True:
        show_menu()
        
        try:
            choice = input(f"{C.Cy}[?] Select option: {C.Reset}").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{C.G}[+] Goodbye!{C.Reset}")
            break
        
        if choice == "1":
            run_quick_scan(db, scanner)
        elif choice == "2":
            run_deep_scan(db, scanner)
        elif choice == "3":
            print(f"{C.Y}[*] Custom Scan - Coming Soon{C.Reset}")
        elif choice == "4":
            print(f"{C.Y}[*] Auth Scan - Coming Soon{C.Reset}")
        elif choice == "5":
            print(f"{C.Y}[*] AI Recon - Coming Soon{C.Reset}")
        elif choice == "6":
            print(f"{C.Y}[*] AI Mapping - Coming Soon{C.Reset}")
        elif choice == "7":
            print(f"{C.Y}[*] AI Vuln Discovery - Coming Soon{C.Reset}")
        elif choice == "8":
            print(f"{C.Y}[*] AI Exploitation - Coming Soon{C.Reset}")
        elif choice == "9":
            print(f"{C.Y}[*] Full AI Hack - Coming Soon{C.Reset}")
        elif choice == "10":
            print(f"{C.Y}[*] PoC Generator - Coming Soon{C.Reset}")
        elif choice == "11":
            print(f"{C.Y}[*] WAF Bypass - Coming Soon{C.Reset}")
        elif choice == "12":
            print(f"{C.Y}[*] Blind SQL Detector - Coming Soon{C.Reset}")
        elif choice == "13":
            print(f"{C.Y}[*] Session Scanner - Coming Soon{C.Reset}")
        elif choice == "14":
            print(f"{C.Y}[*] Recursive Crawler - Coming Soon{C.Reset}")
        elif choice == "15":
            print(f"{C.Y}[*] Chain Detector - Coming Soon{C.Reset}")
        elif choice == "16":
            print(f"{C.Y}[*] Verification Engine - Coming Soon{C.Reset}")
        elif choice == "17":
            print(f"{C.Y}[*] Smart Fuzzer - Coming Soon{C.Reset}")
        elif choice == "18":
            print(f"{C.Y}[*] OOB Listener - Coming Soon{C.Reset}")
        elif choice == "19":
            run_report(db, report_gen)
        elif choice == "20":
            print(f"{C.Y}[*] JSON Export - Coming Soon{C.Reset}")
        elif choice == "21":
            print(f"{C.Y}[*] CVSS Calculator - Coming Soon{C.Reset}")
        elif choice == "22":
            print(f"{C.Y}[*] OWASP Mapping - Coming Soon{C.Reset}")
        elif choice == "23":
            print(f"{C.Y}[*] Subdomain Finder - Coming Soon{C.Reset}")
        elif choice == "24":
            print(f"{C.Y}[*] Port Scanner - Coming Soon{C.Reset}")
        elif choice == "25":
            print(f"{C.Y}[*] DNS Lookup - Coming Soon{C.Reset}")
        elif choice == "26":
            print(f"{C.Y}[*] Whois Lookup - Coming Soon{C.Reset}")
        elif choice == "27":
            print(f"{C.Y}[*] SSL Checker - Coming Soon{C.Reset}")
        elif choice == "28":
            print(f"{C.Y}[*] Tech Detector - Coming Soon{C.Reset}")
        elif choice == "29":
            show_history(db)
        elif choice == "30":
            print(f"{C.Y}[*] Hacker Diary - Coming Soon{C.Reset}")
        elif choice == "31":
            print(f"{C.Y}[*] Export Data - Coming Soon{C.Reset}")
        elif choice == "32":
            print(f"{C.Y}[*] Settings - Coming Soon{C.Reset}")
        elif choice == "33":
            show_about()
        elif choice == "0":
            print(f"{C.G}[+] Goodbye! Happy Hacking!{C.Reset}")
            break
        else:
            print(f"{C.R}[-] Invalid option{C.Reset}")
        
        input(f"\n{C.Dim}Press Enter to continue...{C.Reset}")

if __name__ == "__main__":
    main()
