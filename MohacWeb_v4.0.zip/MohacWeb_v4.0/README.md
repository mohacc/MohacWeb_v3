# MohacWeb v4.0 - Full Working Security Scanner

## Quick Start
```bash
python3 MohacWeb.py
```

## No Installation Required
- Python 3.7+ only
- No pip install needed
- All modules built-in

## Features (ALL WORKING - No Coming Soon!)
1. Quick Scan (Headers, Paths, Cookies, Sensitive Data)
2. SQL Injection Scan
3. XSS Scan (Reflected)
4. Path Traversal Scan
5. Command Injection Scan
6. Open Redirect Scan
7. SSL/TLS Scan
8. Port Scanner (24 common ports)
9. Subdomain Scanner (29 subdomains)
10. WAF Detection (7 WAF types)
11. Full Scan (ALL 7 modules)
12. Deep Crawler + Scan
13. Recon + Full Scan (4 phases)
14. View Scan History
15. View Scan Details
16. Generate HTML Report (dark theme)
17. View Statistics
18. Help

## Test Target
http://testphp.vulnweb.com
