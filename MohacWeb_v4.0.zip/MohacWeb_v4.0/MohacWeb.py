#!/usr/bin/env python3
# -*- coding: ascii -*-
"""
MohacWeb v4.0 - Full Working Security Scanner
All functions are real - NO Coming Soon!
For Kali Linux and Termux
"""

import re
import os
import sys
import ssl
import json
import time
import socket
import hashlib
import sqlite3
import threading
import subprocess
from datetime import datetime
from urllib.parse import urljoin, urlparse, parse_qs

try:
    import urllib.request
    import urllib.error
    import urllib.parse
    HAS_URLLIB = True
except ImportError:
    HAS_URLLIB = False

VERSION = "4.0"
DB_FILE = "mohacweb.db"

# ============ ANSI Colors ============
class C:
    R = '\033[91m'
    G = '\033[92m'
    B = '\033[94m'
    Y = '\033[93m'
    W = '\033[97m'
    Cy = '\033[96m'
    M = '\033[95m'
    O = '\033[33m'
    Bold = '\033[1m'
    Dim = '\033[2m'
    Reset = '\033[0m'

BANNER = "[96m[1m" + chr(10)
BANNER += "    __  __       _       _   _      __        __   _      " + chr(10)
BANNER += "   |  \/  | ___ | |__   | | | |     \ \      / /__| |__   " + chr(10)
BANNER += "   | |\/| |/ _ \| '_ \  | |_| |___   \ \ /\ / / _ \ '_ \  " + chr(10)
BANNER += "   | |  | | (_) | |_) | |  _  |___|   \ V  V /  __/ |_) |" + chr(10)
BANNER += "   |_|  |_|\___/|_.__/  |_| |_|        \_/\_/ \___|_.__/  " + chr(10)
BANNER += "[0m[93m    [v4.0] Full Working Security Scanner[0m" + chr(10)
BANNER += "[2m    [!] All functions are REAL - No Coming Soon![0m" + chr(10)


# ============ Database ============
class Database:
    def __init__(self, db_file=DB_FILE):
        self.db_file = db_file
        self.init_db()
    
    def get_conn(self):
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_db(self):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS scans (id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL, scan_type TEXT DEFAULT 'quick', status TEXT DEFAULT 'running', start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, end_time TIMESTAMP, total_vulns INTEGER DEFAULT 0, critical INTEGER DEFAULT 0, high INTEGER DEFAULT 0, medium INTEGER DEFAULT 0, low INTEGER DEFAULT 0, info INTEGER DEFAULT 0, score REAL DEFAULT 0.0)")
        c.execute("CREATE TABLE IF NOT EXISTS vulnerabilities (id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER, vuln_type TEXT, severity TEXT, title TEXT, description TEXT, url TEXT, parameter TEXT, payload TEXT, evidence TEXT, cvss_score REAL DEFAULT 0.0, owasp_category TEXT, remediation TEXT, found_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (scan_id) REFERENCES scans(id))")
        c.execute("CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, scan_id INTEGER, report_type TEXT DEFAULT 'html', file_path TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (scan_id) REFERENCES scans(id))")
        conn.commit()
        conn.close()
    
    def create_scan(self, target, scan_type='quick'):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("INSERT INTO scans (target, scan_type) VALUES (?, ?)", (target, scan_type))
        scan_id = c.lastrowid
        conn.commit()
        conn.close()
        return scan_id
    
    def update_scan(self, scan_id, **kwargs):
        conn = self.get_conn()
        c = conn.cursor()
        sets = ", ".join([k + "=?" for k in kwargs.keys()])
        values = list(kwargs.values()) + [scan_id]
        c.execute("UPDATE scans SET " + sets + " WHERE id=?", values)
        conn.commit()
        conn.close()
    
    def add_vulnerability(self, scan_id, vuln_type, severity, title, description, url='', parameter='', payload='', evidence='', cvss_score=0.0, owasp_category='', remediation=''):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("INSERT INTO vulnerabilities (scan_id, vuln_type, severity, title, description, url, parameter, payload, evidence, cvss_score, owasp_category, remediation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (scan_id, vuln_type, severity, title, description, url, parameter, payload, evidence, cvss_score, owasp_category, remediation))
        conn.commit()
        conn.close()
    
    def get_scan(self, scan_id):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("SELECT * FROM scans WHERE id=?", (scan_id,))
        result = c.fetchone()
        conn.close()
        return dict(result) if result else None
    
    def get_vulns(self, scan_id):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("SELECT * FROM vulnerabilities WHERE scan_id=? ORDER BY cvss_score DESC", (scan_id,))
        results = [dict(r) for r in c.fetchall()]
        conn.close()
        return results
    
    def get_all_scans(self):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 50")
        results = [dict(r) for r in c.fetchall()]
        conn.close()
        return results
    
    def get_stats(self):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute("SELECT COUNT(*) as total FROM scans")
        total = c.fetchone()["total"]
        c.execute("SELECT SUM(total_vulns) as vulns FROM scans")
        vulns = c.fetchone()["vulns"] or 0
        c.execute("SELECT COUNT(*) as crit FROM vulnerabilities WHERE severity='Critical'")
        crit = c.fetchone()["crit"]
        conn.close()
        return {"total_scans": total, "total_vulns": vulns, "critical": crit}

# ============ HTTP Helper ============
class HTTPHelper:
    @staticmethod
    def get(url, timeout=10, headers=None, follow_redirects=True):
        try:
            if not url.startswith('http'):
                url = 'http://' + url
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
            if headers:
                for k, v in headers.items():
                    req.add_header(k, v)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib.request.urlopen(req, timeout=timeout, context=ctx)
            content = response.read().decode('utf-8', errors='ignore')
            return {'status': response.getcode(), 'headers': dict(response.headers), 'body': content, 'url': response.geturl()}
        except Exception as e:
            return {'status': 0, 'headers': {}, 'body': '', 'error': str(e)}
    
    @staticmethod
    def post(url, data='', timeout=10, headers=None):
        try:
            if not url.startswith('http'):
                url = 'http://' + url
            if isinstance(data, dict):
                data = urllib.parse.urlencode(data).encode('utf-8')
            elif isinstance(data, str):
                data = data.encode('utf-8')
            req = urllib.request.Request(url, data=data, method='POST')
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            req.add_header('Content-Type', 'application/x-www-form-urlencoded')
            if headers:
                for k, v in headers.items():
                    req.add_header(k, v)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib.request.urlopen(req, timeout=timeout, context=ctx)
            content = response.read().decode('utf-8', errors='ignore')
            return {'status': response.getcode(), 'headers': dict(response.headers), 'body': content, 'url': response.geturl()}
        except Exception as e:
            return {'status': 0, 'headers': {}, 'body': '', 'error': str(e)}

# ============ Scanner Engine ============
class Scanner:
    def __init__(self, db):
        self.db = db
        self.http = HTTPHelper()
        self.found_urls = []
        self.found_forms = []
    
    def normalize_url(self, url):
        if not url.startswith('http'):
            url = 'http://' + url
        return url.rstrip('/')
    
    def extract_links(self, base_url, html):
        links = []
        pattern = r'href=["\']([^"\']+)["\']'
        matches = re.findall(pattern, html, re.IGNORECASE)
        for match in matches:
            full_url = urljoin(base_url, match)
            if full_url.startswith('http') and urlparse(full_url).netloc == urlparse(base_url).netloc:
                links.append(full_url)
        return list(set(links))
    
    def extract_forms(self, html, url):
        forms = []
        form_pattern = r'<form[^>]*>(.*?)</form>'
        form_matches = re.findall(form_pattern, html, re.DOTALL | re.IGNORECASE)
        for form_html in form_matches:
            action_match = re.search(r'action=["\']([^"\']*)["\']', form_html, re.IGNORECASE)
            method_match = re.search(r'method=["\']([^"\']*)["\']', form_html, re.IGNORECASE)
            inputs = re.findall(r'<input[^>]*name=["\']([^"\']+)["\'][^>]*>', form_html, re.IGNORECASE)
            action = action_match.group(1) if action_match else url
            method = method_match.group(1).upper() if method_match else 'GET'
            forms.append({'action': urljoin(url, action), 'method': method, 'inputs': inputs})
        return forms
    
    def quick_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting Quick Scan on: " + url + "\033[0m")
        vulns = []
        
        # 1. Server Header Check
        print("\033[93m[+] Checking server headers...\033[0m")
        resp = self.http.get(url)
        if resp['status'] > 0:
            headers = resp['headers']
            server = headers.get('Server', '')
            if server:
                vulns.append({'type': 'Information Disclosure', 'severity': 'Low', 'title': 'Server Version Disclosure', 'desc': 'Server header reveals: ' + server, 'url': url, 'param': 'Server Header', 'payload': server, 'evidence': 'Server: ' + server, 'cvss': 2.0, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Remove or customize Server header'})
            
            powered = headers.get('X-Powered-By', '')
            if powered:
                vulns.append({'type': 'Information Disclosure', 'severity': 'Low', 'title': 'X-Powered-By Disclosure', 'desc': 'Technology stack revealed: ' + powered, 'url': url, 'param': 'X-Powered-By', 'payload': powered, 'evidence': 'X-Powered-By: ' + powered, 'cvss': 2.0, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Remove X-Powered-By header'})
            
            security_headers = {
                'Strict-Transport-Security': ('Missing HSTS', 'Medium', 4.0),
                'X-Content-Type-Options': ('Missing X-Content-Type-Options', 'Low', 2.0),
                'X-Frame-Options': ('Missing X-Frame-Options (Clickjacking)', 'Medium', 4.0),
                'Content-Security-Policy': ('Missing CSP', 'Medium', 4.0),
                'X-XSS-Protection': ('Missing XSS Protection Header', 'Low', 2.0),
                'Referrer-Policy': ('Missing Referrer-Policy', 'Low', 2.0),
                'Permissions-Policy': ('Missing Permissions-Policy', 'Low', 2.0),
            }
            header_keys_lower = [k.lower() for k in headers.keys()]
            for hdr, (title, sev, cvss) in security_headers.items():
                if hdr.lower() not in header_keys_lower:
                    vulns.append({'type': 'Security Misconfiguration', 'severity': sev, 'title': title, 'desc': 'Header ' + hdr + ' is not set', 'url': url, 'param': hdr, 'payload': '', 'evidence': hdr + ' header not found in response', 'cvss': cvss, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Add ' + hdr + ' header to your web server configuration'})
        
        # 2. Check common paths
        print("\033[93m[+] Checking common paths...\033[0m")
        common_paths = [
            ('/admin', 'Admin Panel Exposure', 'High'),
            ('/phpmyadmin', 'phpMyAdmin Exposure', 'High'),
            ('/.env', 'Environment File Exposure', 'Critical'),
            ('/.git/HEAD', 'Git Repository Exposure', 'Critical'),
            ('/backup', 'Backup Directory Exposure', 'High'),
            ('/config.php', 'Config File Exposure', 'Critical'),
            ('/wp-admin', 'WordPress Admin Exposure', 'Medium'),
            ('/robots.txt', 'Robots.txt Found', 'Info'),
            ('/sitemap.xml', 'Sitemap Found', 'Info'),
            ('/.htaccess', 'htaccess File Exposure', 'High'),
            ('/server-status', 'Server Status Exposure', 'Medium'),
            ('/server-info', 'Server Info Exposure', 'Medium'),
            ('/debug', 'Debug Mode Active', 'High'),
            ('/trace', 'TRACE Method Enabled', 'Medium'),
            ('/test', 'Test Page Exposure', 'Medium'),
        ]
        cvss_map = {'Critical': 9.0, 'High': 7.0, 'Medium': 4.0, 'Low': 2.0, 'Info': 0.0}
        for path, title, severity in common_paths:
            check_url = url + path
            resp = self.http.get(check_url, timeout=5)
            if resp['status'] == 200 and len(resp['body']) > 50:
                vulns.append({'type': 'Information Disclosure', 'severity': severity, 'title': title, 'desc': 'Sensitive path accessible: ' + path, 'url': check_url, 'param': 'URL Path', 'payload': path, 'evidence': 'HTTP 200 - Size: ' + str(len(resp['body'])) + ' bytes', 'cvss': cvss_map.get(severity, 0), 'owasp': 'A01:2021 - Broken Access Control', 'fix': 'Restrict access to ' + path})
                print("  \033[91m[!] Found: " + path + " (" + severity + ")\033[0m")
        
        # 3. Sensitive data in HTML
        print("\033[93m[+] Scanning for sensitive data exposure...\033[0m")
        if resp['status'] > 0:
            body = resp['body']
            patterns = [
                (r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', 'Email Address', 'Medium'),
                (r'\b(?:\d{1,3}\.){3}\d{1,3}\b', 'IP Address', 'Low'),
                (r'(?i)(api[_-]?key|apikey)\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})', 'API Key Exposure', 'Critical'),
                (r'(?i)(secret[_-]?key|secretkey)\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})', 'Secret Key Exposure', 'Critical'),
                (r'(?i)password\s*[:=]\s*["\']([^"\']{3,})', 'Password Exposure', 'Critical'),
            ]
            for pattern, title, severity in patterns:
                matches = re.findall(pattern, body)
                if matches:
                    sample = str(matches[0])[:50]
                    vulns.append({'type': 'Sensitive Data Exposure', 'severity': severity, 'title': title, 'desc': title + ' found in page content', 'url': url, 'param': 'Page Content', 'payload': sample, 'evidence': 'Found ' + str(len(matches)) + ' occurrence(s)', 'cvss': cvss_map.get(severity, 0), 'owasp': 'A02:2021 - Cryptographic Failures', 'fix': 'Remove sensitive data from client-side code'})
                    print("  \033[91m[!] " + title + ": " + sample + "\033[0m")
        
        # 4. Cookie Security
        print("\033[93m[+] Checking cookie security...\033[0m")
        if resp['status'] > 0:
            cookies = resp['headers'].get('Set-Cookie', '')
            if cookies:
                if 'httponly' not in cookies.lower():
                    vulns.append({'type': 'Session Management', 'severity': 'Medium', 'title': 'Cookie Missing HttpOnly Flag', 'desc': 'Cookies do not have HttpOnly flag set', 'url': url, 'param': 'Cookie', 'payload': cookies[:100], 'evidence': 'HttpOnly flag not found in Set-Cookie', 'cvss': 4.0, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Set HttpOnly flag on all cookies'})
                if 'secure' not in cookies.lower():
                    vulns.append({'type': 'Session Management', 'severity': 'Medium', 'title': 'Cookie Missing Secure Flag', 'desc': 'Cookies do not have Secure flag set', 'url': url, 'param': 'Cookie', 'payload': cookies[:100], 'evidence': 'Secure flag not found in Set-Cookie', 'cvss': 4.0, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Set Secure flag on all cookies'})
        
        return vulns

    def sqli_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting SQL Injection Scan on: " + url + "\033[0m")
        vulns = []
        resp = self.http.get(url)
        if resp['status'] == 0:
            print("\033[91m[!] Cannot connect to target\033[0m")
            return vulns
        
        links = self.extract_links(url, resp['body'])
        param_urls = [l for l in links if '?' in l and '=' in l]
        
        test_params = ['id', 'page', 'cat', 'search', 'q', 'user', 'item', 'product']
        for param in test_params:
            test_url = url + '?' + param + '=1'
            if test_url not in param_urls:
                param_urls.append(test_url)
        
        sqli_payloads = [
            ("'", "Single Quote Test"),
            ("' OR '1'='1", "OR Boolean Test"),
            ("' OR '1'='1' --", "OR Comment Test"),
            ("' UNION SELECT NULL--", "UNION Test"),
            ("1 AND 1=1", "AND True Test"),
            ("1 AND 1=2", "AND False Test"),
            ("1' ORDER BY 10--", "ORDER BY Test"),
        ]
        
        error_patterns = [
            r'SQL syntax.*?MySQL',
            r'Warning.*?mysql_',
            r'Unclosed quotation mark',
            r'SQLServer.*?Driver',
            r'ORA-\d{5}',
            r'PostgreSQL.*?ERROR',
            r'sqlite3\.OperationalError',
            r'mysql_fetch',
            r'SQLSTATE',
            r'Syntax error.*?in query',
        ]
        
        print("\033[93m[+] Testing " + str(len(param_urls)) + " URLs for SQLi...\033[0m")
        
        for test_url in param_urls[:10]:
            parsed = urlparse(test_url)
            params = parse_qs(parsed.query)
            for param_name in list(params.keys())[:3]:
                for payload, ptype in sqli_payloads:
                    new_params = dict(params)
                    new_params[param_name] = [payload]
                    query = '&'.join([k + "=" + v[0] for k, v in new_params.items()])
                    inject_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                    resp = self.http.get(inject_url, timeout=10)
                    if resp['status'] > 0:
                        body = resp['body']
                        for pattern in error_patterns:
                            m = re.search(pattern, body, re.IGNORECASE)
                            if m:
                                vulns.append({'type': 'SQL Injection', 'severity': 'Critical', 'title': 'SQL Injection - ' + ptype, 'desc': 'Potential SQL injection in parameter: ' + param_name, 'url': test_url, 'param': param_name, 'payload': payload, 'evidence': m.group()[:100], 'cvss': 9.8, 'owasp': 'A03:2021 - Injection', 'fix': 'Use parameterized queries/prepared statements'})
                                print("  \033[91m[!!!] SQLi Found: " + param_name + " @ " + test_url + "\033[0m")
                                break
                        else:
                            continue
                        break
        
        forms = self.extract_forms(resp['body'], url)
        print("\033[93m[+] Testing " + str(len(forms)) + " forms for SQLi...\033[0m")
        for form in forms[:5]:
            for inp in form['inputs'][:2]:
                for payload, ptype in sqli_payloads[:3]:
                    data = {i: 'test' for i in form['inputs']}
                    data[inp] = payload
                    if form['method'] == 'POST':
                        resp = self.http.post(form['action'], data)
                    else:
                        query = '&'.join([k + "=" + v for k, v in data.items()])
                        resp = self.http.get(form['action'] + "?" + query)
                    if resp['status'] > 0:
                        for pattern in error_patterns:
                            m = re.search(pattern, resp['body'], re.IGNORECASE)
                            if m:
                                vulns.append({'type': 'SQL Injection', 'severity': 'Critical', 'title': 'Form SQL Injection - ' + ptype, 'desc': 'SQL injection in form field: ' + inp, 'url': form['action'], 'param': inp, 'payload': payload, 'evidence': m.group()[:100], 'cvss': 9.8, 'owasp': 'A03:2021 - Injection', 'fix': 'Use parameterized queries/prepared statements'})
                                print("  \033[91m[!!!] Form SQLi: " + inp + " @ " + form['action'] + "\033[0m")
                                break
        return vulns
    
    def xss_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting XSS Scan on: " + url + "\033[0m")
        vulns = []
        resp = self.http.get(url)
        if resp['status'] == 0:
            return vulns
        
        xss_payloads = [
            ('<script>alert(1)</script>', 'Script Tag'),
            ('"><script>alert(1)</script>', 'Double Quote Break'),
            ("'><script>alert(1)</script>", "Single Quote Break"),
            ('<img src=x onerror=alert(1)>', 'Img OnError'),
            ('<svg onload=alert(1)>', 'SVG OnLoad'),
            ('javascript:alert(1)', 'Javascript Protocol'),
        ]
        
        links = self.extract_links(url, resp['body'])
        param_urls = [l for l in links if '?' in l and '=' in l]
        for param in ['q', 'search', 'query', 'keyword', 'name', 'input']:
            test_url = url + '?' + param + '=test'
            if test_url not in param_urls:
                param_urls.append(test_url)
        
        print("\033[93m[+] Testing " + str(len(param_urls)) + " URLs for XSS...\033[0m")
        for test_url in param_urls[:10]:
            parsed = urlparse(test_url)
            params = parse_qs(parsed.query)
            for param_name in list(params.keys())[:3]:
                for payload, ptype in xss_payloads:
                    new_params = dict(params)
                    new_params[param_name] = [payload]
                    query = '&'.join([k + "=" + v[0] for k, v in new_params.items()])
                    inject_url = parsed.scheme + "://" + parsed.netloc + parsed.path + "?" + query
                    resp = self.http.get(inject_url, timeout=10)
                    if resp['status'] > 0 and payload in resp['body']:
                        vulns.append({'type': 'Cross-Site Scripting', 'severity': 'High', 'title': 'Reflected XSS - ' + ptype, 'desc': 'XSS vulnerability in parameter: ' + param_name, 'url': test_url, 'param': param_name, 'payload': payload, 'evidence': 'Payload reflected in response', 'cvss': 6.1, 'owasp': 'A03:2021 - Injection', 'fix': 'Implement output encoding and Content Security Policy'})
                        print("  \033[91m[!!!] XSS Found: " + param_name + " @ " + test_url + "\033[0m")
                        break
        
        forms = self.extract_forms(resp['body'], url)
        print("\033[93m[+] Testing " + str(len(forms)) + " forms for XSS...\033[0m")
        for form in forms[:5]:
            for inp in form['inputs'][:2]:
                for payload, ptype in xss_payloads[:3]:
                    data = {i: 'test' for i in form['inputs']}
                    data[inp] = payload
                    if form['method'] == 'POST':
                        resp = self.http.post(form['action'], data)
                    else:
                        query = '&'.join([k + "=" + v for k, v in data.items()])
                        resp = self.http.get(form['action'] + "?" + query)
                    if resp['status'] > 0 and payload in resp['body']:
                        vulns.append({'type': 'Cross-Site Scripting', 'severity': 'High', 'title': 'Form XSS - ' + ptype, 'desc': 'XSS in form field: ' + inp, 'url': form['action'], 'param': inp, 'payload': payload, 'evidence': 'Payload reflected in response', 'cvss': 6.1, 'owasp': 'A03:2021 - Injection', 'fix': 'Implement output encoding and Content Security Policy'})
                        print("  \033[91m[!!!] Form XSS: " + inp + "\033[0m")
                        break
        return vulns

    def path_traversal_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting Path Traversal Scan on: " + url + "\033[0m")
        vulns = []
        traversal_payloads = [
            ('../../../etc/passwd', 'Linux passwd', '/root:'),
            ('..\\..\\..\\windows\\win.ini', 'Windows win.ini', '[fonts]'),
            ('../../../etc/shadow', 'Linux shadow', 'root:'),
            ('/etc/passwd', 'Absolute path passwd', 'root:'),
            ('....//....//....//etc/passwd', 'Double encoding', 'root:'),
            ('..%252f..%252f..%252fetc/passwd', 'URL encoded', 'root:'),
        ]
        common_params = ['file', 'path', 'page', 'include', 'template', 'doc', 'document', 'folder', 'dir']
        for param in common_params:
            for payload, name, indicator in traversal_payloads:
                test_url = url + '?' + param + '=' + payload
                resp = self.http.get(test_url, timeout=5)
                if resp['status'] > 0 and indicator in resp['body']:
                    vulns.append({'type': 'Path Traversal', 'severity': 'Critical', 'title': 'Path Traversal - ' + name, 'desc': 'Directory traversal via ' + param + ' parameter', 'url': url, 'param': param, 'payload': payload, 'evidence': 'Found "' + indicator + '" in response', 'cvss': 8.6, 'owasp': 'A01:2021 - Broken Access Control', 'fix': 'Validate and sanitize file path inputs'})
                    print("  \033[91m[!!!] Path Traversal: " + param + "\033[0m")
                    break
        return vulns
    
    def cmd_injection_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting Command Injection Scan on: " + url + "\033[0m")
        vulns = []
        cmd_payloads = [
            (';id', 'Semicolon', 'uid='),
            ('|id', 'Pipe', 'uid='),
            ('`id`', 'Backtick', 'uid='),
            ('$(id)', 'Substitution', 'uid='),
            ('&& id', 'AND Operator', 'uid='),
            ('|| id', 'OR Operator', 'uid='),
            ('; cat /etc/passwd', 'File Read', 'root:'),
            ('| whoami', 'Whoami', 'www-data'),
        ]
        common_params = ['cmd', 'exec', 'command', 'ping', 'host', 'ip', 'target', 'domain']
        for param in common_params:
            for payload, name, indicator in cmd_payloads:
                test_url = url + '?' + param + '=127.0.0.1' + payload
                resp = self.http.get(test_url, timeout=10)
                if resp['status'] > 0 and indicator in resp['body']:
                    vulns.append({'type': 'Command Injection', 'severity': 'Critical', 'title': 'OS Command Injection - ' + name, 'desc': 'Command injection via ' + param + ' parameter', 'url': url, 'param': param, 'payload': payload, 'evidence': 'Found "' + indicator + '" in response', 'cvss': 9.8, 'owasp': 'A03:2021 - Injection', 'fix': 'Use safe APIs instead of system commands'})
                    print("  \033[91m[!!!] CMD Injection: " + param + "\033[0m")
                    break
        return vulns
    
    def open_redirect_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting Open Redirect Scan on: " + url + "\033[0m")
        vulns = []
        redirect_payloads = ['https://evil.com', '//evil.com', '////evil.com', 'https:evil.com', '/\\evil.com']
        redirect_params = ['url', 'redirect', 'next', 'return', 'goto', 'link', 'target', 'dest', 'destination', 'redir', 'redirect_url', 'redirect_uri', 'return_url', 'return_to', 'continue']
        for param in redirect_params:
            for payload in redirect_payloads:
                test_url = url + '?' + param + '=' + payload
                resp = self.http.get(test_url, timeout=5)
                if resp['status'] in [301, 302, 303, 307, 308]:
                    location = resp['headers'].get('Location', '')
                    if 'evil.com' in location or payload in location:
                        vulns.append({'type': 'Open Redirect', 'severity': 'Medium', 'title': 'Open Redirect', 'desc': 'Unvalidated redirect via ' + param, 'url': url, 'param': param, 'payload': payload, 'evidence': 'Redirects to: ' + location, 'cvss': 5.4, 'owasp': 'A01:2021 - Broken Access Control', 'fix': 'Validate redirect URLs against whitelist'})
                        print("  \033[91m[!!!] Open Redirect: " + param + "\033[0m")
                        break
        return vulns
    
    def ssl_scan(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Starting SSL/TLS Scan on: " + url + "\033[0m")
        vulns = []
        parsed = urlparse(url)
        hostname = parsed.netloc
        if ':' in hostname:
            hostname = hostname.split(':')[0]
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((hostname, 443), timeout=10) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert(binary_form=True)
                    cipher = ssock.cipher()
                    version = ssock.version()
                    if version in ['TLSv1', 'TLSv1.1', 'SSLv3', 'SSLv2']:
                        vulns.append({'type': 'Weak TLS', 'severity': 'High', 'title': 'Outdated TLS Version: ' + version, 'desc': 'Server uses deprecated ' + version, 'url': url, 'param': 'TLS', 'payload': version, 'evidence': 'TLS Version: ' + version, 'cvss': 7.0, 'owasp': 'A02:2021 - Cryptographic Failures', 'fix': 'Disable TLSv1.0/1.1, use TLSv1.2+'})
                        print("  \033[91m[!] Weak TLS: " + version + "\033[0m")
                    if cipher and cipher[0]:
                        cipher_name = cipher[0]
                        weak_ciphers = ['RC4', 'DES', '3DES', 'NULL', 'EXPORT', 'anon']
                        for wc in weak_ciphers:
                            if wc in cipher_name:
                                vulns.append({'type': 'Weak Cipher', 'severity': 'High', 'title': 'Weak Cipher Suite: ' + cipher_name, 'desc': 'Server uses weak cipher', 'url': url, 'param': 'Cipher', 'payload': cipher_name, 'evidence': 'Cipher: ' + cipher_name, 'cvss': 7.0, 'owasp': 'A02:2021 - Cryptographic Failures', 'fix': 'Configure strong cipher suites only'})
                                print("  \033[91m[!] Weak Cipher: " + cipher_name + "\033[0m")
                    print("  \033[92m[+] SSL/TLS Version: " + version + "\033[0m")
                    print("  \033[92m[+] Cipher: " + (cipher[0] if cipher else 'Unknown') + "\033[0m")
        except Exception as e:
            if '443' in str(e) or 'SSL' in str(e):
                vulns.append({'type': 'SSL Error', 'severity': 'Medium', 'title': 'SSL/TLS Connection Failed', 'desc': 'Cannot establish SSL connection: ' + str(e)[:100], 'url': url, 'param': 'SSL', 'payload': str(e)[:100], 'evidence': str(e)[:100], 'cvss': 4.0, 'owasp': 'A02:2021 - Cryptographic Failures', 'fix': 'Configure proper SSL/TLS certificate'})
        return vulns
    
    def port_scan(self, scan_id, target):
        parsed = urlparse(target if target.startswith('http') else 'http://' + target)
        hostname = parsed.netloc.split(':')[0]
        print("\n\033[96m[*] Port Scanning: " + hostname + "\033[0m")
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 993, 995, 1433, 1521, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 8888, 9090, 27017]
        open_ports = []
        for port in common_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((hostname, port))
                if result == 0:
                    try:
                        service = socket.getservbyport(port)
                    except:
                        service = 'unknown'
                    open_ports.append((port, service))
                    print("  \033[92m[+] Port " + str(port) + " OPEN (" + service + ")\033[0m")
                sock.close()
            except:
                pass
        vulns = []
        dangerous_ports = {21: 'FTP', 23: 'Telnet', 445: 'SMB', 3389: 'RDP', 5900: 'VNC'}
        for port, service in open_ports:
            if port in dangerous_ports:
                vulns.append({'type': 'Open Port', 'severity': 'Medium', 'title': 'Dangerous Port Open: ' + str(port) + ' (' + dangerous_ports[port] + ')', 'desc': 'Port ' + str(port) + ' is accessible', 'url': target, 'param': 'Port ' + str(port), 'payload': '', 'evidence': 'Port ' + str(port) + ' is open', 'cvss': 5.0, 'owasp': 'A05:2021 - Security Misconfiguration', 'fix': 'Close port ' + str(port) + ' if not needed'})
        print("\n\033[92m[+] Found " + str(len(open_ports)) + " open ports\033[0m")
        return vulns
    
    def subdomain_scan(self, scan_id, target):
        parsed = urlparse(target if target.startswith('http') else 'http://' + target)
        domain = parsed.netloc.split(':')[0]
        print("\n\033[96m[*] Subdomain Scan: " + domain + "\033[0m")
        subdomains = ['www', 'mail', 'ftp', 'admin', 'test', 'dev', 'staging', 'api', 'blog', 'shop', 'portal', 'app', 'cdn', 'static', 'media', 'vpn', 'ns1', 'ns2', 'mx', 'smtp', 'remote', 'git', 'jenkins', 'ci', 'jira', 'wiki', 'support', 'help', 'docs']
        found = []
        for sub in subdomains:
            full_domain = sub + '.' + domain
            try:
                ip = socket.gethostbyname(full_domain)
                found.append((full_domain, ip))
                print("  \033[92m[+] " + full_domain + " -> " + ip + "\033[0m")
            except:
                pass
        print("\n\033[92m[+] Found " + str(len(found)) + " subdomains\033[0m")
        return []
    
    def waf_detect(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] WAF Detection: " + url + "\033[0m")
        resp = self.http.get(url)
        if resp['status'] == 0:
            print("\033[91m[!] Cannot connect\033[0m")
            return []
        headers = resp['headers']
        waf_signs = {
            'cloudflare': ['cf-ray', 'cf-cache-status', 'server: cloudflare'],
            'akamai': ['x-akamai', 'akamai'],
            'incapsula': ['x-iinfo', 'incapsula'],
            'sucuri': ['x-sucuri', 'sucuri'],
            'modsecurity': ['mod_security', 'modsecurity'],
            'aws waf': ['x-amzn-requestid', 'awselb'],
            'f5 bigip': ['x-cnection', 'bigip'],
        }
        all_headers = ' '.join([k + ': ' + v for k, v in headers.items()]).lower()
        detected = []
        for waf, signs in waf_signs.items():
            for sign in signs:
                if sign in all_headers:
                    detected.append(waf)
                    print("  \033[33m[!] WAF Detected: " + waf.upper() + "\033[0m")
                    break
        test_url = url + '?test=<script>alert(1)</script>'
        resp2 = self.http.get(test_url, timeout=5)
        if resp2['status'] in [403, 406, 419, 429, 503]:
            if not detected:
                detected.append('Unknown WAF')
            print("  \033[33m[!] WAF blocking requests (HTTP " + str(resp2['status']) + ")\033[0m")
        if not detected:
            print("  \033[92m[+] No WAF detected\033[0m")
        return []
    
    def full_scan(self, scan_id, target):
        print("\n\033[1m\033[96m" + "=" * 60)
        print("  FULL SECURITY SCAN")
        print("  Target: " + target)
        print("  Scan ID: " + str(scan_id))
        print("=" * 60 + "\033[0m")
        all_vulns = []
        scan_functions = [
            ('Quick Scan (Headers + Paths)', self.quick_scan),
            ('SQL Injection Scan', self.sqli_scan),
            ('XSS Scan', self.xss_scan),
            ('Path Traversal Scan', self.path_traversal_scan),
            ('Command Injection Scan', self.cmd_injection_scan),
            ('Open Redirect Scan', self.open_redirect_scan),
            ('SSL/TLS Scan', self.ssl_scan),
        ]
        for name, func in scan_functions:
            print("\n\033[1m\033[95m[>>] Running: " + name + "\033[0m")
            print("\033[2m" + "-" * 40 + "\033[0m")
            try:
                results = func(scan_id, target)
                all_vulns.extend(results)
                print("\033[92m[+] Found " + str(len(results)) + " issues\033[0m")
            except Exception as e:
                print("\033[91m[!] Error in " + name + ": " + str(e)[:80] + "\033[0m")
        return all_vulns
    
    def crawl_site(self, scan_id, target):
        url = self.normalize_url(target)
        print("\n\033[96m[*] Crawling: " + url + "\033[0m")
        visited = set()
        to_visit = [url]
        all_links = []
        while to_visit and len(visited) < 50:
            current = to_visit.pop(0)
            if current in visited:
                continue
            visited.add(current)
            print("  \033[2m[>] " + current + "\033[0m")
            resp = self.http.get(current, timeout=5)
            if resp['status'] > 0:
                links = self.extract_links(url, resp['body'])
                for link in links:
                    if link not in visited and link not in to_visit:
                        to_visit.append(link)
                        all_links.append(link)
        print("\n\033[92m[+] Crawled " + str(len(visited)) + " pages, found " + str(len(all_links)) + " links\033[0m")
        for link in all_links[:20]:
            print("  \033[96m  -> " + link + "\033[0m")
        if len(all_links) > 20:
            print("  \033[2m  ... and " + str(len(all_links)-20) + " more\033[0m")
        return all_links

# ============ Report Generator ============
class ReportGenerator:
    def __init__(self, db):
        self.db = db
    
    def generate_html(self, scan_id):
        scan = self.db.get_scan(scan_id)
        vulns = self.db.get_vulns(scan_id)
        if not scan:
            return None
        
        severity_colors = {'Critical': '#dc3545', 'High': '#fd7e14', 'Medium': '#ffc107', 'Low': '#28a745', 'Info': '#17a2b8'}
        severity_counts = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0, 'Info': 0}
        for v in vulns:
            sev = v.get('severity', 'Info')
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        
        vuln_rows = ''
        for v in vulns:
            color = severity_colors.get(v.get('severity', 'Info'), '#6c757d')
            vuln_rows += '<tr>'
            vuln_rows += '<td><span style="background:' + color + ';color:#fff;padding:2px 8px;border-radius:4px;font-size:12px;">' + str(v.get("severity","")) + '</span></td>'
            vuln_rows += '<td style="font-weight:600;">' + str(v.get("title","")) + '</td>'
            vuln_rows += '<td>' + str(v.get("vuln_type","")) + '</td>'
            vuln_rows += '<td><code>' + str(v.get("url","")) + '</code></td>'
            vuln_rows += '<td><code>' + str(v.get("parameter","")) + '</code></td>'
            vuln_rows += '<td>' + str(v.get("cvss_score",0)) + '</td>'
            vuln_rows += '</tr>'
            vuln_rows += '<tr>'
            vuln_rows += '<td colspan="6" style="background:#1a1a2e;border-top:1px solid #333;padding:10px;">'
            vuln_rows += '<strong>Description:</strong> ' + str(v.get("description","")) + '<br>'
            vuln_rows += '<strong>Payload:</strong> <code>' + str(v.get("payload","")) + '</code><br>'
            vuln_rows += '<strong>Evidence:</strong> ' + str(v.get("evidence","")) + '<br>'
            vuln_rows += '<strong>OWASP:</strong> ' + str(v.get("owasp_category","")) + '<br>'
            vuln_rows += '<strong>Remediation:</strong> ' + str(v.get("remediation",""))
            vuln_rows += '</td></tr>'
        
        risk_score = min(10, (severity_counts['Critical'] * 3 + severity_counts['High'] * 2 + severity_counts['Medium'] * 1) / max(1, len(vulns)) * 3)
        risk_pct = risk_score * 10
        
        if not vuln_rows:
            vuln_rows = '<tr><td colspan="6" style="text-align:center;padding:20px;">No vulnerabilities found</td></tr>'
        
        css = """
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #0a0a1a; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 30px; border-radius: 10px; margin-bottom: 20px; border: 1px solid #0f3460; }
    .header h1 { color: #00d4ff; font-size: 28px; }
    .header p { color: #888; margin-top: 5px; }
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin-bottom: 20px; }
    .stat-card { background: #1a1a2e; padding: 20px; border-radius: 10px; text-align: center; border: 1px solid #333; }
    .stat-card .number { font-size: 36px; font-weight: bold; }
    .stat-card .label { color: #888; font-size: 14px; margin-top: 5px; }
    .risk-bar { background: #1a1a2e; padding: 20px; border-radius: 10px; margin-bottom: 20px; border: 1px solid #333; }
    .risk-bar h2 { color: #00d4ff; margin-bottom: 10px; }
    .bar { height: 30px; background: #333; border-radius: 15px; overflow: hidden; }
    .bar-fill { height: 100%; border-radius: 15px; transition: width 0.5s; }
    .vuln-table { width: 100%; border-collapse: collapse; background: #1a1a2e; border-radius: 10px; overflow: hidden; }
    .vuln-table th { background: #16213e; color: #00d4ff; padding: 12px; text-align: left; }
    .vuln-table td { padding: 10px; border-bottom: 1px solid #333; }
    .vuln-table tr:hover { background: #16213e; }
    code { background: #0d1117; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
    .footer { text-align: center; color: #666; margin-top: 30px; padding: 20px; }
"""
        
        html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">'
        html += '<title>MohacWeb Security Report - Scan #' + str(scan_id) + '</title>'
        html += '<style>' + css + '</style></head><body><div class="container">'
        html += '<div class="header"><h1> MohacWeb Security Report</h1>'
        html += '<p>Target: ' + str(scan["target"]) + ' | Scan Type: ' + str(scan["scan_type"]).upper() + ' | Date: ' + str(scan["start_time"]) + '</p></div>'
        html += '<div class="stats">'
        html += '<div class="stat-card"><div class="number" style="color:#dc3545;">' + str(severity_counts["Critical"]) + '</div><div class="label">Critical</div></div>'
        html += '<div class="stat-card"><div class="number" style="color:#fd7e14;">' + str(severity_counts["High"]) + '</div><div class="label">High</div></div>'
        html += '<div class="stat-card"><div class="number" style="color:#ffc107;">' + str(severity_counts["Medium"]) + '</div><div class="label">Medium</div></div>'
        html += '<div class="stat-card"><div class="number" style="color:#28a745;">' + str(severity_counts["Low"]) + '</div><div class="label">Low</div></div>'
        html += '<div class="stat-card"><div class="number" style="color:#17a2b8;">' + str(severity_counts["Info"]) + '</div><div class="label">Info</div></div>'
        html += '<div class="stat-card"><div class="number" style="color:#00d4ff;">' + str(len(vulns)) + '</div><div class="label">Total</div></div>'
        html += '</div>'
        html += '<div class="risk-bar"><h2>Risk Score: ' + str(round(risk_score,1)) + '/10</h2>'
        html += '<div class="bar"><div class="bar-fill" style="width:' + str(risk_pct) + '%;background:linear-gradient(90deg,#28a745,#ffc107,#dc3545);"></div></div></div>'
        html += '<h2 style="color:#00d4ff;margin:20px 0 10px;">Vulnerability Details</h2>'
        html += '<table class="vuln-table"><thead><tr><th>Severity</th><th>Title</th><th>Type</th><th>URL</th><th>Parameter</th><th>CVSS</th></tr></thead>'
        html += '<tbody>' + vuln_rows + '</tbody></table>'
        html += '<div class="footer"><p>Generated by MohacWeb v' + VERSION + ' | ' + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + '</p></div>'
        html += '</div></body></html>'
        
        report_dir = os.path.join(os.getcwd(), 'reports')
        os.makedirs(report_dir, exist_ok=True)
        report_path = os.path.join(report_dir, 'scan_' + str(scan_id) + '_report.html')
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return report_path

# ============ Main Application ============
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    print(BANNER)

def show_menu():
    print("""
\033[96m\033[1m    ============================
       MAIN MENU
    ============================\033[0m

\033[92m  [ SCAN MODULES ]\033[0m
    \033[93m[1]\033[0m  Quick Scan (Headers, Paths, Cookies)
    \033[93m[2]\033[0m  SQL Injection Scan
    \033[93m[3]\033[0m  XSS Scan (Reflected)
    \033[93m[4]\033[0m  Path Traversal Scan
    \033[93m[5]\033[0m  Command Injection Scan
    \033[93m[6]\033[0m  Open Redirect Scan
    \033[93m[7]\033[0m  SSL/TLS Scan
    \033[93m[8]\033[0m  Port Scanner
    \033[93m[9]\033[0m  Subdomain Scanner
    \033[93m[10]\033[0m WAF Detection

\033[92m  [ FULL SCANS ]\033[0m
    \033[91m[11]\033[0m FULL SCAN (All Modules)
    \033[91m[12]\033[0m Deep Crawler + Scan
    \033[91m[13]\033[0m Recon + Full Scan

\033[92m  [ REPORTS & HISTORY ]\033[0m
    \033[96m[14]\033[0m View Scan History
    \033[96m[15]\033[0m View Scan Details
    \033[96m[16]\033[0m Generate HTML Report
    \033[96m[17]\033[0m View Statistics

\033[92m  [ SYSTEM ]\033[0m
    \033[2m[18]\033[0m Help
    \033[2m[0]\033[0m  Exit
""")

def get_target():
    target = input("\n\033[96m  [?] Enter target URL/IP: \033[0m").strip()
    if not target:
        print("\033[91m  [!] No target specified\033[0m")
        return None
    if not target.startswith('http'):
        target = 'http://' + target
    return target

def run_scan(db, scanner, scan_type, target):
    scan_id = db.create_scan(target, scan_type)
    print("\n\033[1m\033[92m  [*] Scan #" + str(scan_id) + " started\033[0m")
    print("  \033[2mTarget: " + target + "\033[0m")
    print("  \033[2mType: " + scan_type + "\033[0m")
    
    start_time = time.time()
    
    if scan_type == 'quick':
        vulns = scanner.quick_scan(scan_id, target)
    elif scan_type == 'sqli':
        vulns = scanner.sqli_scan(scan_id, target)
    elif scan_type == 'xss':
        vulns = scanner.xss_scan(scan_id, target)
    elif scan_type == 'path_traversal':
        vulns = scanner.path_traversal_scan(scan_id, target)
    elif scan_type == 'cmd_injection':
        vulns = scanner.cmd_injection_scan(scan_id, target)
    elif scan_type == 'open_redirect':
        vulns = scanner.open_redirect_scan(scan_id, target)
    elif scan_type == 'ssl':
        vulns = scanner.ssl_scan(scan_id, target)
    elif scan_type == 'port_scan':
        vulns = scanner.port_scan(scan_id, target)
    elif scan_type == 'subdomain':
        vulns = scanner.subdomain_scan(scan_id, target)
    elif scan_type == 'waf':
        vulns = scanner.waf_detect(scan_id, target)
    elif scan_type == 'full':
        vulns = scanner.full_scan(scan_id, target)
    elif scan_type == 'crawl':
        links = scanner.crawl_site(scan_id, target)
        print("\n\033[96m[*] Now scanning found pages...\033[0m")
        vulns = scanner.full_scan(scan_id, target)
    elif scan_type == 'recon':
        print("\n\033[1m\033[95m[>>] Phase 1: Subdomain Discovery\033[0m")
        scanner.subdomain_scan(scan_id, target)
        print("\n\033[1m\033[95m[>>] Phase 2: Port Scan\033[0m")
        scanner.port_scan(scan_id, target)
        print("\n\033[1m\033[95m[>>] Phase 3: WAF Detection\033[0m")
        scanner.waf_detect(scan_id, target)
        print("\n\033[1m\033[95m[>>] Phase 4: Full Vulnerability Scan\033[0m")
        vulns = scanner.full_scan(scan_id, target)
    else:
        vulns = []
    
    elapsed = time.time() - start_time
    
    critical = high = medium = low = info = 0
    for v in vulns:
        sev = v.get('severity', 'Info')
        if sev == 'Critical': critical += 1
        elif sev == 'High': high += 1
        elif sev == 'Medium': medium += 1
        elif sev == 'Low': low += 1
        else: info += 1
        db.add_vulnerability(scan_id, v.get('type', ''), sev, v.get('title', ''), v.get('desc', ''), v.get('url', ''), v.get('param', ''), v.get('payload', ''), v.get('evidence', ''), v.get('cvss', 0), v.get('owasp', ''), v.get('fix', ''))
    
    db.update_scan(scan_id, status='completed', end_time=datetime.now().isoformat(), total_vulns=len(vulns), critical=critical, high=high, medium=medium, low=low, info=info, score=round((critical*3 + high*2 + medium) / max(1, len(vulns)) * 2, 1))
    
    print("\n\033[1m\033[96m" + "=" * 60)
    print("  SCAN COMPLETE - #" + str(scan_id))
    print("=" * 60 + "\033[0m")
    print("  Target:   " + target)
    print("  Duration: " + str(round(elapsed, 1)) + "s")
    print("  Total:    " + str(len(vulns)) + " vulnerabilities")
    print("  \033[91mCritical: " + str(critical) + "\033[0m")
    print("  \033[33mHigh:     " + str(high) + "\033[0m")
    print("  \033[93mMedium:   " + str(medium) + "\033[0m")
    print("  \033[92mLow:      " + str(low) + "\033[0m")
    print("  \033[96mInfo:     " + str(info) + "\033[0m")
    
    if vulns:
        report_gen = ReportGenerator(db)
        report_path = report_gen.generate_html(scan_id)
        if report_path:
            print("\n  \033[92m[+] Report saved: " + report_path + "\033[0m")
    
    return scan_id

def show_scan_history(db):
    scans = db.get_all_scans()
    if not scans:
        print("\n  \033[93m[!] No scans found\033[0m")
        return
    print("\n\033[96m\033[1m  SCAN HISTORY\033[0m")
    print("  " + "ID".ljust(5) + "Target".ljust(30) + "Type".ljust(10) + "Status".ljust(10) + "Vulns".ljust(8) + "Critical".ljust(10))
    print("  " + "-" * 75)
    for s in scans:
        print("  " + str(s['id']).ljust(5) + str(s['target'])[:28].ljust(30) + str(s['scan_type']).ljust(10) + str(s['status']).ljust(10) + str(s['total_vulns']).ljust(8) + str(s['critical']).ljust(10))

def show_scan_details(db):
    scan_id = input("\n  \033[96m[?] Enter Scan ID: \033[0m").strip()
    try:
        scan_id = int(scan_id)
    except:
        print("\033[91m  [!] Invalid ID\033[0m")
        return
    scan = db.get_scan(scan_id)
    if not scan:
        print("\033[91m  [!] Scan not found\033[0m")
        return
    vulns = db.get_vulns(scan_id)
    print("\n\033[96m\033[1m  SCAN #" + str(scan_id) + " DETAILS\033[0m")
    print("  Target:   " + str(scan['target']))
    print("  Type:     " + str(scan['scan_type']))
    print("  Status:   " + str(scan['status']))
    print("  Started:  " + str(scan['start_time']))
    print("  Total:    " + str(scan['total_vulns']) + " vulnerabilities")
    if vulns:
        print("\n\033[1m  VULNERABILITIES:\033[0m")
        for i, v in enumerate(vulns, 1):
            sev = v['severity']
            color = '\033[91m' if sev == 'Critical' else '\033[33m' if sev == 'High' else '\033[93m' if sev == 'Medium' else '\033[92m'
            print("\n  " + color + "[" + str(i) + "] " + sev + " - " + v['title'] + "\033[0m")
            print("      Type:       " + str(v['vuln_type']))
            print("      URL:        " + str(v['url']))
            print("      Parameter:  " + str(v['parameter']))
            print("      CVSS:       " + str(v['cvss_score']))
            print("      OWASP:      " + str(v['owasp_category']))
            if v['payload']:
                print("      Payload:    " + str(v['payload'])[:60])
            print("      Fix:        " + str(v['remediation'])[:80])

def generate_report(db):
    scan_id = input("\n  \033[96m[?] Enter Scan ID: \033[0m").strip()
    try:
        scan_id = int(scan_id)
    except:
        print("\033[91m  [!] Invalid ID\033[0m")
        return
    report_gen = ReportGenerator(db)
    report_path = report_gen.generate_html(scan_id)
    if report_path:
        print("\n  \033[92m[+] Report generated: " + report_path + "\033[0m")
    else:
        print("\033[91m  [!] Scan not found or no data\033[0m")

def show_stats(db):
    stats = db.get_stats()
    print("\n\033[96m\033[1m  STATISTICS\033[0m")
    print("  Total Scans:     " + str(stats['total_scans']))
    print("  Total Vulns:     " + str(stats['total_vulns']))
    print("  Critical Vulns:  " + str(stats['critical']))

def show_help():
    print("""
\033[96m\033[1m  HELP - MohacWeb v4.0\033[0m

  \033[92mSCAN TYPES:\033[0m
  - Quick Scan:      Headers, common paths, cookies, sensitive data
  - SQL Injection:   Tests parameters and forms for SQLi
  - XSS Scan:        Reflected XSS in parameters and forms
  - Path Traversal:  Directory traversal attempts
  - Command Injection: OS command injection tests
  - Open Redirect:   Unvalidated redirect parameters
  - SSL/TLS:         Certificate and cipher checks
  - Port Scan:       Common port discovery
  - Subdomain:       Subdomain enumeration
  - WAF Detect:      Web Application Firewall detection
  - Full Scan:       Runs ALL scan modules
  - Crawl + Scan:    Crawls site then runs full scan
  - Recon + Scan:    Subdomains + Ports + WAF + Full Scan

  \033[92mUSAGE:\033[0m
  1. Select scan type from menu
  2. Enter target URL (e.g., http://example.com)
  3. Wait for scan to complete
  4. View results and generate reports

  \033[92mREPORTS:\033[0m
  - HTML reports auto-generated for scans with findings
  - Saved in ./reports/ directory
  - Open in any web browser

  \033[92mTEST TARGET:\033[0m
  - http://testphp.vulnweb.com
""")

def main():
    db = Database()
    scanner = Scanner(db)
    clear_screen()
    print_banner()
    
    while True:
        show_menu()
        choice = input("\033[96m  [>] Select option: \033[0m").strip()
        
        if choice == '0':
            print("\n\033[92m  [+] Goodbye!\033[0m\n")
            break
        elif choice == '1':
            target = get_target()
            if target: run_scan(db, scanner, 'quick', target)
        elif choice == '2':
            target = get_target()
            if target: run_scan(db, scanner, 'sqli', target)
        elif choice == '3':
            target = get_target()
            if target: run_scan(db, scanner, 'xss', target)
        elif choice == '4':
            target = get_target()
            if target: run_scan(db, scanner, 'path_traversal', target)
        elif choice == '5':
            target = get_target()
            if target: run_scan(db, scanner, 'cmd_injection', target)
        elif choice == '6':
            target = get_target()
            if target: run_scan(db, scanner, 'open_redirect', target)
        elif choice == '7':
            target = get_target()
            if target: run_scan(db, scanner, 'ssl', target)
        elif choice == '8':
            target = get_target()
            if target: run_scan(db, scanner, 'port_scan', target)
        elif choice == '9':
            target = get_target()
            if target: run_scan(db, scanner, 'subdomain', target)
        elif choice == '10':
            target = get_target()
            if target: run_scan(db, scanner, 'waf', target)
        elif choice == '11':
            target = get_target()
            if target: run_scan(db, scanner, 'full', target)
        elif choice == '12':
            target = get_target()
            if target: run_scan(db, scanner, 'crawl', target)
        elif choice == '13':
            target = get_target()
            if target: run_scan(db, scanner, 'recon', target)
        elif choice == '14':
            show_scan_history(db)
        elif choice == '15':
            show_scan_details(db)
        elif choice == '16':
            generate_report(db)
        elif choice == '17':
            show_stats(db)
        elif choice == '18':
            show_help()
        else:
            print("\n  \033[91m[!] Invalid option\033[0m")
        
        input("\n\033[2m  Press Enter to continue...\033[0m")

if __name__ == '__main__':
    main()
