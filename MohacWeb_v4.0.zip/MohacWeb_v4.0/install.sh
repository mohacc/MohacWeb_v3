#!/bin/bash
echo "[*] MohacWeb v4.0 Setup"
echo "[+] No external dependencies required!"
echo "[+] Python 3.7+ only"
echo ""
echo "[*] Starting MohacWeb..."
python3 MohacWeb.py
