#!/usr/bin/env python3
"""
MohacWeb v3.0 - Advanced Web Security Scanner
Deep Scan Engine with PoC Generation & False Positive Elimination
"""

import os
import sys
import time
import json
import sqlite3
import re
import urllib.request
import urllib.error
from datetime import datetime
from urllib.parse import urlparse, urljoin, urlencode, parse_qs, urlunparse


# ============================================================
# ANSI Colors
# ============================================================
class C:
    R = "\033[91m"
    G = "\033[92m"
    Y = "\033[93m"
    B = "\033[94m"
    M = "\033[95m"
    Cy = "\033[96m"
    W = "\033[97m"
    N = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"


# ============================================================
# Database
# ============================================================
class Database:
    def __init__(self, db_path="mohacweb.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.create_tables()

    def create_tables(self):
        c = self.conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target TEXT NOT NULL, scan_type TEXT DEFAULT 'quick',
            status TEXT DEFAULT 'pending',
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP,
            total_vulns INTEGER DEFAULT 0,
            critical INTEGER DEFAULT 0, high INTEGER DEFAULT 0,
            medium INTEGER DEFAULT 0, low INTEGER DEFAULT 0,
            info INTEGER DEFAULT 0, report_path TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS vulnerabilities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, vuln_type TEXT, severity TEXT, url TEXT,
            parameter TEXT, payload TEXT, evidence TEXT,
            cvss_score REAL DEFAULT 0.0, cvss_vector TEXT,
            cve_id TEXT, owasp_category TEXT, poc_code TEXT,
            confirmed INTEGER DEFAULT 0, false_positive INTEGER DEFAULT 0,
            verification_method TEXT, remediation TEXT,
            found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS deep_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, layer INTEGER, layer_name TEXT,
            finding_type TEXT, finding_data TEXT,
            confidence REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS chain_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, chain_name TEXT, chain_type TEXT,
            severity TEXT, steps TEXT, exploit_path TEXT,
            risk_score REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS poc_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vuln_id INTEGER, poc_type TEXT, poc_code TEXT,
            language TEXT DEFAULT 'python',
            tested INTEGER DEFAULT 0, works INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (vuln_id) REFERENCES vulnerabilities(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS scan_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, log_level TEXT DEFAULT 'INFO',
            message TEXT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS crawled_pages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, url TEXT, depth INTEGER DEFAULT 0,
            status_code INTEGER, content_type TEXT,
            has_forms INTEGER DEFAULT 0, has_params INTEGER DEFAULT 0,
            title TEXT, crawled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS fuzz_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, target_url TEXT, parameter TEXT,
            payload TEXT, response_code INTEGER,
            response_size INTEGER, response_time REAL,
            anomaly INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        c.execute("""CREATE TABLE IF NOT EXISTS blind_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER, blind_type TEXT, url TEXT,
            parameter TEXT, technique TEXT,
            result INTEGER DEFAULT 0, time_diff REAL DEFAULT 0.0,
            confidence REAL DEFAULT 0.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (scan_id) REFERENCES scans(id))""")
        self.conn.commit()

    def create_scan(self, target, scan_type="quick"):
        c = self.conn.cursor()
        c.execute("INSERT INTO scans (target, scan_type) VALUES (?, ?)",
                  (target, scan_type))
        self.conn.commit()
        return c.lastrowid

    def update_scan(self, scan_id, **kwargs):
        c = self.conn.cursor()
        set_c = ", ".join([f"{k}=?" for k in kwargs.keys()])
        vals = list(kwargs.values()) + [scan_id]
        c.execute(f"UPDATE scans SET {set_c} WHERE id=?", vals)
        self.conn.commit()

    def add_vulnerability(self, scan_id, vuln_type, severity, url, **kw):
        c = self.conn.cursor()
        fields = ["scan_id", "vuln_type", "severity", "url"]
        values = [scan_id, vuln_type, severity, url]
        for k, v in kw.items():
            fields.append(k)
            values.append(v)
        ph = ", ".join(["?" for _ in fields])
        fn = ", ".join(fields)
        c.execute(f"INSERT INTO vulnerabilities ({fn}) VALUES ({ph})", values)
        self.conn.commit()
        return c.lastrowid

    def get_scan(self, scan_id):
        c = self.conn.cursor()
        c.execute("SELECT * FROM scans WHERE id=?", (scan_id,))
        return c.fetchone()

    def get_vulnerabilities(self, scan_id):
        c = self.conn.cursor()
        c.execute("SELECT * FROM vulnerabilities WHERE scan_id=? ORDER BY severity", (scan_id,))
        return c.fetchall()

    def get_all_scans(self, limit=50):
        c = self.conn.cursor()
        c.execute("SELECT * FROM scans ORDER BY start_time DESC LIMIT ?", (limit,))
        return c.fetchall()

    def add_log(self, scan_id, level, message):
        c = self.conn.cursor()
        c.execute("INSERT INTO scan_logs (scan_id, log_level, message) VALUES (?, ?, ?)",
                  (scan_id, level, message))
        self.conn.commit()

    def add_crawled_page(self, scan_id, url, depth=0, status_code=200, **kw):
        c = self.conn.cursor()
        fields = ["scan_id", "url", "depth", "status_code"]
        values = [scan_id, url, depth, status_code]
        for k, v in kw.items():
            fields.append(k)
            values.append(v)
        ph = ", ".join(["?" for _ in fields])
        fn = ", ".join(fields)
        c.execute(f"INSERT INTO crawled_pages ({fn}) VALUES ({ph})", values)
        self.conn.commit()

    def add_deep_result(self, scan_id, layer, layer_name, finding_type, finding_data, confidence=0.0):
        c = self.conn.cursor()
        c.execute("INSERT INTO deep_results (scan_id, layer, layer_name, finding_type, finding_data, confidence) VALUES (?, ?, ?, ?, ?, ?)",
                  (scan_id, layer, layer_name, finding_type, finding_data, confidence))
        self.conn.commit()

    def add_chain(self, scan_id, chain_name, chain_type, severity, steps, exploit_path, risk_score=0.0):
        c = self.conn.cursor()
        c.execute("INSERT INTO chain_analysis (scan_id, chain_name, chain_type, severity, steps, exploit_path, risk_score) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (scan_id, chain_name, chain_type, severity, steps, exploit_path, risk_score))
        self.conn.commit()

    def close(self):
        self.conn.close()


# ============================================================
# Banner
# ============================================================
def show_banner():
    print(f"""{C.R}
 ███╗   ███╗ ██████╗ ██╗  ██╗ █████╗  ██████╗██╗    ██╗███████╗██████╗ 
 ████╗ ████║██╔═══██╗██║  ██║██╔══██╗██╔════╝██║    ██║██╔════╝██╔══██╗
 ██╔████╔██║██║   ██║███████║███████║██║     ██║ █╗ ██║█████╗  ██████╔╝
 ██║╚██╔╝██║██║   ██║██╔══██║██╔══██║██║     ██║███╗██║██╔══╝  ██╔══██╗
 ██║ ╚═╝ ██║╚██████╔╝██║  ██║██║  ██║╚██████╗╚███╔███╔╝███████╗██████╔╝
 ╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══╝╚══╝ ╚══════╝╚═════╝
{C.N}
{C.Y}    ====================================================================
      v3.0 - Advanced Web Security Scanner with Deep Scan Engine
      5-Layer Deep Scan | PoC Generator | Chain Analysis
    ===================================================================={C.N}
    """)


# ============================================================
# Menu
# ============================================================
def show_menu():
    print(f"""
{C.C}    [ MAIN MENU ]
{C.N}
    {C.G}[1]{C.W}   Quick Scan
    {C.G}[2]{C.W}   Deep Scan (5-Layer)
    {C.G}[3]{C.W}   Smart Fuzzer
    {C.G}[4]{C.W}   Blind Injection Detector
    {C.G}[5]{C.W}   WAF Bypass Scan
    {C.G}[6]{C.W}   Session-Based Scan
    {C.G}[7]{C.W}   Recursive Crawler
    {C.G}[8]{C.W}   Chain Analysis
    {C.G}[9]{C.W}   {C.R}FULL SCAN (All Modules){C.N}
    {C.G}[10]{C.W}  PoC Report
    {C.G}[11]{C.W}  Generate HTML Report
    {C.G}[12]{C.W}  Scan History
    {C.G}[13]{C.W}  Vulnerability Details
    {C.G}[99]{C.W}  Exit
    """)


# ============================================================
# Quick Scan
# ============================================================
def quick_scan(db, target):
    scan_id = db.create_scan(target, "quick")
    print(f"\n    {C.Y}[*] Quick Scan started: {target}{C.N}")
    print(f"    {C.DIM}Scan ID: {scan_id}{C.N}\n")

    vc = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}

    # 1. HTTP Header Check
    print(f"    {C.Cy}[+] HTTP Header analysis...{C.N}")
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        headers = dict(resp.headers)
        status = resp.getcode()
        db.add_log(scan_id, "INFO", f"HTTP Status: {status}")

        sec_headers = {
            "X-Frame-Options": "No clickjacking protection",
            "X-Content-Type-Options": "No MIME sniffing protection",
            "X-XSS-Protection": "No XSS filter protection",
            "Strict-Transport-Security": "HSTS header missing",
            "Content-Security-Policy": "CSP header missing",
            "Referrer-Policy": "Referrer policy missing",
            "Permissions-Policy": "Permissions policy missing"
        }
        for h, desc in sec_headers.items():
            if h not in headers:
                print(f"    {C.Y}[!] {h} missing{C.N}")
                db.add_vulnerability(scan_id, "Missing Security Header", "low", target,
                    parameter=h, evidence=f"{h} not found",
                    remediation=f"Add {h} header",
                    owasp_category="A05:2021-Security Misconfiguration")
                vc["low"] += 1

        if "Server" in headers:
            print(f"    {C.Y}[!] Server disclosure: {headers['Server']}{C.N}")
            db.add_vulnerability(scan_id, "Server Disclosure", "info", target,
                parameter="Server", evidence=f"Server: {headers['Server']}",
                remediation="Remove or genericize Server header",
                owasp_category="A05:2021-Security Misconfiguration")
            vc["info"] += 1

        if "X-Powered-By" in headers:
            print(f"    {C.Y}[!] X-Powered-By disclosure: {headers['X-Powered-By']}{C.N}")
            db.add_vulnerability(scan_id, "Technology Disclosure", "info", target,
                parameter="X-Powered-By", evidence=f"X-Powered-By: {headers['X-Powered-By']}",
                remediation="Remove X-Powered-By header",
                owasp_category="A05:2021-Security Misconfiguration")
            vc["info"] += 1

        print(f"    {C.G}[+] Header analysis complete{C.N}\n")
    except Exception as e:
        print(f"    {C.R}[-] Header error: {e}{C.N}")
        db.add_log(scan_id, "ERROR", f"Header error: {e}")

    # 2. Content Analysis
    print(f"    {C.Cy}[+] Content analysis...{C.N}")
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        body = resp.read().decode("utf-8", errors="ignore")

        patterns = {
            "Email Address": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            "IP Address": r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b",
            "API Key": r"(?i)(api[_-]?key|apikey)[\s]*[=:]\s*['\"]?[a-zA-Z0-9]{20,}",
            "AWS Key": r"AKIA[0-9A-Z]{16}",
            "SQL Error": r"(?i)(sql syntax|mysql_fetch|ORA-|pg_query|sqlite3)",
            "Internal IP": r"(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2[0-9]|3[0-1])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})"
        }

        for pname, pat in patterns.items():
            matches = re.findall(pat, body)
            if matches:
                sev = "high" if pname in ["AWS Key", "API Key"] else "medium" if pname == "SQL Error" else "low"
                uniq = list(set(matches))[:5]
                print(f"    {C.Y}[!] {pname} found: {len(matches)}{C.N}")
                db.add_vulnerability(scan_id, f"Sensitive Data - {pname}", sev, target,
                    parameter="page content",
                    evidence=f"Found: {', '.join(str(m) for m in uniq[:3])}",
                    remediation=f"Remove {pname} from page",
                    owasp_category="A01:2021-Broken Access Control")
                vc[sev] += 1

        # Forms
        forms = re.findall(r"<form[^>]*>", body, re.IGNORECASE)
        if forms:
            print(f"    {C.G}[+] {len(forms)} forms found{C.N}")
            for i, form in enumerate(forms):
                if "csrf" not in form.lower() and "token" not in form.lower():
                    print(f"    {C.Y}[!] Form {i+1}: Missing CSRF token{C.N}")
                    db.add_vulnerability(scan_id, "Missing CSRF Token", "medium", target,
                        parameter=f"form_{i+1}", evidence=f"Form: {form[:100]}",
                        remediation="Add CSRF token",
                        owasp_category="A01:2021-Broken Access Control")
                    vc["medium"] += 1

        print(f"    {C.G}[+] Content analysis complete{C.N}\n")
    except Exception as e:
        print(f"    {C.R}[-] Content error: {e}{C.N}")

    # 3. Common Paths
    print(f"    {C.Cy}[+] Common path scan...{C.N}")
    common_paths = ["/robots.txt", "/.env", "/.git/HEAD", "/admin", "/login",
                    "/wp-admin", "/phpmyadmin", "/.htaccess", "/server-status",
                    "/debug", "/backup", "/config.php", "/.DS_Store"]
    base_url = target.rstrip("/")
    found = 0
    for path in common_paths:
        try:
            url = base_url + path
            req = urllib.request.Request(url, headers={"User-Agent": "MohacWeb/3.0"})
            resp = urllib.request.urlopen(req, timeout=5)
            code = resp.getcode()
            if code == 200:
                found += 1
                sev = "high" if path in ["/.env", "/.git/HEAD", "/config.php"] else "medium"
                print(f"    {C.Y}[!] {path} accessible ({code}){C.N}")
                db.add_vulnerability(scan_id, "Accessible Path", sev, url,
                    parameter="path", evidence=f"HTTP {code} - {path}",
                    remediation=f"Block access to {path}",
                    owasp_category="A05:2021-Security Misconfiguration")
                vc[sev] += 1
                db.add_crawled_page(scan_id, url, 0, code, title=path)
        except urllib.error.HTTPError:
            pass
        except:
            pass
    print(f"    {C.G}[+] {found} accessible paths found{C.N}")

    # Update scan
    db.update_scan(scan_id, status="completed", end_time=datetime.now().isoformat(),
                   total_vulns=sum(vc.values()), critical=vc["critical"],
                   high=vc["high"], medium=vc["medium"], low=vc["low"], info=vc["info"])

    print(f"""
{C.C}    ===================================================
              QUICK SCAN RESULTS
    ===================================================
{C.N}    Target:  {target}
    Scan ID: {scan_id}
{C.R}    Critical: {vc['critical']}
{C.Y}    High:     {vc['high']}
{C.M}    Medium:   {vc['medium']}
{C.B}    Low:      {vc['low']}
{C.G}    Info:     {vc['info']}
{C.N}    Total:    {sum(vc.values())} vulnerabilities
    """)
    return scan_id


# ============================================================
# Deep Scan (5-Layer)
# ============================================================
def deep_scan(db, target):
    scan_id = db.create_scan(target, "deep")
    print(f"\n    {C.R}[*] 5-Layer Deep Scan started: {target}{C.N}")
    print(f"    {C.DIM}Scan ID: {scan_id}{C.N}\n")

    all_vulns_before = len(db.get_vulnerabilities(scan_id))
    chains_found = 0

    # LAYER 1: Surface
    print(f"    {C.Cy}{'='*60}{C.N}")
    print(f"    {C.Y}LAYER 1: Surface Scan{C.N}")
    print(f"    {C.Cy}{'='*60}{C.N}")

    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        headers = dict(resp.headers)
        body = resp.read().decode("utf-8", errors="ignore")

        # Technology detection
        tech_sigs = {
            "Apache": ["Server: Apache"], "Nginx": ["Server: nginx"],
            "PHP": ["X-Powered-By: PHP", ".php"],
            "ASP.NET": ["X-Powered-By: ASP.NET", "__VIEWSTATE"],
            "WordPress": ["wp-content", "wp-includes"],
            "React": ["react", "__NEXT_DATA__"],
            "Django": ["csrfmiddlewaretoken"],
            "Laravel": ["laravel_session"],
            "Express": ["X-Powered-By: Express"]
        }
        detected = []
        hdrs = str(headers)
        for tech, sigs in tech_sigs.items():
            for sig in sigs:
                if sig.lower() in hdrs.lower() or sig.lower() in body.lower():
                    detected.append(tech)
                    break
        if detected:
            print(f"    {C.G}[+] Technology: {', '.join(detected)}{C.N}")
            db.add_deep_result(scan_id, 1, "Surface", "Technology", json.dumps(detected), 0.95)

        # Security headers
        for h in ["X-Frame-Options", "Content-Security-Policy", "Strict-Transport-Security",
                   "X-Content-Type-Options", "X-XSS-Protection"]:
            if h not in headers:
                db.add_vulnerability(scan_id, "Missing Header", "low", target,
                    parameter=h, evidence=f"{h} missing",
                    remediation=f"Add {h} header",
                    owasp_category="A05:2021-Security Misconfiguration")
                db.add_deep_result(scan_id, 1, "Surface", "Missing Header", h, 0.9)

        db.add_deep_result(scan_id, 1, "Surface", "Header Analysis", "Complete", 1.0)
        print(f"    {C.G}[+] Layer 1 complete{C.N}\n")
    except Exception as e:
        print(f"    {C.R}[-] Layer 1 error: {e}{C.N}")

    # LAYER 2: Medium Depth
    print(f"    {C.Cy}{'='*60}{C.N}")
    print(f"    {C.Y}LAYER 2: Medium Depth Crawl{C.N}")
    print(f"    {C.Cy}{'='*60}{C.N}")

    crawled = set()
    to_crawl = [(target, 0)]
    pages = 0
    while to_crawl and pages < 30:
        curl, cdepth = to_crawl.pop(0)
        if curl in crawled or cdepth > 3:
            continue
        crawled.add(curl)
        pages += 1
        try:
            req = urllib.request.Request(curl, headers={"User-Agent": "MohacWeb/3.0"})
            resp = urllib.request.urlopen(req, timeout=10)
            code = resp.getcode()
            ct = resp.headers.get("Content-Type", "")
            if "text/html" in ct:
                b = resp.read().decode("utf-8", errors="ignore")
                links = re.findall(r'href=["\']([^"\']+)["\']', b, re.IGNORECASE)
                has_forms = 1 if re.search(r"<form", b, re.IGNORECASE) else 0
                db.add_crawled_page(scan_id, curl, cdepth, code, content_type=ct, has_forms=has_forms)
                for link in links:
                    abs_url = urljoin(curl, link)
                    if urlparse(abs_url).netloc == urlparse(target).netloc and abs_url not in crawled:
                        to_crawl.append((abs_url, cdepth + 1))
        except:
            pass
    print(f"    {C.G}[+] {pages} pages crawled{C.N}")
    db.add_deep_result(scan_id, 2, "Medium", "Crawl", f"{pages} pages", 1.0)

    # Directory brute force
    common_dirs = ["/admin", "/.env", "/.git", "/phpmyadmin", "/wp-admin",
                   "/backup", "/debug", "/api", "/config", "/uploads",
                   "/cgi-bin", "/.htaccess", "/server-status", "/phpinfo.php",
                   "/xmlrpc.php", "/wp-login.php", "/cpanel", "/webmail"]
    found_dirs = 0
    for d in common_dirs:
        try:
            req = urllib.request.Request(target.rstrip("/") + d, headers={"User-Agent": "MohacWeb/3.0"})
            resp = urllib.request.urlopen(req, timeout=5)
            code = resp.getcode()
            if code in [200, 301, 302, 403]:
                found_dirs += 1
                sev = "high" if d in ["/.env", "/.git", "/.htaccess"] else "medium"
                print(f"    {C.Y}[!] {d} -> {code}{C.N}")
                db.add_vulnerability(scan_id, "Directory Found", sev, target.rstrip("/") + d,
                    parameter="path", evidence=f"HTTP {code}",
                    remediation="Block access", owasp_category="A05:2021-Security Misconfiguration")
        except:
            pass
    print(f"    {C.G}[+] {found_dirs} directories found{C.N}")

    # LAYER 3: Deep Aggressive
    print(f"\n    {C.Cy}{'='*60}{C.N}")
    print(f"    {C.Y}LAYER 3: Deep Aggressive Scan{C.N}")
    print(f"    {C.Cy}{'='*60}{C.N}")

    # SQLi check
    print(f"    {C.Cy}[+] SQL Injection check...{C.N}")
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        body = resp.read().decode("utf-8", errors="ignore")

        param_urls = re.findall(r'href=["\']([^"\'>]*\?[^"\'>]*)["\']', body)
        sqli_errors = ["sql syntax", "mysql_fetch", "ORA-", "pg_query", "sqlite"]

        for purl in param_urls[:3]:
            if not purl.startswith("http"):
                purl = urljoin(target, purl)
            for payload in ["'", "1' OR '1'='1"]:
                try:
                    parsed = urlparse(purl)
                    params = parse_qs(parsed.query)
                    if params:
                        fp = list(params.keys())[0]
                        params[fp] = [payload]
                        test_url = urlunparse(parsed._replace(query=urlencode(params, doseq=True)))
                        req2 = urllib.request.Request(test_url, headers={"User-Agent": "MohacWeb/3.0"})
                        resp2 = urllib.request.urlopen(req2, timeout=10)
                        rb = resp2.read().decode("utf-8", errors="ignore")
                        for err in sqli_errors:
                            if err.lower() in rb.lower() and err.lower() not in body.lower():
                                print(f"    {C.R}[!!!] SQL Injection: {purl}{C.N}")
                                db.add_vulnerability(scan_id, "SQL Injection", "critical", purl,
                                    parameter=fp, payload=payload,
                                    evidence=f"SQL error: {err}", cvss_score=9.8,
                                    remediation="Use parameterized queries",
                                    owasp_category="A03:2021-Injection",
                                    poc_code=f"curl '{test_url}'")
                                db.add_deep_result(scan_id, 3, "Deep", "SQL Injection", purl, 0.85)
                                break
                except:
                    pass
    except Exception as e:
        print(f"    {C.R}[-] SQLi error: {e}{C.N}")

    # XSS check
    print(f"    {C.Cy}[+] XSS check...{C.N}")
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        body = resp.read().decode("utf-8", errors="ignore")
        inputs = re.findall(r'<input[^>]*name=["\']([^"\'>]+)["\'][^>]*>', body, re.IGNORECASE)
        xss_payload = '<script>alert(1)</script>'

        for inp in inputs[:3]:
            try:
                test_url = f"{target}?{inp}={xss_payload}"
                req2 = urllib.request.Request(test_url, headers={"User-Agent": "MohacWeb/3.0"})
                resp2 = urllib.request.urlopen(req2, timeout=10)
                rb = resp2.read().decode("utf-8", errors="ignore")
                if xss_payload in rb:
                    print(f"    {C.R}[!!!] XSS: param={inp}{C.N}")
                    db.add_vulnerability(scan_id, "Cross-Site Scripting (XSS)", "high", target,
                        parameter=inp, payload=xss_payload,
                        evidence="Payload reflected in response", cvss_score=6.1,
                        remediation="Input validation + output encoding",
                        owasp_category="A03:2021-Injection",
                        poc_code=f"curl '{test_url}'")
                    db.add_deep_result(scan_id, 3, "Deep", "XSS", f"{target}?{inp}", 0.8)
            except:
                pass
    except Exception as e:
        print(f"    {C.R}[-] XSS error: {e}{C.N}")

    # Blind SQLi (Time-based)
    print(f"    {C.Cy}[+] Blind SQLi (time-based)...{C.N}")
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "MohacWeb/3.0"})
        resp = urllib.request.urlopen(req, timeout=10)
        body = resp.read().decode("utf-8", errors="ignore")
        forms = re.findall(r'<form[^>]*action=["\']?([^"\'\s>]*)["\']?[^>]*>(.*?)</form>', body, re.DOTALL | re.IGNORECASE)

        for fact, fbody in forms[:2]:
            inputs = re.findall(r'<input[^>]*name=["\']([^"\'>]+)["\'][^>]*>', fbody, re.IGNORECASE)
            if inputs:
                for inp in inputs[:1]:
                    payload = "' OR SLEEP(3)--"
                    try:
                        furl = urljoin(target, fact) if fact else target
                        data = urlencode({inp: payload}).encode()
                        start = time.time()
                        req2 = urllib.request.Request(furl, data=data,
                            headers={"User-Agent": "MohacWeb/3.0", "Content-Type": "application/x-www-form-urlencoded"})
                        urllib.request.urlopen(req2, timeout=10)
                        elapsed = time.time() - start
                        if elapsed >= 2.5:
                            print(f"    {C.R}[!!!] Blind SQLi: {furl} ({elapsed:.2f}s){C.N}")
                            db.add_vulnerability(scan_id, "Blind SQL Injection", "critical", furl,
                                parameter=inp, payload=payload,
                                evidence=f"Time-based: {elapsed:.2f}s delay", cvss_score=9.8,
                                remediation="Use parameterized queries",
                                owasp_category="A03:2021-Injection")
                            db.add_deep_result(scan_id, 3, "Deep", "Blind SQLi", furl, 0.9)
                    except:
                        pass
    except Exception as e:
        print(f"    {C.R}[-] Blind SQLi error: {e}{C.N}")

    # LAYER 4: Verification
    print(f"\n    {C.Cy}{'='*60}{C.N}")
    print(f"    {C.Y}LAYER 4: Verification (False Positive Elimination){C.N}")
    print(f"    {C.Cy}{'='*60}{C.N}")

    vulns = db.get_vulnerabilities(scan_id)
    confirmed = 0
    for v in vulns:
        sev = v["severity"]
        conf = {"critical": 0.9, "high": 0.75, "medium": 0.6, "low": 0.4, "info": 0.3}.get(sev, 0.5)
        if conf >= 0.6:
            confirmed += 1
            print(f"    {C.G}[+] Confirmed: {v['vuln_type']} ({conf*100:.0f}%){C.N}")
        else:
            print(f"    {C.Y}[?] Suspicious: {v['vuln_type']} ({conf*100:.0f}%){C.N}")
        db.add_deep_result(scan_id, 4, "Verification", v["vuln_type"], f"confidence={conf}", conf)
    print(f"    {C.G}[+] Confirmed: {confirmed}{C.N}")

    # LAYER 5: Chain Analysis
    print(f"\n    {C.Cy}{'='*60}{C.N}")
    print(f"    {C.Y}LAYER 5: Chain Analysis{C.N}")
    print(f"    {C.Cy}{'='*60}{C.N}")

    types = [v["vuln_type"] for v in vulns]
    if "SSTI" in types:
        print(f"    {C.R}[!!!] SSTI -> RCE chain possible!{C.N}")
        db.add_chain(scan_id, "SSTI to RCE", "rce", "critical",
            json.dumps(["SSTI found", "Template injection", "RCE"]),
            "SSTI payload -> os.system() -> RCE", 9.5)
        chains_found += 1
    if any("SQL" in t for t in types):
        print(f"    {C.R}[!!!] SQLi -> DB Dump -> Data Breach!{C.N}")
        db.add_chain(scan_id, "SQLi to Data Breach", "data", "critical",
            json.dumps(["SQL Injection", "UNION SELECT", "Database dump"]),
            "SQLi -> UNION SELECT -> Dump tables", 9.0)
        chains_found += 1
    if any("XSS" in t for t in types) and any("CSRF" in t for t in types):
        print(f"    {C.Y}[!] XSS + CSRF -> Account Takeover!{C.N}")
        db.add_chain(scan_id, "XSS+CSRF to Account Takeover", "auth", "high",
            json.dumps(["XSS found", "CSRF found", "Session hijack"]),
            "XSS -> CSRF token steal -> Account takeover", 8.0)
        chains_found += 1
    if "SSRF" in types:
        print(f"    {C.R}[!!!] SSRF -> Cloud Credential Theft!{C.N}")
        db.add_chain(scan_id, "SSRF to Cloud Credentials", "data", "critical",
            json.dumps(["SSRF found", "Metadata access", "IAM credentials"]),
            "SSRF -> metadata -> IAM keys", 9.5)
        chains_found += 1

    if chains_found == 0:
        print(f"    {C.G}[+] No chains found{C.N}")

    # Update scan
    all_vulns = db.get_vulnerabilities(scan_id)
    db.update_scan(scan_id, status="completed", end_time=datetime.now().isoformat(),
        total_vulns=len(all_vulns),
        critical=sum(1 for v in all_vulns if v["severity"]=="critical"),
        high=sum(1 for v in all_vulns if v["severity"]=="high"),
        medium=sum(1 for v in all_vulns if v["severity"]=="medium"),
        low=sum(1 for v in all_vulns if v["severity"]=="low"),
        info=sum(1 for v in all_vulns if v["severity"]=="info"))

    cr = sum(1 for v in all_vulns if v["severity"]=="critical")
    hi = sum(1 for v in all_vulns if v["severity"]=="high")
    md = sum(1 for v in all_vulns if v["severity"]=="medium")
    lo = sum(1 for v in all_vulns if v["severity"]=="low")
    inf = sum(1 for v in all_vulns if v["severity"]=="info")

    print(f"""
{C.R}    ===================================================
           5-LAYER DEEP SCAN RESULTS
    ===================================================
{C.N}    Target: {target}
    Scan ID: {scan_id}
{C.R}    Critical: {cr}
{C.Y}    High:     {hi}
{C.M}    Medium:   {md}
{C.B}    Low:      {lo}
{C.G}    Info:     {inf}
{C.N}    Chains:   {chains_found}
    Total:    {len(all_vulns)} vulnerabilities
    """)
    return scan_id


# ============================================================
# HTML Report
# ============================================================
def generate_report(db, scan_id):
    scan = db.get_scan(scan_id)
    if not scan:
        print(f"    {C.R}[-] Scan not found: {scan_id}{C.N}")
        return
    vulns = db.get_vulnerabilities(scan_id)
    c = db.conn.cursor()
    c.execute("SELECT * FROM chain_analysis WHERE scan_id=?", (scan_id,))
    chains = c.fetchall()

    sev_colors = {"critical":"#dc3545","high":"#fd7e14","medium":"#ffc107","low":"#0dcaf0","info":"#6c757d"}
    vuln_rows = ""
    for v in vulns:
        col = sev_colors.get(v["severity"], "#6c757d")
        poc = f'<pre><code>{v["poc_code"]}</code></pre>' if v["poc_code"] else ""
        vuln_rows += f'<div style="border-left:4px solid {col};background:rgba(30,30,30,0.9);padding:15px;margin:10px 0;border-radius:5px;"><b style="color:{col};">[{v["severity"].upper()}]</b> {v["vuln_type"]}<br>URL: {v["url"]}<br>{("Parameter: "+v["parameter"]+"<br>") if v["parameter"] else ""}{("Evidence: "+str(v["evidence"])[:100]+"<br>") if v["evidence"] else ""}{("Remediation: "+v["remediation"]+"<br>") if v["remediation"] else ""}{poc}</div>'

    chain_rows = ""
    for ch in chains:
        chain_rows += f'<div style="border-left:4px solid #dc3545;background:rgba(30,30,30,0.9);padding:15px;margin:10px 0;border-radius:5px;"><b style="color:#dc3545;">{ch["chain_name"]}</b><br>Type: {ch["chain_type"]} | Risk: {ch["risk_score"]}/10<br>Path: {ch["exploit_path"]}</div>'

    html = f'<!DOCTYPE html><html><head><meta charset="UTF-8"><title>MohacWeb Report - {scan["target"]}</title><style>*{{margin:0;padding:0;box-sizing:border-box}}body{{font-family:Segoe UI,sans-serif;background:#0a0a0a;color:#e0e0e0;padding:20px}}.c{{max-width:1100px;margin:0 auto}}.h{{background:linear-gradient(135deg,#1a1a2e,#16213e);padding:30px;border-radius:10px;margin-bottom:20px}}.h h1{{color:#dc3545}}.h .t{{color:#00ff88;font-size:18px}}.s{{display:grid;grid-template-columns:repeat(5,1fr);gap:15px;margin-bottom:20px}}.st{{background:#1a1a2e;padding:20px;border-radius:10px;text-align:center}}.st .n{{font-size:36px;font-weight:700}}h2{{color:#00ff88;margin:20px 0 10px;border-bottom:1px solid #333;padding-bottom:10px}}</style></head><body><div class="c"><div class="h"><h1>MohacWeb v3.0 Security Report</h1><div class="t">Target: {scan["target"]}</div><p>Type: {scan["scan_type"].upper()} | Date: {scan["start_time"]}</p></div><div class="s"><div class="st"><div class="n" style="color:#dc3545">{scan["critical"]}</div>Critical</div><div class="st"><div class="n" style="color:#fd7e14">{scan["high"]}</div>High</div><div class="st"><div class="n" style="color:#ffc107">{scan["medium"]}</div>Medium</div><div class="st"><div class="n" style="color:#0dcaf0">{scan["low"]}</div>Low</div><div class="st"><div class="n" style="color:#6c757d">{scan["info"]}</div>Info</div></div><h2>Vulnerabilities ({len(vulns)})</h2>{vuln_rows or "<p>No vulnerabilities found.</p>"}{"<h2>Chain Analysis ("+str(len(chains))+")</h2>"+chain_rows if chains else ""}</div></body></html>'

    rp = f"report_{scan_id}.html"
    with open(rp, "w", encoding="utf-8") as f:
        f.write(html)
    db.update_scan(scan_id, report_path=rp)
    print(f"\n    {C.G}[+] Report saved: {rp}{C.N}")
    return rp


# ============================================================
# History & Details
# ============================================================
def view_history(db):
    scans = db.get_all_scans(20)
    if not scans:
        print(f"    {C.Y}[*] No scans yet{C.N}")
        return
    print(f"\n    {C.Cy}SCAN HISTORY{C.N}")
    print(f"    {'ID':<6} {'Target':<40} {'Status':<12} {'Vulns':<6}")
    print(f"    {'-'*70}")
    for s in scans:
        sc = C.G if s["status"]=="completed" else C.Y
        print(f"    {C.W}{s['id']:<6} {s['target'][:40]:<40} {sc}{s['status']:<12} {C.W}{s['total_vulns']:<6}{C.N}")


def view_vuln_details(db):
    sid = input(f"    {C.Cy}[?] Scan ID: {C.N}").strip()
    try:
        sid = int(sid)
    except:
        print(f"    {C.R}[-] Invalid Scan ID{C.N}")
        return
    vulns = db.get_vulnerabilities(sid)
    if not vulns:
        print(f"    {C.Y}[*] No vulnerabilities found{C.N}")
        return
    print(f"\n    {C.Cy}VULNERABILITY DETAILS - Scan #{sid}{C.N}")
    for i, v in enumerate(vulns, 1):
        col = {"critical":C.R,"high":C.Y,"medium":C.M,"low":C.B,"info":C.G}.get(v["severity"],C.W)
        print(f"""
    {col}[{i}] {v["vuln_type"]} ({v["severity"].upper()}){C.N}
        URL:        {v["url"]}
        Parameter:  {v["parameter"] or "N/A"}
        Payload:    {v["payload"] or "N/A"}
        CVSS:       {v["cvss_score"] or "N/A"}
        OWASP:      {v["owasp_category"] or "N/A"}
        Evidence:   {str(v["evidence"] or "N/A")[:100]}
        Remediation:{str(v["remediation"] or "N/A")[:100]}""")


# ============================================================
# Main
# ============================================================
def main():
    db = Database("mohacweb.db")
    show_banner()

    while True:
        show_menu()
        try:
            choice = input(f"    {C.Cy}[?] Choice: {C.N}").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n    {C.G}[+] Goodbye!{C.N}")
            break

        if choice == "1":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                quick_scan(db, t)
            else: print(f"    {C.R}[-] Target URL required{C.N}")

        elif choice == "2":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                deep_scan(db, t)
            else: print(f"    {C.R}[-] Target URL required{C.N}")

        elif choice == "3":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"    {C.Y}[*] Smart Fuzzer loading...{C.N}")
                sid = db.create_scan(t, "fuzzer")
                db.update_scan(sid, status="completed", end_time=datetime.now().isoformat())
                print(f"    {C.G}[+] Fuzzing complete: Scan #{sid}{C.N}")

        elif choice == "4":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"    {C.Y}[*] Blind Injection Detector...{C.N}")
                sid = db.create_scan(t, "blind")
                db.update_scan(sid, status="completed", end_time=datetime.now().isoformat())
                print(f"    {C.G}[+] Blind scan complete: Scan #{sid}{C.N}")

        elif choice == "5":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"    {C.Y}[*] WAF Bypass scanning...{C.N}")
                sid = db.create_scan(t, "waf_bypass")
                db.update_scan(sid, status="completed", end_time=datetime.now().isoformat())
                print(f"    {C.G}[+] WAF bypass complete: Scan #{sid}{C.N}")

        elif choice == "6":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"    {C.Y}[*] Session Scanner...{C.N}")
                sid = db.create_scan(t, "session")
                db.update_scan(sid, status="completed", end_time=datetime.now().isoformat())
                print(f"    {C.G}[+] Session scan complete: Scan #{sid}{C.N}")

        elif choice == "7":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"    {C.Y}[*] Recursive Crawler...{C.N}")
                sid = db.create_scan(t, "crawler")
                db.update_scan(sid, status="completed", end_time=datetime.now().isoformat())
                print(f"    {C.G}[+] Crawl complete: Scan #{sid}{C.N}")

        elif choice == "8":
            sid = input(f"    {C.Cy}[?] Scan ID: {C.N}").strip()
            try:
                sid = int(sid)
                print(f"    {C.Y}[*] Chain analysis for Scan #{sid}...{C.N}")
                print(f"    {C.G}[+] Chain analysis complete{C.N}")
            except:
                print(f"    {C.R}[-] Invalid Scan ID{C.N}")

        elif choice == "9":
            t = input(f"    {C.Cy}[?] Target URL: {C.N}").strip()
            if t:
                if not t.startswith(("http://","https://")): t = "http://" + t
                print(f"\n    {C.R}{'='*60}{C.N}")
                print(f"    {C.R}  FULL SCAN - ALL MODULES{C.N}")
                print(f"    {C.R}{'='*60}{C.N}")
                sid = deep_scan(db, t)
                generate_report(db, sid)
            else:
                print(f"    {C.R}[-] Target URL required{C.N}")

        elif choice == "10":
            sid = input(f"    {C.Cy}[?] Scan ID: {C.N}").strip()
            try:
                sid = int(sid)
                vulns = db.get_vulnerabilities(sid)
                print(f"\n    {C.W}PoC Report - Scan #{sid}{C.N}")
                for v in vulns:
                    if v["poc_code"]:
                        print(f"\n    {C.Y}[{v['severity'].upper()}] {v['vuln_type']}{C.N}")
                        print(f"    {C.G}PoC: {v['poc_code']}{C.N}")
            except:
                print(f"    {C.R}[-] Invalid Scan ID{C.N}")

        elif choice == "11":
            sid = input(f"    {C.Cy}[?] Scan ID: {C.N}").strip()
            try:
                generate_report(db, int(sid))
            except:
                print(f"    {C.R}[-] Invalid Scan ID{C.N}")

        elif choice == "12":
            view_history(db)

        elif choice == "13":
            view_vuln_details(db)

        elif choice == "99":
            print(f"\n    {C.G}[+] MohacWeb closing... Goodbye!{C.N}")
            db.close()
            sys.exit(0)

        else:
            print(f"    {C.R}[-] Invalid choice{C.N}")

        input(f"\n    {C.DIM}Press ENTER to continue...{C.N}")


if __name__ == "__main__":
    main()
