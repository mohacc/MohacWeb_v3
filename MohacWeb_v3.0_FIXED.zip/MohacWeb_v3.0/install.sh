#!/bin/bash
echo "=========================================="
echo "  MohacWeb v3.0 - Installation"
echo "=========================================="

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[!] Python3 not found. Installing..."
    apt-get update && apt-get install -y python3 python3-pip
fi

# Create virtual environment
echo "[*] Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo "[*] Installing dependencies..."
pip install requests beautifulsoup4 lxml

echo ""
echo "[+] Installation complete!"
echo "[+] Run: python3 MohacWeb.py"
echo "=========================================="
